package TDDieTemp.tml;

import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Die-temperature reference measurement.
 *
 * <p>Sets ARM_PS low, forces ITD into TD, measures VTD, and calculates:
 * RTD_ref = VTD / ITD.
 */
public class TD_RTD_DYN extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdRTD_Dyn;
    public IParametricTestDescriptor ptdDeltaT;

    public String gVariableNameInput = "";

    /** Known current forced into TD, in amperes. */
    public double ITD = 100e-6;

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        // Configure ARM_PS for the die-temperature reference measurement.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(false);

        // Set ARM_PS low.
        ISetupDcVI.IVforce setArmLow = arm.vforce("set_arm_low")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure TD for current force and voltage measurement.
        ISetupDcVI td = ds.addDcVI("TD_PS");
        td.setConnect(true).setDisconnect(true);

        // Force the known current ITD into TD.
        ISetupDcVI.IIforce forceITD = td.iforce("force_itd")
                .setForceValue(ITD)
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);

        // Force 0 A into TD for safe power-down.
        ISetupDcVI.IIforce forceITD0A = td.iforce("force_itd_0A")
                .setForceValue(0.0)
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);

        // Measure TD voltage VTD.
        ISetupDcVI.IVmeas measureVTD = td.vmeas("measure_vtd")
                .setVrange(3.3)
                .setHighAccuracy(true);

        // Disable the VSS disconnect pulldown for this measurement.
//        ISetupDcVI vss = ds.addDcVI("VSS_GND");
//        vss.protection().setDisconnectPulldownState(false);

        ISetupUtility.ISetState K5_VSS_GND_utility_0 = null;
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = null;
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        K5_VSS_GND_utility_1= K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        ds.parallelBegin("die_temperature_reference_measurement");
        {
            ds.sequentialBegin("set_arm_force_itd_measure_vtd");
            {
                ds.actionCall(K5_VSS_GND_utility_1);
                ds.waitCall(0.010);
                ds.actionCall(setArmLow);
                ds.actionCall(forceITD);
                ds.waitCall(0.010);
                ds.actionCall(measureVTD);

                // Safe power-down sequence: return forced current to 0A before opening relays
                ds.actionCall(forceITD0A);
                ds.waitCall(0.010);

                ds.actionCall(K5_VSS_GND_utility_0);
                ds.waitCall(0.010);

            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- Dynamic Die Temperature Test START ------->\n");

        measurement.execute();

        MultiSiteDouble RTD_ref = new MultiSiteDouble(0.0);

        if(gVariableNameInput != "") {

            RTD_ref.set(context.testProgram().variables().getDouble(gVariableNameInput));

            }

        IDcVIResults results = measurement.dcVI("TD_PS").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredVoltages =
                results.vmeas("").getVoltage();

        MultiSiteDoubleArray VTD_array = measuredVoltages.get("TD_PS");

        // Measured TD voltage.
        MultiSiteDouble VTD = VTD_array.getElement(0);

        // Dynamic TD resistance: RTD_Dyn = VTD / ITD.
        MultiSiteDouble RTD_Dyn = VTD.divide(ITD);

        // Die-temperature rise: delta-T = (RTD_Dyn - RTD_ref) / (RTD_ref * 0.0033).
        MultiSiteDouble deltaT_C = RTD_Dyn.subtract(RTD_ref)
                .divide(RTD_ref).divide(0.0033);

        println("VTD      = " + VTD + " V");
        println("ITD      = " + ITD + " A");
        println("RTD_ref  = " + RTD_ref + " Ohm");
        println("RTD_Dyn  = " + RTD_Dyn + " Ohm");
        println("delta-T  = " + deltaT_C + " C");

        // Datalog dynamic measured resistance.
        ptdRTD_Dyn.evaluate(RTD_Dyn);

        // Datalog calculated die-temperature rise.
        ptdDeltaT.evaluate(deltaT_C);
    }
}

