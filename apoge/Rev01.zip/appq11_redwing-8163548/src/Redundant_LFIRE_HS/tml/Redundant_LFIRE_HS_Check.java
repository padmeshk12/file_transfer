package Redundant_LFIRE_HS.tml;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class Redundant_LFIRE_HS_Check extends TestMethod {

    public IMeasurement measurement;
    public String VDDQGroup = "VDDQ1_AVI1";
    public IParametricTestDescriptor ptd_IQ_VDD_TEST0000;
    public IParametricTestDescriptor ptd_IQ_VDDQ_TEST0000;
    public IParametricTestDescriptor ptd_IQ_VDD_TEST1000;
    public IParametricTestDescriptor ptd_IQ_VDDQ_TEST1000;
    public IParametricTestDescriptor ptdDCISET;
    public IParametricTestDescriptor ptdDCISET_4K;
    public IParametricTestDescriptor ptd_IQ_VDD_TEST1100;
    public IParametricTestDescriptor ptd_IQ_VDDQ_TEST1100;
    public IParametricTestDescriptor ptd_IQ_VDD_TEST1110;
    public IParametricTestDescriptor ptd_IQ_VDDQ_TEST1110;
    public IParametricTestDescriptor ptd_IQ_VDDQ_TEST1110_delta;
    public IParametricTestDescriptor ptd_IQ_VDD_TEST1010;
    public IParametricTestDescriptor ptd_IQ_VDDQ_TEST1010;


    @Override
    public void setup() {
        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.025);

        ISetupDcVI.IVforce vddForce3p3V = vdd.vforce("VDD_force_3p3V")
                .setForceValue(3.3)
                .setIrange(0.025)
                .setIclamp(0.025);
        ISetupDcVI.IVforce vddForce0V = vdd.vforce("VDD_force_0V")
                .setForceValue(0.0)
                .setIrange(0.025)
                .setIclamp(0.025);
        ISetupDcVI.IImeas vddMeas = vdd.imeas("vddMeas").setIrange(0.0025).setRestoreIrange(true);

        ISetupDcVI vddq = ds.addDcVI(VDDQGroup);
        vddq.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce12V = vddq.vforce("vddq_force_12V").setForceValue(12.0)
                .setVrange(30.0).setIrange(0.05).setIclamp(0.05);
        ISetupDcVI.IVforce vddqForce0V = vddq.vforce("vddq_force_0V")
                .setForceValue(0.0).setVrange(30.0).setIrange(0.05).setIclamp(0.05);

        ISetupDcVI.IImeas vddqMeas = vddq.imeas("vddqMeas").setIrange(0.05);

        ISetupDcVI ioPins = ds.addDcVI("ARM_PS+LFIRE_PS+TEST_PS+HFIRE_PS");
        ioPins.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce ioPinsForce0V = ioPins.vforce("ioPins_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce ioPinsForceHigh = ioPins.vforce("ioPins_force_high")
                .setForceValue(3.3)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce ioPinsForce5V = ioPins.vforce("ioPins_force_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_utility_0 = K2_ISET_R4K.setState("K2_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_utility_1 = K2_ISET_R4K.setState("K2_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K9_VDD_PS").setValue(0);      // Disconnect VDD_PS (closed by UVLO_Test)
        ds.addUtility("K7_SQM1_PS").setValue(0);     // Disconnect SQM1_PS
        ds.addUtility("K13_SQP1_PS").setValue(0);    // Disconnect SQP1_PS
        ds.addUtility("K8_SQM1_C47UF").setValue(0);   // Disconnect SQM1 47uF cap
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0); // Disconnect VDDQ2 47uF cap
        ds.addUtility("K12_SQP4_C47UF").setValue(0);  // Disconnect SQP4 47uF cap
        ds.addUtility("K1_ISET_R24K").setValue(0);    // Disconnect 24k resistor
        ds.addUtility("K3_ISET_R2P4K").setValue(0);   // Disconnect 2.4k resistor
        ds.addUtility("K6_VSS_PS").setValue(0);       // Disconnect VSS_PS
        ds.addUtility("K14_TD_DPS").setValue(0);      // Disconnect TD_DPS
        ds.addUtility("K11_SQP4_GND").setValue(0);    // Disconnect SQP4 GND

        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);

        ISetupDcVI.IVmeas isetMeas = iset.vmeas("isetMeas").setVrange(1.5);

        ds.sequentialBegin("Redundant_LFIRE_PS_HS");
        {
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K2_ISET_R4K_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.waitCall(0.010);

            ds.actionCall(vddForce3p3V);
            ds.actionCall(vddqForce12V);
            ds.actionCall(ioPinsForce0V);
            ds.waitCall(0.1);
            ds.parallelBegin("Measure_current1");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(vddMeas);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();
                {
                    ds.actionCall(vddqMeas);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.actionCall("ioPins_force_high", Arrays.asList("TEST_PS"));
            ds.waitCall(0.1);
            ds.parallelBegin("Measure_current2");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(vddMeas);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();
                {
                    ds.actionCall(vddqMeas);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.actionCall("ioPins_force_high", Arrays.asList("ARM_PS"));
            ds.waitCall(0.1);
            ds.parallelBegin("Measure3");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(isetMeas);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();
                {
                    ds.actionCall(vddMeas);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();
                {
                    ds.actionCall(vddqMeas);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.actionCall("ioPins_force_high", Arrays.asList("LFIRE_PS"));
            ds.waitCall(0.1);
            ds.parallelBegin("Measure_current4");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(vddMeas);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();
                {
                    ds.actionCall(vddqMeas);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.actionCall("ioPins_force_0V", Arrays.asList("ARM_PS"));
            ds.waitCall(0.1);
            ds.parallelBegin("Measure_current5");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(vddMeas);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();
                {
                    ds.actionCall(vddqMeas);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Safe power-down sequence: bring supplies and IOs to 0V before opening GND relay
            ds.actionCall(ioPinsForce0V);
            ds.actionCall(vddForce0V);
            ds.actionCall(vddqForce0V);
            ds.waitCall(0.010);

            ds.actionCall(K5_VSS_GND_utility_0);
            ds.actionCall(K2_ISET_R4K_utility_0);
            ds.actionCall(K4_ISET_PS_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No runtime updates required.
    }

    @Override
    public void execute() {
        measurement.execute();

        IDcVIResults resultsVDD = measurement.dcVI("VDD_DPS").preserveResults();
        IDcVIResults resultsISET = measurement.dcVI("ISET_PS").preserveResults();
        IDcVIResults resultsVDDQ = measurement.dcVI(VDDQGroup).preserveResults();
        Map<String, MultiSiteDoubleArray> iMeasVDDQ = resultsVDDQ.imeas("vddqMeas").getCurrent();
        Map<String, MultiSiteDoubleArray> iMeasVDD = resultsVDD.imeas("vddMeas").getCurrent();
        Map<String, MultiSiteDoubleArray> vMeasISET = resultsISET.vmeas("isetMeas").getVoltage();

        println("\nVDDQ results are :" + iMeasVDDQ);
        println("\nVDD results are :" + iMeasVDD);
        println("\nISET results are :" + vMeasISET);

        MultiSiteDoubleArray finalResultsArrayVDDQ = new MultiSiteDoubleArray(10, 0.0);

        for (int i = 0; i < 5; i++) {
            MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

            for (int site : context.getActiveSites()) {
                double totalCurrentPerSite = 0.0;
                println("------ SITE " + site + " (Step " + (i + 1) + ") ------");

                for (Entry<String, MultiSiteDoubleArray> entry : iMeasVDDQ.entrySet()) {
                    String signal = entry.getKey();
                    MultiSiteDoubleArray valuesOfSignal = entry.getValue();
                    MultiSiteDouble valuesOfAction = valuesOfSignal.getElement(i);

                    double currentPerSignal = valuesOfAction.get(site);
                    println("Site " + site + " Signal: " + signal + " Current: " + currentPerSignal + " A");
                    totalCurrentPerSite += currentPerSignal;
                }

                totalCurrent.set(site, totalCurrentPerSite);
                println("Site " + site + " Total VDDQ Current (Step " + (i + 1) + "): " + totalCurrentPerSite + " A");
            }
            finalResultsArrayVDDQ.setElement(i, totalCurrent);
        }

        MultiSiteDoubleArray currentVDDQ = finalResultsArrayVDDQ;
        MultiSiteDoubleArray currentVDD = iMeasVDD.get("VDD_DPS");

        MultiSiteDoubleArray I_ISET_4KArray = vMeasISET.get("ISET_PS");
        MultiSiteDouble I_ISET_4K = (I_ISET_4KArray.getElement(0)).divide(4000.0);

        // -------------------------------------------------------------------------
        // Test 27000: IQ_VDD_TEST0000 (TEST=0V, ARM=0V, LFIRE=0V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDD_TEST0000.evaluate(currentVDD.getElement(0));

        // -------------------------------------------------------------------------
        // Test 27010: IQ_VDDQ_TEST0000 (TEST=0V, ARM=0V, LFIRE=0V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDDQ_TEST0000.evaluate(currentVDDQ.getElement(0));

        // -------------------------------------------------------------------------
        // Test 27020: IQ_VDD_TEST1000 (TEST=3.3V, ARM=0V, LFIRE=0V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDD_TEST1000.evaluate(currentVDD.getElement(1));

        // -------------------------------------------------------------------------
        // Test 27030: IQ_VDDQ_TEST1000 (TEST=3.3V, ARM=0V, LFIRE=0V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDDQ_TEST1000.evaluate(currentVDDQ.getElement(1));

        // -------------------------------------------------------------------------
        // Step 7 / Test 27040: ISET_TEST (ISET=4k, VDD=3.3V, VDDQ=12V, ARM=3.3V, TEST=3.3V)
        // -------------------------------------------------------------------------
        ptdDCISET.evaluate(vMeasISET.get("ISET_PS").getElement(0));

        // -------------------------------------------------------------------------
        // Step 8 / Test 27050: I_ISET_4K (ISET=4k, VDD=3.3V, VDDQ=12V, ARM=3.3V, TEST=3.3V)
        // -------------------------------------------------------------------------
        ptdDCISET_4K.evaluate(I_ISET_4K);

        // -------------------------------------------------------------------------
        // Step 9 / Test 27060: IQ_VDD_TEST1100 (TEST=3.3V, ARM=3.3V, LFIRE=0V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDD_TEST1100.evaluate(currentVDD.getElement(2));

        // -------------------------------------------------------------------------
        // Step 10 / Test 27070: IQ_VDDQ_TEST1100 (TEST=3.3V, ARM=3.3V, LFIRE=0V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDDQ_TEST1100.evaluate(currentVDDQ.getElement(2));

        // -------------------------------------------------------------------------
        // Step 12 / Test 27080: IQ_VDD_TEST1110 (TEST=3.3V, ARM=3.3V, LFIRE=3.3V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDD_TEST1110.evaluate(currentVDD.getElement(3));

        // -------------------------------------------------------------------------
        // Step 13 / Test 27090: IQ_VDDQ_TEST1110 (TEST=3.3V, ARM=3.3V, LFIRE=3.3V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDDQ_TEST1110.evaluate(currentVDDQ.getElement(3));

        // -------------------------------------------------------------------------
        // Step 14 / Test 27100: IQ_VDDQ_TEST1110_delta (Step 13 - Step 10)
        // -------------------------------------------------------------------------
        MultiSiteDouble IQ_VDDQ_TEST1110_delta = currentVDDQ.getElement(3).subtract(currentVDDQ.getElement(2));
        ptd_IQ_VDDQ_TEST1110_delta.evaluate(IQ_VDDQ_TEST1110_delta);

        // -------------------------------------------------------------------------
        // Step 16 / Test 27110: IQ_VDD_TEST1010 (TEST=3.3V, ARM=0V, LFIRE=3.3V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDD_TEST1010.evaluate(currentVDD.getElement(4));

        // -------------------------------------------------------------------------
        // Step 17 / Test 27120: IQ_VDDQ_TEST1010 (TEST=3.3V, ARM=0V, LFIRE=3.3V, HFIRE=0V)
        // -------------------------------------------------------------------------
        ptd_IQ_VDDQ_TEST1010.evaluate(currentVDDQ.getElement(4));
    }

}

