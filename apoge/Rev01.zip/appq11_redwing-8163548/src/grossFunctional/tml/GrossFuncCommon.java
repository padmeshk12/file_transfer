package grossFunctional.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.measurement.IMeasurement;

public class GrossFuncCommon extends TestMethod {

    public IMeasurement measurement;
//    public IParametricTestDescriptor ptdDC;

    public String SQPGroup = "SQP1_AVI1 +SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 +SQP4_AVI8";
    public String SQMGroup = "SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 +SQM4_AVI8";
    public String VDDQGroup = "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 +VDDQ1_AVI8";

    protected IDeviceSetup ds;

    @Override
    public void setup() {
        // TODO Auto-generated method stub
        ds = DeviceSetupFactory.createInstance(DSAGenerationMode.GENERATE_IN_FILE);

//        protected void CommonActions() {
//        IDeviceSetup ds = DeviceSetupFactory.createInstance(DSAGenerationMode.GENERATE_IN_FILE);

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7) .setIrange(0.025);

        ISetupDcVI.IVforce vddForce0V = vdd.vforce("vdd_force_common_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);
        ISetupDcVI.IVforce vddForce5p5V = vdd.vforce("vdd_force_common_5p5V").setForceValue(5.5)
                .setIrange(0.025).setIclamp(0.025);
        ISetupDcVI.IImeas vddMeasCurr = vdd.imeas("vddMeasCurr").setIrange(0.025).setRestoreIrange(false);

        ISetupDcVI highPowerGroup = ds.addDcVI(SQPGroup +"+"+ SQMGroup + "+" + VDDQGroup);
        highPowerGroup.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce highPowerForce0V = highPowerGroup.vforce("highPower_force_common_0V").setForceValue(0.0)
                .setVrange(1.5).setIrange(0.05).setIclamp(0.1/8.0);

        ISetupDcVI.IVforce highPowerForce25V = highPowerGroup.vforce("highPower_force_common_25V").setForceValue(25.0)
                .setVrange(30.0).setIrange(0.05).setIclamp(0.1/8.0);

        ISetupDcVI.IImeas MeasCurr = highPowerGroup.imeas("MeasCurrCommon").setIrange(0.05);

        ISetupDcVI.IMeasureWaveform measureCurrWaveform = highPowerGroup.measureWaveform("measureCurrWaveformCommon").setMeasTypeCurrent()
                .setIrange(0.05).setSamples(200).setSampleRate(100e3);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForce5p5V = arm.vforce("arm_force_common_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce armForce0V = arm.vforce("arm_force_common_0V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        ISetupWaveformDc dcWaveform5p5VPulse = ds.addWaveformDc("dcWaveform5VPulse").setDcValue(5.5).setSamples(100).setSampleRate(100e3);
        ISetupWaveformDc dcWaveform0VPulse = ds.addWaveformDc("dcWaveform0VPulse").setDcValue(5.5).setSamples(100).setSampleRate(100e3);

        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce5p5V = lfire.vforce("lfire_force_common_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce lfireForce0V = lfire.vforce("lfire_force_common_0V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.ISourceWaveform lfire5p5VPulse = lfire.sourceWaveform("lfire5p5VPulseCommon").setForceTypeVoltage()
                .setWaveform(dcWaveform5p5VPulse).setIclamp(0.001).setIrange(0.001);
        ISetupDcVI.ISourceWaveform lfire0VPulse = lfire.sourceWaveform("lfire0VPulseCommon").setForceTypeVoltage()
                .setWaveform(dcWaveform5p5VPulse).setIclamp(0.001).setIrange(0.001);

        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce5p5V = hfire.vforce("hfire_force_common_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce hfireForce0V = hfire.vforce("hfire_force_common_0V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        ISetupDcVI.ISourceWaveform hfire5p5VPulse = hfire.sourceWaveform("hfire5p5VPulseCommon").setForceTypeVoltage()
                .setWaveform(dcWaveform5p5VPulse).setIclamp(0.001).setIrange(0.001);
        ISetupDcVI.ISourceWaveform hfire0VPulse = hfire.sourceWaveform("hfire0VPulseCommon").setForceTypeVoltage()
                .setWaveform(dcWaveform5p5VPulse).setIclamp(0.001).setIrange(0.001);

        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        ISetupAction isetCurrForce100uA = iset.iforce("iset_force_common_100uA")
                .setForceValue(0.0001)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);
        ISetupAction isetCurrForce10uA = iset.iforce("iset_force_common_10uA")
                .setForceValue(0.00001)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);
//        }



//        measurement.setSetups(ds);

    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

//        measurement.execute();

    }

}
