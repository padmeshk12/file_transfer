package grossFunctional.tml;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class GrossFuncArmLowLfireLowHfireLow extends GrossFuncCommon {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    @Override
    public void setup() {
        // TODO Auto-generated method stub

        super.setup();

        ds.parallelBegin("seqOne");{
            ds.sequentialBegin();{
                ds.actionCall("vdd_force_common_5p5V");
                ds.actionCall("highPower_force_common_25V", Arrays.asList(VDDQGroup));
                ds.actionCall("iset_force_common_100uA");
                ds.actionCall("arm_force_common_0V");
                ds.actionCall("highPower_force_common_0V", Arrays.asList(SQPGroup));
                ds.actionCall("highPower_force_common_25V", Arrays.asList( SQMGroup));
                ds.actionCall("lfire_force_common_0V");
                ds.actionCall("hfire_force_common_0V");

                ds.actionCall("MeasCurrCommon", Arrays.asList( SQPGroup + "+" + SQMGroup));
            }
            ds.sequentialEnd();
        }ds.parallelEnd();

        measurement.setSetups(ds);

    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

        measurement.execute();

        println("\n<------- Gross Funcional Test Arm Low Lfire High Hfire High START ------->\n");

        measurement.execute();

        /* get value results for all 'iforceVmeas' actions defined in the specification */
        IDcVIResults resultsSQP = measurement.dcVI("SQP1_AVI1 +SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 +SQP4_AVI8").preserveResults();
        IDcVIResults resultsSQM = measurement.dcVI("SQM1_AVI1 +SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 +SQM4_AVI8").preserveResults();

        Map<String, MultiSiteDouble> finalResults = new HashMap<>();


        MultiSiteDouble totalCurrentSQP = new MultiSiteDouble(0.0);
        MultiSiteDouble totalCurrentSQM = new MultiSiteDouble(0.0);

        Map<String, MultiSiteDoubleArray> iMeasResultsSQP = resultsSQP.imeas("MeasCurrCommon").getCurrent();
        Map<String, MultiSiteDoubleArray> iMeasResultsSQM = resultsSQM.imeas("MeasCurrCommon").getCurrent();

        for (int site : context.getActiveSites()) {

            double totalCurrentPerSiteSQP = 0.0;
            double totalCurrentPerSiteSQM = 0.0;
            println("------ SITE " + site + " ------");

        for (Entry<String, MultiSiteDoubleArray> entry : iMeasResultsSQP.entrySet()) {
            String signal = entry.getKey();
            MultiSiteDoubleArray valuesOfSignal = entry.getValue();
            MultiSiteDouble valuesOfAction = valuesOfSignal.getElement(0);

                double currentPerSignal = valuesOfAction.get(site);
                println("Site " + site + " Signal: " + signal +" Current: " + currentPerSignal + " A");
                totalCurrentPerSiteSQP += currentPerSignal;
            }

        totalCurrentSQP.set(site, totalCurrentPerSiteSQP);
        println("--------------------------------");
        println("Site " + site +" Total Current at SQP: " + totalCurrentPerSiteSQP + " A");


        for (Entry<String, MultiSiteDoubleArray> entry : iMeasResultsSQM.entrySet()) {
            String signal = entry.getKey();
            MultiSiteDoubleArray valuesOfSignal = entry.getValue();
            MultiSiteDouble valuesOfAction = valuesOfSignal.getElement(0);

                double currentPerSignal = valuesOfAction.get(site);
                println("Site " + site + " Signal: " + signal +" Current: " + currentPerSignal + " A");
                totalCurrentPerSiteSQM += currentPerSignal;
            }

        totalCurrentSQM.set(site, totalCurrentPerSiteSQM);
        println("--------------------------------");
        println("Site " + site +" Total Current at SQM: " + totalCurrentPerSiteSQM + " A");

        }

        println("Final Total Current (All Sites): " + totalCurrentSQP);
        println("Final Total Current (All Sites): " + totalCurrentSQM);

        finalResults.put("SQM1_AVI1", totalCurrentSQM);
        finalResults.put("SQP1_AVI1", totalCurrentSQP);

        println(finalResults);

        ptdDC.evaluate(finalResults,measurement);

        println("\n<------- Gross Funcional Test Arm Low Lfire High Hfire High END ------->\n");




    }

}
