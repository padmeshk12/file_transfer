package grossFunctional.tml;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class GrossFuncArmHighLfireHighHfireLow extends GrossFuncCommon {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    @Override
    public void setup() {
        // TODO Auto-generated method stub

        super.setup();

        ds.parallelBegin("seqOne");{
            ds.sequentialBegin();{
                ds.actionCall("vdd_force_common_5p5V");
                ds.actionCall("highPower_force_common_25V", Arrays.asList(VDDQGroup));
                ds.actionCall("iset_force_common_100uA");
                ds.actionCall("arm_force_common_5p5V");
                ds.actionCall("highPower_force_common_0V", Arrays.asList(SQPGroup));
                ds.actionCall("highPower_force_common_25V", Arrays.asList( SQMGroup));
                ds.parallelBegin("parOne");{
                    ds.sequentialBegin();{
                        ds.actionCall("lfire5p5VPulseCommon");
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin();{
                        ds.actionCall("hfire0VPulseCommon");
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin();{
                        ds.actionCall("measureCurrWaveformCommon", Arrays.asList( SQPGroup + "+" + SQMGroup));
                    }
                    ds.sequentialEnd();
                }
            ds.parallelEnd();

            }
            ds.sequentialEnd();
        }ds.parallelEnd();

        measurement.setSetups(ds);

    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

        measurement.execute();

        println("\n<------- Gross Funcional Test Arm Low Lfire High Hfire High START ------->\n");

        measurement.execute();

        /* get value results for all 'iforceVmeas' actions defined in the specification */
        IDcVIResults resultsSQP = measurement
                .dcVI("SQP1_AVI1 +SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 +SQP4_AVI8")
                .preserveResults();
        IDcVIResults resultsSQM = measurement
                .dcVI("SQM1_AVI1 +SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 +SQM4_AVI8")
                .preserveResults();

        Map<String, MultiSiteWaveDoubleArray> measWaveformSQM = resultsSQM
                .measureWaveform("measureCurrWaveformCommon").getWaveform();
        Map<String, MultiSiteWaveDoubleArray> measWaveformSQP = resultsSQP
                .measureWaveform("measureCurrWaveformCommon").getWaveform();

        Map<String, MultiSiteDouble> finalResults = new HashMap<>();

        MultiSiteDouble totalCurrentSQP = new MultiSiteDouble(0.0);
        MultiSiteDouble totalCurrentSQM = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {

            double totalCurrentPerSiteSQP = 0.0;
            double totalCurrentPerSiteSQM = 0.0;
            MultiSiteWaveDouble w200_sqms1 = measWaveformSQM.get("SQM1_AVI1").getElement(0);
            MultiSiteWaveDouble w200_sqmg1 = measWaveformSQM.get("SQM1_AVI2").getElement(0);
            MultiSiteWaveDouble w200_sqmg2 = measWaveformSQM.get("SQM2_AVI3").getElement(0);
            MultiSiteWaveDouble w200_sqmg3 = measWaveformSQM.get("SQM2_AVI4").getElement(0);
            MultiSiteWaveDouble w200_sqmg4 = measWaveformSQM.get("SQM3_AVI5").getElement(0);
            MultiSiteWaveDouble w200_sqmg5 = measWaveformSQM.get("SQM3_AVI6").getElement(0);
            MultiSiteWaveDouble w200_sqmg6 = measWaveformSQM.get("SQM4_AVI7").getElement(0);
            MultiSiteWaveDouble w200_sqmg7 = measWaveformSQM.get("SQM4_AVI8").getElement(0);
            MultiSiteWaveDouble w200_sqps1 = measWaveformSQP.get("SQP1_AVI1").getElement(0);
            MultiSiteWaveDouble w200_sqpg1 = measWaveformSQP.get("SQP1_AVI2").getElement(0);
            MultiSiteWaveDouble w200_sqpg2 = measWaveformSQP.get("SQP2_AVI3").getElement(0);
            MultiSiteWaveDouble w200_sqpg3 = measWaveformSQP.get("SQP2_AVI4").getElement(0);
            MultiSiteWaveDouble w200_sqpg4 = measWaveformSQP.get("SQP3_AVI5").getElement(0);
            MultiSiteWaveDouble w200_sqpg5 = measWaveformSQP.get("SQP3_AVI6").getElement(0);
            MultiSiteWaveDouble w200_sqpg6 = measWaveformSQP.get("SQP4_AVI7").getElement(0);
            MultiSiteWaveDouble w200_sqpg7 = measWaveformSQP.get("SQP4_AVI8").getElement(0);
            println("------ SITE " + site + " ------");

            double totalCurrentSiteSQM = (Math.abs(w200_sqms1.getValue(125).get(site)
                    + w200_sqms1.getValue(130).get(site) + w200_sqms1.getValue(135).get(site)
                    + w200_sqms1.getValue(140).get(site) + w200_sqms1.getValue(145).get(site))
                    / 5.0)

                    + (Math.abs(
                            w200_sqmg1.getValue(125).get(site) + w200_sqmg1.getValue(130).get(site)
                                    + w200_sqmg1.getValue(135).get(site)
                                    + w200_sqmg1.getValue(140).get(site)
                                    + w200_sqmg1.getValue(145).get(site))
                            / 5.0)

                    + (Math.abs(
                            w200_sqmg2.getValue(125).get(site) + w200_sqmg2.getValue(130).get(site)
                                    + w200_sqmg2.getValue(135).get(site)
                                    + w200_sqmg2.getValue(140).get(site)
                                    + w200_sqmg2.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqmg3.getValue(125).get(site) + w200_sqmg3.getValue(130).get(site)
                                    + w200_sqmg3.getValue(135).get(site)
                                    + w200_sqmg3.getValue(140).get(site)
                                    + w200_sqmg3.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqmg4.getValue(125).get(site) + w200_sqmg4.getValue(130).get(site)
                                    + w200_sqmg4.getValue(135).get(site)
                                    + w200_sqmg4.getValue(140).get(site)
                                    + w200_sqmg4.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqmg5.getValue(125).get(site) + w200_sqmg5.getValue(130).get(site)
                                    + w200_sqmg5.getValue(135).get(site)
                                    + w200_sqmg5.getValue(140).get(site)
                                    + w200_sqmg5.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqmg6.getValue(125).get(site) + w200_sqmg6.getValue(130).get(site)
                                    + w200_sqmg6.getValue(135).get(site)
                                    + w200_sqmg6.getValue(140).get(site)
                                    + w200_sqmg6.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqmg7.getValue(125).get(site) + w200_sqmg7.getValue(130).get(site)
                                    + w200_sqmg7.getValue(135).get(site)
                                    + w200_sqmg7.getValue(140).get(site)
                                    + w200_sqmg7.getValue(145).get(site))
                            / 5.0);

            totalCurrentSQM.set(site, totalCurrentSiteSQM);

            // Print individual currents

            println("SQM1_AVI1 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqms1.getValue(125).get(site) + w200_sqms1.getValue(130).get(site)
                                    + w200_sqms1.getValue(135).get(site)
                                    + w200_sqms1.getValue(140).get(site)
                                    + w200_sqms1.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM1_AVI2 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg1.getValue(125).get(site) + w200_sqmg1.getValue(130).get(site)
                                    + w200_sqmg1.getValue(135).get(site)
                                    + w200_sqmg1.getValue(140).get(site)
                                    + w200_sqmg1.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM2_AVI3 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg2.getValue(125).get(site) + w200_sqmg2.getValue(130).get(site)
                                    + w200_sqmg2.getValue(135).get(site)
                                    + w200_sqmg2.getValue(140).get(site)
                                    + w200_sqmg2.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM2_AVI4 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg3.getValue(125).get(site) + w200_sqmg3.getValue(130).get(site)
                                    + w200_sqmg3.getValue(135).get(site)
                                    + w200_sqmg3.getValue(140).get(site)
                                    + w200_sqmg3.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM3_AVI5 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg4.getValue(125).get(site) + w200_sqmg4.getValue(130).get(site)
                                    + w200_sqmg4.getValue(135).get(site)
                                    + w200_sqmg4.getValue(140).get(site)
                                    + w200_sqmg4.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM3_AVI6 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg5.getValue(125).get(site) + w200_sqmg5.getValue(130).get(site)
                                    + w200_sqmg5.getValue(135).get(site)
                                    + w200_sqmg5.getValue(140).get(site)
                                    + w200_sqmg5.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM4_AVI7 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg6.getValue(125).get(site) + w200_sqmg6.getValue(130).get(site)
                                    + w200_sqmg6.getValue(135).get(site)
                                    + w200_sqmg6.getValue(140).get(site)
                                    + w200_sqmg6.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQM4_AVI8 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqmg7.getValue(125).get(site) + w200_sqmg7.getValue(130).get(site)
                                    + w200_sqmg7.getValue(135).get(site)
                                    + w200_sqmg7.getValue(140).get(site)
                                    + w200_sqmg7.getValue(145).get(site))
                            / 5.0)
                    + " A");

            totalCurrentSQM.set(site, totalCurrentPerSiteSQM);
            println("--------------------------------");
            println("Site " + site + " Total Current at SQP: " + totalCurrentPerSiteSQM + " A");

            double totalCurrentSiteSQP = (Math.abs(w200_sqps1.getValue(125).get(site)
                    + w200_sqps1.getValue(130).get(site) + w200_sqps1.getValue(135).get(site)
                    + w200_sqps1.getValue(140).get(site) + w200_sqps1.getValue(145).get(site))
                    / 5.0)

                    + (Math.abs(
                            w200_sqpg1.getValue(125).get(site) + w200_sqpg1.getValue(130).get(site)
                                    + w200_sqpg1.getValue(135).get(site)
                                    + w200_sqpg1.getValue(140).get(site)
                                    + w200_sqpg1.getValue(145).get(site))
                            / 5.0)

                    + (Math.abs(
                            w200_sqpg2.getValue(125).get(site) + w200_sqpg2.getValue(130).get(site)
                                    + w200_sqpg2.getValue(135).get(site)
                                    + w200_sqpg2.getValue(140).get(site)
                                    + w200_sqpg2.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqpg3.getValue(125).get(site) + w200_sqpg3.getValue(130).get(site)
                                    + w200_sqpg3.getValue(135).get(site)
                                    + w200_sqpg3.getValue(140).get(site)
                                    + w200_sqpg3.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqpg4.getValue(125).get(site) + w200_sqpg4.getValue(130).get(site)
                                    + w200_sqpg4.getValue(135).get(site)
                                    + w200_sqpg4.getValue(140).get(site)
                                    + w200_sqpg4.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqpg5.getValue(125).get(site) + w200_sqpg5.getValue(130).get(site)
                                    + w200_sqpg5.getValue(135).get(site)
                                    + w200_sqpg5.getValue(140).get(site)
                                    + w200_sqpg5.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqpg6.getValue(125).get(site) + w200_sqpg6.getValue(130).get(site)
                                    + w200_sqpg6.getValue(135).get(site)
                                    + w200_sqpg6.getValue(140).get(site)
                                    + w200_sqpg6.getValue(145).get(site))
                            / 5.0)
                    + (Math.abs(
                            w200_sqpg7.getValue(125).get(site) + w200_sqpg7.getValue(130).get(site)
                                    + w200_sqpg7.getValue(135).get(site)
                                    + w200_sqpg7.getValue(140).get(site)
                                    + w200_sqpg7.getValue(145).get(site))
                            / 5.0);

            totalCurrentSQP.set(site, totalCurrentSiteSQP);

            // Print individual currents

            println("SQP1_AVI1 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqps1.getValue(125).get(site) + w200_sqps1.getValue(130).get(site)
                                    + w200_sqps1.getValue(135).get(site)
                                    + w200_sqps1.getValue(140).get(site)
                                    + w200_sqps1.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP1_AVI2 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg1.getValue(125).get(site) + w200_sqpg1.getValue(130).get(site)
                                    + w200_sqpg1.getValue(135).get(site)
                                    + w200_sqpg1.getValue(140).get(site)
                                    + w200_sqpg1.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP2_AVI3 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg2.getValue(125).get(site) + w200_sqpg2.getValue(130).get(site)
                                    + w200_sqpg2.getValue(135).get(site)
                                    + w200_sqpg2.getValue(140).get(site)
                                    + w200_sqpg2.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP2_AVI4 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg3.getValue(125).get(site) + w200_sqpg3.getValue(130).get(site)
                                    + w200_sqpg3.getValue(135).get(site)
                                    + w200_sqpg3.getValue(140).get(site)
                                    + w200_sqpg3.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP3_AVI5 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg4.getValue(125).get(site) + w200_sqpg4.getValue(130).get(site)
                                    + w200_sqpg4.getValue(135).get(site)
                                    + w200_sqpg4.getValue(140).get(site)
                                    + w200_sqpg4.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP3_AVI6 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg5.getValue(125).get(site) + w200_sqpg5.getValue(130).get(site)
                                    + w200_sqpg5.getValue(135).get(site)
                                    + w200_sqpg5.getValue(140).get(site)
                                    + w200_sqpg5.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP4_AVI7 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg6.getValue(125).get(site) + w200_sqpg6.getValue(130).get(site)
                                    + w200_sqpg6.getValue(135).get(site)
                                    + w200_sqpg6.getValue(140).get(site)
                                    + w200_sqpg6.getValue(145).get(site))
                            / 5.0)
                    + " A");
            println("SQP4_AVI8 Absolute Average Current = " + "at site :" + site + " is :"
                    + (Math.abs(
                            w200_sqpg7.getValue(125).get(site) + w200_sqpg7.getValue(130).get(site)
                                    + w200_sqpg7.getValue(135).get(site)
                                    + w200_sqpg7.getValue(140).get(site)
                                    + w200_sqpg7.getValue(145).get(site))
                            / 5.0)
                    + " A");

            totalCurrentSQP.set(site, totalCurrentPerSiteSQP);
            println("--------------------------------");
            println("Site " + site + " Total Current at SQM: " + totalCurrentPerSiteSQP + " A");

        }

        println("Final Total Current (All Sites): " + totalCurrentSQP);
        println("Final Total Current (All Sites): " + totalCurrentSQM);

        finalResults.put("SQM1_AVI1", totalCurrentSQM);
        finalResults.put("SQP1_AVI1", totalCurrentSQP);

        println(finalResults);

        ptdDC.evaluate(finalResults, measurement);

        println("\n<------- Gross Funcional Test Arm Low Lfire High Hfire High END ------->\n");

    }

}
