package grossFunctional.tml;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : GrossFunctionalTest
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Apply VDD, VDDQ, SQP, SQM, ARM, LFIRE/HFIRE, and ISET conditions.
 * 2. Measure static current for the first four conditions.
 * 3. Measure current waveforms for the remaining six conditions.
 * 4. Calculate total SQP and SQM current for each condition.
 * 5. Datalog gross-functional current results.
 */
public class GrossFunctionalTest extends TestMethod {

    // Parametric Test Descriptors for each gross-functional condition (loaded directly from Test Table)
    // Condition 1: ISET=100uA, ARM=0V, LFIRE=0V, HFIRE=0V (Static Quiescent)
    public IParametricTestDescriptor ptd_SQP_C1;  // Test 8000: SQP
    public IParametricTestDescriptor ptd_SQM_C1;  // Test 8010: SQM

    // Condition 2: ISET=100uA, ARM=0V, LFIRE=5.5V, HFIRE=0V (Static Interlock Check)
    public IParametricTestDescriptor ptd_SQP_C2;  // Test 8020: SQP
    public IParametricTestDescriptor ptd_SQM_C2;  // Test 8030: SQM

    // Condition 3: ISET=100uA, ARM=0V, LFIRE=0V, HFIRE=5.5V (Static Interlock Check)
    public IParametricTestDescriptor ptd_SQP_C3;  // Test 8040: SQP
    public IParametricTestDescriptor ptd_SQM_C3;  // Test 8050: SQM

    // Condition 4: ISET=100uA, ARM=0V, LFIRE=5.5V, HFIRE=5.5V (Static Interlock Check)
    public IParametricTestDescriptor ptd_SQP_C4;  // Test 8060: SQP
    public IParametricTestDescriptor ptd_SQM_C4;  // Test 8070: SQM

    // Condition 5: ISET=100uA, ARM=5.5V, LFIRE=0V_WF, HFIRE=0V_WF (Waveform Armed Quiescent)
    public IParametricTestDescriptor ptd_SQP_C5;  // Test 8080: SQP
    public IParametricTestDescriptor ptd_SQM_C5;  // Test 8090: SQM

    // Condition 6: ISET=100uA, ARM=5.5V, LFIRE=5.5V_WF, HFIRE=0V_WF (Waveform Low-Side Fire)
    public IParametricTestDescriptor ptd_SQP_C6;  // Test 8100: SQP
    public IParametricTestDescriptor ptd_SQM_C6;  // Test 8110: SQM

    // Condition 7: ISET=100uA, ARM=5.5V, LFIRE=0V_WF, HFIRE=5.5V_WF (Waveform High-Side Fire)
    public IParametricTestDescriptor ptd_SQP_C7;  // Test 8120: SQP
    public IParametricTestDescriptor ptd_SQM_C7;  // Test 8130: SQM

    // Condition 8: ISET=10uA, ARM=5.5V, LFIRE=0V_WF, HFIRE=0V_WF (Waveform Armed Quiescent @ 10uA)
    public IParametricTestDescriptor ptd_SQP_C8;  // Test 8140: SQP
    public IParametricTestDescriptor ptd_SQM_C8;  // Test 8150: SQM

    // Condition 9: ISET=10uA, ARM=5.5V, LFIRE=5.5V_WF, HFIRE=0V_WF (Waveform Low-Side Fire @ 10uA)
    public IParametricTestDescriptor ptd_SQP_C9;  // Test 8160: SQP
    public IParametricTestDescriptor ptd_SQM_C9;  // Test 8170: SQM

    // Condition 10: ISET=10uA, ARM=5.5V, LFIRE=0V_WF, HFIRE=5.5V_WF (Waveform High-Side Fire @ 10uA)
    public IParametricTestDescriptor ptd_SQP_C10; // Test 8180: SQP
    public IParametricTestDescriptor ptd_SQM_C10; // Test 8190: SQM


    private static final int[] AVERAGE_SAMPLE_INDICES = {65, 70, 75, 80, 85};

    private static final String[] SQP_CHANNELS = {
            "SQP1_AVI1", "SQP1_AVI2", "SQP2_AVI3", "SQP2_AVI4",
            "SQP3_AVI5", "SQP3_AVI6", "SQP4_AVI7", "SQP4_AVI8"
    };

    private static final String[] SQM_CHANNELS = {
            "SQM1_AVI1", "SQM1_AVI2", "SQM2_AVI3", "SQM2_AVI4",
            "SQM3_AVI5", "SQM3_AVI6", "SQM4_AVI7", "SQM4_AVI8"
    };

    public IMeasurement measurement;

    /** Number of samples used for all waveform actions and measurements. */
    public int waveformSamples = 100;

    /** Sample rate used for all waveform actions and measurements, in Hz. */
    public double waveformSampleRate = 100e3;

    public String SQPGroup =
            "SQP1_AVI1 + SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + "
                    + "SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8";

    public String SQMGroup =
            "SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + "
                    + "SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 + SQM4_AVI8";

    public String VDDQGroup =
            "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + "
                    + "VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8";

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance(
                DSAGenerationMode.GENERATE_IN_FILE);

        ds.importSpec("common.pinGroups");

        String sqpAndSqmGroup = SQPGroup + " + " + SQMGroup;

        // Configure VDD.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.00125);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVddTo5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.00125)
                .setIclamp(0.00125);

        // Force VDD to 0 V for safe power-down.
        ISetupDcVI.IVforce forceVddTo0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.00125)
                .setIclamp(0.00125);

        // Configure VDDQGroup.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQGroup");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force VDDQGroup to 12 V (<=12V).
        ISetupDcVI.IVforce forceVddqGroupTo25V =
                vddqGroup.vforce("force_vddq_group_25V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);
        forceVddqGroupTo25V.regulation().setVslewrate(100e3);

        // Force VDDQGroup to 0 V for safe power-down.
        ISetupDcVI.IVforce forceVddqGroupTo0V =
                vddqGroup.vforce("force_vddq_group_0V")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);
        forceVddqGroupTo0V.regulation().setVslewrate(100e3);

        // Configure combined SQP and SQM groups.
        ISetupDcVI sqpAndSqmPins = ds.addDcVI(sqpAndSqmGroup);
        sqpAndSqmPins.setConnect(true).setDisconnect(true);

        // Force selected SQP and SQM pins to 0 V with 100mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo0VWith100mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_0V_with_100mA_clamp")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.1 / 8.0);
        forceSqpSqmTo0VWith100mAClamp.regulation().setVslewrate(100e3);


        // Force selected SQP and SQM pins to 12 V with 100mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo25VWith100mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_25V_with_100mA_clamp")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.1 / 8.0);
        forceSqpSqmTo25VWith100mAClamp.regulation().setVslewrate(100e3);

     // Force selected SQP and SQM pins to 0 V with 200mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo0VWith200mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_0V_with_200mA_clamp")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.2 / 8.0);
        forceSqpSqmTo0VWith200mAClamp.regulation().setVslewrate(100e3);

        // Force selected SQP and SQM pins to 12 V with 200mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo25VWith200mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_25V_with_200mA_clamp")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.2 / 8.0);
        forceSqpSqmTo25VWith200mAClamp.regulation().setVslewrate(100e3);

        // Measure static current on SQP and SQM channels.
        ISetupDcVI.IImeas measureSqpSqmCurrent =
                sqpAndSqmPins.imeas("measure_sqp_sqm_current")
                        .setIrange(0.05);

        // Measure current waveform on SQP and SQM channels.
        ISetupDcVI.IMeasureWaveform measureSqpSqmCurrentWaveform =
                sqpAndSqmPins.measureWaveform("measure_sqp_sqm_current_waveform")
                        .setMeasTypeCurrent()
                        .setIrange(0.05)
                        .setSamples(waveformSamples)
                        .setSampleRate(waveformSampleRate);

        // Configure ARM.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM to 5.5 V.
        ISetupDcVI.IVforce forceArmTo5p5V = arm.vforce("force_arm_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Force ARM to 0 V.
        ISetupDcVI.IVforce forceArmTo0V = arm.vforce("force_arm_0V")
                .setForceValue(0.0)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Create a 5.5 V waveform.
        ISetupWaveformDc waveform5p5V = ds.addWaveformDc("waveform_5p5V")
                .setDcValue(5.5)
                .setSamples(waveformSamples)
                .setSampleRate(waveformSampleRate);

        // Create a 0 V waveform.
        ISetupWaveformDc waveform0V = ds.addWaveformDc("waveform_0V")
                .setDcValue(0.0)
                .setSamples(waveformSamples)
                .setSampleRate(waveformSampleRate);

        // Configure LFIRE and HFIRE as one setup group.
        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        // Force selected LFIRE/HFIRE signal to 5.5 V.
        ISetupDcVI.IVforce forceLfireHfireTo5p5V =
                lfireHfire.vforce("force_lfire_hfire_5p5V")
                        .setForceValue(5.5)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Force selected LFIRE/HFIRE signal to 0 V.
        ISetupDcVI.IVforce forceLfireHfireTo0V =
                lfireHfire.vforce("force_lfire_hfire_0V")
                        .setForceValue(0.0)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Apply a 5.5 V waveform on selected LFIRE/HFIRE signal.
        ISetupDcVI.ISourceWaveform sourceLfireHfire5p5VWaveform =
                lfireHfire.sourceWaveform("source_lfire_hfire_5p5V_waveform")
                        .setForceTypeVoltage()
                        .setWaveform(waveform5p5V)
                        .setIclamp(0.001)
                        .setIrange(0.001);

        // Apply a 0 V waveform on selected LFIRE/HFIRE signal.
        ISetupDcVI.ISourceWaveform sourceLfireHfire0VWaveform =
                lfireHfire.sourceWaveform("source_lfire_hfire_0V_waveform")
                        .setForceTypeVoltage()
                        .setWaveform(waveform0V)
                        .setIclamp(0.001)
                        .setIrange(0.001);

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);


        ISetupUtility k11 = ds.addUtility("K11_SQP4_GND");
        ISetupUtility.ISetState k11_1 = k11.setState("k11_1").setValue(1).setSettlingTime(0.01);
        ISetupUtility.ISetState k11_0 = k11.setState("k11_0").setValue(0).setSettlingTime(0.01);


        // Configure ISET.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force 100 uA on ISET.
        ISetupAction forceIset100uA = iset.iforce("force_iset_100uA")
                .setForceValue(-100e-6)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Force 10 uA on ISET.
        ISetupAction forceIset10uA = iset.iforce("force_iset_10uA")
                .setForceValue(-10e-6)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Force 0 A on ISET for safe power-down.
        ISetupAction forceIset0A = iset.iforce("force_iset_0A")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        ds.sequentialBegin("GrossFunctionalTest");
        {
            // Dynamic relay control: connect VSS to GND, connect ISET to PS
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.actionCall(k11_1);
            ds.waitCall(0.020);

            // Condition 1: ISET = 100 uA, ARM = 0 V, LFIRE = 0 V, HFIRE = 0 V.
            ds.parallelBegin("condition_1_static");
            {
                ds.sequentialBegin("condition_1_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.waitCall(0.020);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("HFIRE_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 2: ISET = 100 uA, ARM = 0 V, LFIRE = 5.5 V, HFIRE = 0 V.
            ds.parallelBegin("condition_2_static");
            {
                ds.sequentialBegin("condition_2_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("HFIRE_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 3: ISET = 100 uA, ARM = 0 V, LFIRE = 0 V, HFIRE = 5.5 V.
            ds.parallelBegin("condition_3_static");
            {
                ds.sequentialBegin("condition_3_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("HFIRE_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 4: ISET = 100 uA, ARM = 0 V, LFIRE = 5.5 V, HFIRE = 5.5 V.
            ds.parallelBegin("condition_4_static");
            {
                ds.sequentialBegin("condition_4_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("HFIRE_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 5: ISET = 100 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_5_waveform");
            {
                ds.sequentialBegin("condition_5_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.waitCall(0.020);

                    ds.parallelBegin("condition_5_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current_waveform");
                        {
                            ds.actionCall(
                                    "measure_sqp_sqm_current_waveform",
                                    Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 6: ISET = 100 uA, ARM = 5.5 V, LFIRE waveform = 5.5 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_6_waveform");
            {
                ds.sequentialBegin("condition_6_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.waitCall(0.020);

                    ds.parallelBegin("condition_6_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current_waveform");
                        {
                            ds.actionCall(
                                    "measure_sqp_sqm_current_waveform",
                                    Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 7: ISET = 100 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 5.5 V.
            ds.parallelBegin("condition_7_waveform");
            {
                ds.sequentialBegin("condition_7_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.waitCall(0.020);

                    ds.parallelBegin("condition_7_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current_waveform");
                        {
                            ds.actionCall(
                                    "measure_sqp_sqm_current_waveform",
                                    Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 8: ISET = 10 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_8_waveform");
            {
                ds.sequentialBegin("condition_8_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset10uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_200mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_200mA_clamp", Arrays.asList(SQMGroup));
                    ds.waitCall(0.020);

                    ds.parallelBegin("condition_8_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current_waveform");
                        {
                            ds.actionCall(
                                    "measure_sqp_sqm_current_waveform",
                                    Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 9: ISET = 10 uA, ARM = 5.5 V, LFIRE waveform = 5.5 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_9_waveform");
            {
                ds.sequentialBegin("condition_9_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset10uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_200mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_200mA_clamp", Arrays.asList(SQMGroup));
                    ds.waitCall(0.020);

                    ds.parallelBegin("condition_9_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current_waveform");
                        {
                            ds.actionCall(
                                    "measure_sqp_sqm_current_waveform",
                                    Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 10: ISET = 10 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 5.5 V.
            ds.parallelBegin("condition_10_waveform");
            {
                ds.sequentialBegin("condition_10_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset10uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_200mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_200mA_clamp", Arrays.asList(SQMGroup));
                    ds.waitCall(0.020);

                    ds.parallelBegin("condition_10_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current_waveform");
                        {
                            ds.actionCall(
                                    "measure_sqp_sqm_current_waveform",
                                    Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Safe shutdown: return supplies and IOs to 0V before opening relays
            ds.actionCall(forceIset0A);
            ds.actionCall(forceArmTo0V);
            ds.actionCall(forceLfireHfireTo0V);
            ds.actionCall(forceVddTo0V);
            ds.actionCall(forceVddqGroupTo0V);
            ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(sqpAndSqmGroup));
            ds.waitCall(0.10);

            // Safe shutdown: turn off dynamic relays
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.actionCall(K4_ISET_PS_utility_0);
            ds.actionCall(k11_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {
        String[] conditionText = {
                "ISET=100uA_ARM=0V_LFIRE=0V_HFIRE=0V",
                "ISET=100uA_ARM=0V_LFIRE=5.5V_HFIRE=0V",
                "ISET=100uA_ARM=0V_LFIRE=0V_HFIRE=5.5V",
                "ISET=100uA_ARM=0V_LFIRE=5.5V_HFIRE=5.5V",
                "ISET=100uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=0V_WF",
                "ISET=100uA_ARM=5.5V_LFIRE=5.5V_WF_HFIRE=0V_WF",
                "ISET=100uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=5.5V_WF",
                "ISET=10uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=0V_WF",
                "ISET=10uA_ARM=5.5V_LFIRE=5.5V_WF_HFIRE=0V_WF",
                "ISET=10uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=5.5V_WF"
        };

        println("\n<------- Gross Functional Test START ------->\n");

        measurement.execute();

        IDcVIResults sqmResults = measurement.dcVI(SQMGroup).preserveResults();
        IDcVIResults sqpResults = measurement.dcVI(SQPGroup).preserveResults();

        Map<String, MultiSiteDoubleArray> sqmStaticCurrents = sqmResults.imeas("measure_sqp_sqm_current").getCurrent();

        Map<String, MultiSiteDoubleArray> sqpStaticCurrents = sqpResults.imeas("measure_sqp_sqm_current").getCurrent();

        Map<String, MultiSiteWaveDoubleArray> sqmWaveformCurrents = sqmResults.measureWaveform("measure_sqp_sqm_current_waveform").getWaveform();

        Map<String, MultiSiteWaveDoubleArray> sqpWaveformCurrents = sqpResults.measureWaveform("measure_sqp_sqm_current_waveform").getWaveform();

        MultiSiteDoubleArray totalSqmCurrent = new MultiSiteDoubleArray(10, 999);

        MultiSiteDoubleArray totalSqpCurrent = new MultiSiteDoubleArray(10, 999);

        for (int conditionIndex = 0; conditionIndex < 10; conditionIndex++) {
            boolean isStaticCondition = conditionIndex < 4;
            if (conditionIndex < 4) {
                totalSqmCurrent.setElement(conditionIndex, calculateStaticTotalCurrent(sqmStaticCurrents, conditionIndex));

                totalSqpCurrent.setElement(conditionIndex, calculateStaticTotalCurrent(sqpStaticCurrents, conditionIndex));
            } else {
                int waveformIndex = conditionIndex - 4;

                totalSqmCurrent.setElement(conditionIndex, calculateWaveformTotalCurrent(sqmWaveformCurrents, SQM_CHANNELS, waveformIndex));

                totalSqpCurrent.setElement(conditionIndex, calculateWaveformTotalCurrent(sqpWaveformCurrents, SQP_CHANNELS, waveformIndex));
            }
            println("--------------------------------------------------");
            println("Condition " + (conditionIndex + 1)
                    + (isStaticCondition ? " - Static Current Measurement" : " - Waveform Current Measurement"));
            println("SQP Total Current : " + totalSqpCurrent.getElement(conditionIndex) + " A");
            println("SQM Total Current : " + totalSqmCurrent.getElement(conditionIndex) + " A");
        }

        Map<String, MultiSiteDoubleArray> finalResults = new HashMap<>();
        finalResults.put("SQM", totalSqmCurrent);
        finalResults.put("SQP", totalSqpCurrent);


        IParametricTestDescriptor[] ptdSQP = {
                ptd_SQP_C1, ptd_SQP_C2, ptd_SQP_C3, ptd_SQP_C4, ptd_SQP_C5,
                ptd_SQP_C6, ptd_SQP_C7, ptd_SQP_C8, ptd_SQP_C9, ptd_SQP_C10
        };

        IParametricTestDescriptor[] ptdSQM = {
                ptd_SQM_C1, ptd_SQM_C2, ptd_SQM_C3, ptd_SQM_C4, ptd_SQM_C5,
                ptd_SQM_C6, ptd_SQM_C7, ptd_SQM_C8, ptd_SQM_C9, ptd_SQM_C10
        };

        // Evaluate each condition directly against its individual Test Table descriptor
        for (int conditionIndex = 0; conditionIndex < 10; conditionIndex++) {
            if (ptdSQP[conditionIndex] != null) {
                ptdSQP[conditionIndex].evaluate(totalSqpCurrent, conditionIndex);
            }
            if (ptdSQM[conditionIndex] != null) {
                ptdSQM[conditionIndex].evaluate(totalSqmCurrent, conditionIndex);
            }
        }

        println("<------- Gross Functional Test END ------->\n");
    }

    private MultiSiteDouble calculateStaticTotalCurrent(
            Map<String, MultiSiteDoubleArray> measuredCurrents, int conditionIndex) {

        MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {
            double totalCurrentPerSite = 0.0;

            for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
                MultiSiteDouble measuredCurrent = entry.getValue().getElement(conditionIndex);

                totalCurrentPerSite += measuredCurrent.get(site);
            }

            totalCurrent.set(site, totalCurrentPerSite);
        }

        return totalCurrent;
    }

    private MultiSiteDouble calculateWaveformTotalCurrent(
            Map<String, MultiSiteWaveDoubleArray> measuredWaveforms, String[] channels,
            int waveformIndex) {

        MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {
            double totalCurrentPerSite = 0.0;

            for (String channel : channels) {
                MultiSiteWaveDouble waveform = measuredWaveforms.get(channel)
                        .getElement(waveformIndex);

                double averageCurrent = (waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                                + waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                                + waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                                + waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                                + waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                        / AVERAGE_SAMPLE_INDICES.length;

                totalCurrentPerSite += averageCurrent;
            }

            totalCurrent.set(site, totalCurrentPerSite);
        }

        return totalCurrent;
    }
}
