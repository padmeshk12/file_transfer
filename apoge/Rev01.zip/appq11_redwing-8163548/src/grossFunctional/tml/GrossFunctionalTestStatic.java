package grossFunctional.tml;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : GrossFunctionalTest
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Apply VDD, VDDQ, SQP, SQM, ARM, LFIRE/HFIRE, and ISET conditions.
 * 2. Measure static current for the first four conditions.
 * 3. Measure current waveforms for the remaining six conditions.
 * 4. Calculate total SQP and SQM current for each condition.
 * 5. Datalog gross-functional current results.
 */
public class GrossFunctionalTestStatic extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    /** Number of samples used for all waveform actions and measurements. */
    public int waveformSamples = 100;

    /** Sample rate used for all waveform actions and measurements, in Hz. */
    public double waveformSampleRate = 100e3;

    public String SQPGroup =
            "SQP1_AVI1 + SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + "
                    + "SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8";

    public String SQMGroup =
            "SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + "
                    + "SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 + SQM4_AVI8";

    public String VDDQGroup =
            "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + "
                    + "VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8";

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance(
                DSAGenerationMode.GENERATE_IN_FILE);

        ds.importSpec("common.pinGroups");

        String sqpAndSqmGroup = SQPGroup + " + " + SQMGroup;

        // Configure VDD.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.00125);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVddTo5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.00125)
                .setIclamp(0.00125);

        // Configure VDDQGroup.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQGroup");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force VDDQGroup to 25 V.
        ISetupDcVI.IVforce forceVddqGroupTo25V =
                vddqGroup.vforce("force_vddq_group_25V")
                        .setForceValue(25.0)
                        .setVrange(30.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);

        // Configure combined SQP and SQM groups.
        ISetupDcVI sqpAndSqmPins = ds.addDcVI(sqpAndSqmGroup);
        sqpAndSqmPins.setConnect(true).setDisconnect(true);

        // Force selected SQP and SQM pins to 0 V with 100mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo0VWith100mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_0V_with_100mA_clamp")
                        .setForceValue(0.0)
                        .setVrange(1.5)
                        .setIrange(0.05)
                        .setIclamp(0.1 / 8.0);

        // Force selected SQP and SQM pins to 25 V with 100mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo25VWith100mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_25V_with_100mA_clamp")
                        .setForceValue(25.0)
                        .setVrange(30.0)
                        .setIrange(0.05)
                        .setIclamp(0.1 / 8.0);

     // Force selected SQP and SQM pins to 0 V with 200mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo0VWith200mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_0V_with_200mA_clamp")
                        .setForceValue(0.0)
                        .setVrange(1.5)
                        .setIrange(0.05)
                        .setIclamp(0.2 / 8.0);

        // Force selected SQP and SQM pins to 25 V with 200mA clamp.
        ISetupDcVI.IVforce forceSqpSqmTo25VWith200mAClamp =
                sqpAndSqmPins.vforce("force_sqp_sqm_25V_with_200mA_clamp")
                        .setForceValue(25.0)
                        .setVrange(30.0)
                        .setIrange(0.05)
                        .setIclamp(0.2 / 8.0);

        // Measure static current on SQP and SQM channels.
        ISetupDcVI.IImeas measureSqpSqmCurrent =
                sqpAndSqmPins.imeas("measure_sqp_sqm_current")
                        .setIrange(0.05);

//        // Measure current waveform on SQP and SQM channels.
//        ISetupDcVI.IMeasureWaveform measureSqpSqmCurrentWaveform =
//                sqpAndSqmPins.measureWaveform("measure_sqp_sqm_current_waveform")
//                        .setMeasTypeCurrent()
//                        .setIrange(0.05)
//                        .setSamples(waveformSamples)
//                        .setSampleRate(waveformSampleRate);

        // Configure ARM.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM to 5.5 V.
        ISetupDcVI.IVforce forceArmTo5p5V = arm.vforce("force_arm_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Force ARM to 0 V.
        ISetupDcVI.IVforce forceArmTo0V = arm.vforce("force_arm_0V")
                .setForceValue(0.0)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Create a 5.5 V waveform.
        ISetupWaveformDc waveform5p5V = ds.addWaveformDc("waveform_5p5V")
                .setDcValue(5.5)
                .setSamples(waveformSamples)
                .setSampleRate(waveformSampleRate);

        // Create a 0 V waveform.
        ISetupWaveformDc waveform0V = ds.addWaveformDc("waveform_0V")
                .setDcValue(0.0)
                .setSamples(waveformSamples)
                .setSampleRate(waveformSampleRate);

        // Configure LFIRE and HFIRE as one setup group.
        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        // Force selected LFIRE/HFIRE signal to 5.5 V.
        ISetupDcVI.IVforce forceLfireHfireTo5p5V =
                lfireHfire.vforce("force_lfire_hfire_5p5V")
                        .setForceValue(5.5)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Force selected LFIRE/HFIRE signal to 0 V.
        ISetupDcVI.IVforce forceLfireHfireTo0V =
                lfireHfire.vforce("force_lfire_hfire_0V")
                        .setForceValue(0.0)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Apply a 5.5 V waveform on selected LFIRE/HFIRE signal.
        ISetupDcVI.ISourceWaveform sourceLfireHfire5p5VWaveform =
                lfireHfire.sourceWaveform("source_lfire_hfire_5p5V_waveform")
                        .setForceTypeVoltage()
                        .setWaveform(waveform5p5V)
                        .setIclamp(0.001)
                        .setIrange(0.001);

        // Apply a 0 V waveform on selected LFIRE/HFIRE signal.
        ISetupDcVI.ISourceWaveform sourceLfireHfire0VWaveform =
                lfireHfire.sourceWaveform("source_lfire_hfire_0V_waveform")
                        .setForceTypeVoltage()
                        .setWaveform(waveform0V)
                        .setIclamp(0.001)
                        .setIrange(0.001);

        // Configure the K4 relay to connect ISET to PS1600.
        ISetupUtility enableIsetRelay = ds.addUtility("K4_ISET_PS")
                .setValue(1);
        //Turn on the relay for VSS to connect to GND
        ISetupUtility vss_k5 = ds.addUtility("K5_VSS_GND").setValue(1);

        // Configure ISET.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force 100 uA on ISET.
        ISetupAction forceIset100uA = iset.iforce("force_iset_100uA")
                .setForceValue(100e-6)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Force 10 uA on ISET.
        ISetupAction forceIset10uA = iset.iforce("force_iset_10uA")
                .setForceValue(10e-6)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        ds.sequentialBegin("GrossFunctionalTest");
        {
            // Condition 1: ISET = 100 uA, ARM = 0 V, LFIRE = 0 V, HFIRE = 0 V.
            ds.parallelBegin("condition_1_static");
            {
                ds.sequentialBegin("condition_1_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("HFIRE_PS"));
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 2: ISET = 100 uA, ARM = 0 V, LFIRE = 5.5 V, HFIRE = 0 V.
            ds.parallelBegin("condition_2_static");
            {
                ds.sequentialBegin("condition_2_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("HFIRE_PS"));
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 3: ISET = 100 uA, ARM = 0 V, LFIRE = 0 V, HFIRE = 5.5 V.
            ds.parallelBegin("condition_3_static");
            {
                ds.sequentialBegin("condition_3_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_0V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("HFIRE_PS"));
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 4: ISET = 100 uA, ARM = 0 V, LFIRE = 5.5 V, HFIRE = 5.5 V.
            ds.parallelBegin("condition_4_static");
            {
                ds.sequentialBegin("condition_4_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo0V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("LFIRE_PS"));
                    ds.actionCall("force_lfire_hfire_5p5V", Arrays.asList("HFIRE_PS"));
                    ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 5: ISET = 100 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_5_waveform");
            {
                ds.sequentialBegin("condition_5_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));

                    ds.parallelBegin("condition_5_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current");
                        {
                            ds.waitCall(0.0005);
                            ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 6: ISET = 100 uA, ARM = 5.5 V, LFIRE waveform = 5.5 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_6_waveform");
            {
                ds.sequentialBegin("condition_6_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));

                    ds.parallelBegin("condition_6_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current");
                        {
                            ds.waitCall(0.0005);
                            ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 7: ISET = 100 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 5.5 V.
            ds.parallelBegin("condition_7_waveform");
            {
                ds.sequentialBegin("condition_7_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset100uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_100mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_100mA_clamp", Arrays.asList(SQMGroup));

                    ds.parallelBegin("condition_7_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current");
                        {
                            ds.waitCall(0.0005);
                            ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 8: ISET = 10 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_8_waveform");
            {
                ds.sequentialBegin("condition_8_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset10uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_200mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_200mA_clamp", Arrays.asList(SQMGroup));

                    ds.parallelBegin("condition_8_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current");
                        {
                            ds.waitCall(0.0005);
                            ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 9: ISET = 10 uA, ARM = 5.5 V, LFIRE waveform = 5.5 V, HFIRE waveform = 0 V.
            ds.parallelBegin("condition_9_waveform");
            {
                ds.sequentialBegin("condition_9_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset10uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_200mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_200mA_clamp", Arrays.asList(SQMGroup));

                    ds.parallelBegin("condition_9_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current");
                        {
                            ds.waitCall(0.0005);
                            ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Condition 10: ISET = 10 uA, ARM = 5.5 V, LFIRE waveform = 0 V, HFIRE waveform = 5.5 V.
            ds.parallelBegin("condition_10_waveform");
            {
                ds.sequentialBegin("condition_10_sequence");
                {
                    ds.actionCall(forceVddTo5p5V);
                    ds.actionCall(forceVddqGroupTo25V);
                    ds.actionCall(forceIset10uA);
                    ds.actionCall(forceArmTo5p5V);
                    ds.actionCall("force_sqp_sqm_0V_with_200mA_clamp", Arrays.asList(SQPGroup));
                    ds.actionCall("force_sqp_sqm_25V_with_200mA_clamp", Arrays.asList(SQMGroup));

                    ds.parallelBegin("condition_10_parallel");
                    {
                        ds.sequentialBegin("source_lfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_0V_waveform",
                                    Arrays.asList("LFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("source_hfire_waveform");
                        {
                            ds.actionCall(
                                    "source_lfire_hfire_5p5V_waveform",
                                    Arrays.asList("HFIRE_PS"));
                        }
                        ds.sequentialEnd();

                        ds.sequentialBegin("measure_current");
                        {
                            ds.waitCall(0.0005);
                            ds.actionCall("measure_sqp_sqm_current", Arrays.asList(sqpAndSqmGroup));
                        }
                        ds.sequentialEnd();
                    }
                    ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {
        String[] conditionText = {
                "ISET=100uA_ARM=0V_LFIRE=0V_HFIRE=0V",
                "ISET=100uA_ARM=0V_LFIRE=5.5V_HFIRE=0V",
                "ISET=100uA_ARM=0V_LFIRE=0V_HFIRE=5.5V",
                "ISET=100uA_ARM=0V_LFIRE=5.5V_HFIRE=5.5V",
                "ISET=100uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=0V_WF",
                "ISET=100uA_ARM=5.5V_LFIRE=5.5V_WF_HFIRE=0V_WF",
                "ISET=100uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=5.5V_WF",
                "ISET=10uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=0V_WF",
                "ISET=10uA_ARM=5.5V_LFIRE=5.5V_WF_HFIRE=0V_WF",
                "ISET=10uA_ARM=5.5V_LFIRE=0V_WF_HFIRE=5.5V_WF"
        };

        println("\n<------- Gross Functional Test START ------->\n");

        measurement.execute();

        IDcVIResults sqmResults = measurement.dcVI(SQMGroup).preserveResults();
        IDcVIResults sqpResults = measurement.dcVI(SQPGroup).preserveResults();

        Map<String, MultiSiteDoubleArray> sqmStaticCurrents = sqmResults.imeas("measure_sqp_sqm_current").getCurrent();

        Map<String, MultiSiteDoubleArray> sqpStaticCurrents = sqpResults.imeas("measure_sqp_sqm_current").getCurrent();

        MultiSiteDoubleArray totalSqmCurrent = new MultiSiteDoubleArray(10, 999);

        MultiSiteDoubleArray totalSqpCurrent = new MultiSiteDoubleArray(10, 999);

        for (int conditionIndex = 0; conditionIndex < 10; conditionIndex++) {

                totalSqmCurrent.setElement(conditionIndex, calculateStaticTotalCurrent(sqmStaticCurrents, conditionIndex));

                totalSqpCurrent.setElement(conditionIndex, calculateStaticTotalCurrent(sqpStaticCurrents, conditionIndex));

            println("--------------------------------------------------");
            println("Condition " + (conditionIndex + 1)
                    +" - Static Current Measurement:");
            println("SQP Total Current : " + totalSqpCurrent.getElement(conditionIndex) + " A");
            println("SQM Total Current : " + totalSqmCurrent.getElement(conditionIndex) + " A");
        }

        Map<String, MultiSiteDoubleArray> finalResults = new HashMap<>();
        finalResults.put("SQM", totalSqmCurrent);
        finalResults.put("SQP", totalSqpCurrent);


        int testNumber = ptdDC.getTestNumber();
        int testNumberFromTestTable = testNumber;

        // Preserve the existing datalog and test-number logic.
        for (int conditionIndex = 0; conditionIndex < 10; conditionIndex++) {
            ptdDC.setTestText("GROSS_FUNC_SQP__VDD=5.5V_VDDQ=25V_" + conditionText[conditionIndex])
            .setTestNumber(testNumber);

            ptdDC.evaluate(totalSqpCurrent, conditionIndex, measurement);

            testNumber += 10;

            ptdDC.setTestText("GROSS_FUNC_SQM__VDD=5.5V_VDDQ=25V_" + conditionText[conditionIndex])
            .setTestNumber(testNumber);

            ptdDC.evaluate(totalSqmCurrent, conditionIndex, measurement);

            testNumber += 10;
        }

        ptdDC.setTestText("GROSS_FUNCTIONAL__VDD=5.5V_VDDQ=25V").setTestNumber(testNumberFromTestTable);

        println("<------- Gross Functional Test END ------->\n");
    }

    private MultiSiteDouble calculateStaticTotalCurrent(
            Map<String, MultiSiteDoubleArray> measuredCurrents, int conditionIndex) {

        MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {
            double totalCurrentPerSite = 0.0;

            for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
                MultiSiteDouble measuredCurrent = entry.getValue().getElement(conditionIndex);

                totalCurrentPerSite += measuredCurrent.get(site);
            }

            totalCurrent.set(site, totalCurrentPerSite);
        }

        return totalCurrent;
    }
}
