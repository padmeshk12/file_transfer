package conty.tml;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Author = Monish/ANORA
 * P2P_Leakage - Pin to Pin Leakage Test
 *
 * Test Plan : Pin to Pin Leakage
 * Force +/-100mV on target group, 0V on neighbor group, measure leakage < 300nA.
 *
 * Only PS1600 channels used for SQM (SQM1_PS) and SQP (SQP1_PS) since all SQM/SQP channels are shorted on die.
 * VDD, VSS, VDDQ channels are supply/ground pins -> forced 0V throughout.
 *
 * ODD Group (green) : TEST_PS + TD_PS
 * EVEN Group (yellow): ISET_PS + LFIRE_PS + HFIRE_PS + ARM_PS + SQM1_PS + SQP1_PS
 *
 * Execution order: all POS (+100mV) first, then all NEG (-100mV).
 */
public class P2P_Leakage_Odd_Even extends TestMethod {

    public IMeasurement measurement;

    public IParametricTestDescriptor ptd_P2P_Leakage;

    public List<String> ODDGroup = Arrays.asList("TEST_PS", "TD_PS");
    public List<String> EVENGroup = Arrays.asList("ISET_PS", "LFIRE_PS", "HFIRE_PS", "ARM_PS", "SQM1_PS", "SQP1_PS");

    private final String ODD_GROUP_EXPR = String.join(" + ", ODDGroup);
    private final String EVEN_GROUP_EXPR = String.join(" + ", EVENGroup);

    private static final String GND_SUPPLY_EXPR =
            "VDD_PS + VDDQ1_AVI1 + VDDQ2_AVI3";

    private static final double V_FORCE_POS = 0.1;
    private static final double V_FORCE_NEG = -0.1;
    private static final double I_RANGE     = 2.0e-6;
    private static final double I_CLAMP     = 2.0e-6;

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        // Loadboard relays connecting PS1600 instruments to DUT pins
        ISetupUtility iset_k4 = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility vss_k6  = ds.addUtility("K6_VSS_PS").setValue(1);
        ISetupUtility sqm1_k7 = ds.addUtility("K7_SQM1_PS").setValue(1);
        ISetupUtility vdd_k9  = ds.addUtility("K9_VDD_PS").setValue(1);
        ISetupUtility sqp1_k13 = ds.addUtility("K13_SQP1_PS").setValue(1);

        ISetupDcVI oddGroup = ds.addDcVI(ODD_GROUP_EXPR);
        oddGroup.setConnect(true).setDisconnect(true);

        ISetupDcVI evenGroup = ds.addDcVI(EVEN_GROUP_EXPR);
        evenGroup.setConnect(true).setDisconnect(true);

        // Supply/ground pins at 0V throughout
        ISetupDcVI gndGroup = ds.addDcVI(GND_SUPPLY_EXPR);
        gndGroup.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce gndForce0V = gndGroup.vforce("gnd_force_0V").setForceValue(0.0).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);

        // ODD group actions
        ISetupDcVI.IVforce oddForcePos = oddGroup.vforce("odd_force_pos").setForceValue(V_FORCE_POS).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce oddForceNeg = oddGroup.vforce("odd_force_neg").setForceValue(V_FORCE_NEG).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce oddForce0V = oddGroup.vforce("odd_force_0V").setForceValue(0.0).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IImeas oddMeasPos = oddGroup.imeas("ODDPIN_POS").setIrange(I_RANGE).setRestoreIrange(false);
        ISetupDcVI.IImeas oddMeasNeg = oddGroup.imeas("ODDPIN_NEG").setIrange(I_RANGE).setRestoreIrange(false);

        // EVEN group actions
        ISetupDcVI.IVforce evenForcePos = evenGroup.vforce("even_force_pos").setForceValue(V_FORCE_POS).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce evenForceNeg = evenGroup.vforce("even_force_neg").setForceValue(V_FORCE_NEG).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce evenForce0V = evenGroup.vforce("even_force_0V").setForceValue(0.0).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IImeas evenMeasPos = evenGroup.imeas("EVENPIN_POS").setIrange(I_RANGE).setRestoreIrange(false);
        ISetupDcVI.IImeas evenMeasNeg = evenGroup.imeas("EVENPIN_NEG").setIrange(I_RANGE).setRestoreIrange(false);

        // POS first, NEG next. Supply/ground always 0V.
        ds.sequentialBegin("P2P_Leakage_Seq");
        {
            ds.actionCall(gndForce0V);

            ds.actionCall(oddForcePos);
            ds.actionCall(evenForce0V);
            ds.actionCall(oddMeasPos);

            ds.actionCall(oddForce0V);
            ds.actionCall(evenForcePos);
            ds.actionCall(evenMeasPos);

            ds.actionCall(oddForceNeg);
            ds.actionCall(evenForce0V);
            ds.actionCall(oddMeasNeg);

            ds.actionCall(oddForce0V);
            ds.actionCall(evenForceNeg);
            ds.actionCall(evenMeasNeg);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
    }

    @Override
    public void execute() {

        println("\n<------- P2P Leakage Test START ------->\n");

        measurement.execute();

        int testNumber = ptd_P2P_Leakage.getTestNumber();

        // 1. ODD Pins Leakage Datalogging (+100mV then -100mV)
        for (String pin : ODDGroup) {
            IDcVIResults res = measurement.dcVI(pin).preserveResults();

            // POS (+100mV)
            Map<String, MultiSiteDoubleArray> posMap = res.imeas("ODDPIN_POS").getCurrent();
            String testTextPos = "LEAKAGE/P2P/" + pin + "/100mV/0V/0V/ADJ=0V/";
            ptd_P2P_Leakage.setTestText(testTextPos).setTestNumber(testNumber);
            ptd_P2P_Leakage.evaluate(posMap, 0, measurement);
            println(testTextPos + " = " + posMap.get(pin).getElement(0).multiply(1e9) + " nA");
            testNumber += 10;

            // NEG (-100mV)
            Map<String, MultiSiteDoubleArray> negMap = res.imeas("ODDPIN_NEG").getCurrent();
            String testTextNeg = "LEAKAGE/P2P/" + pin + "/-100mV/0V/0V/ADJ=0V/";
            ptd_P2P_Leakage.setTestText(testTextNeg).setTestNumber(testNumber);
            ptd_P2P_Leakage.evaluate(negMap, 0, measurement);
            println(testTextNeg + " = " + negMap.get(pin).getElement(0).multiply(1e9) + " nA");
            testNumber += 10;
        }

        // 2. EVEN Pins Leakage Datalogging (+100mV then -100mV)
        for (String pin : EVENGroup) {
            IDcVIResults res = measurement.dcVI(pin).preserveResults();

            // POS (+100mV)
            Map<String, MultiSiteDoubleArray> posMap = res.imeas("EVENPIN_POS").getCurrent();
            String testTextPos = "LEAKAGE/P2P/" + pin + "/100mV/0V/0V/ADJ=0V/";
            ptd_P2P_Leakage.setTestText(testTextPos).setTestNumber(testNumber);
            ptd_P2P_Leakage.evaluate(posMap, 0, measurement);
            println(testTextPos + " = " + posMap.get(pin).getElement(0).multiply(1e9) + " nA");
            testNumber += 10;

            // NEG (-100mV)
            Map<String, MultiSiteDoubleArray> negMap = res.imeas("EVENPIN_NEG").getCurrent();
            String testTextNeg = "LEAKAGE/P2P/" + pin + "/-100mV/0V/0V/ADJ=0V/";
            ptd_P2P_Leakage.setTestText(testTextNeg).setTestNumber(testNumber);
            ptd_P2P_Leakage.evaluate(negMap, 0, measurement);
            println(testTextNeg + " = " + negMap.get(pin).getElement(0).multiply(1e9) + " nA");
            testNumber += 10;
        }

        println("\n<------- P2P Leakage Test END ------->\n");
    }
}
