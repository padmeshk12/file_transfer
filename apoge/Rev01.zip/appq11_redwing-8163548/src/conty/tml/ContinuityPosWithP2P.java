package conty.tml;

import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class ContinuityPosWithP2P extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    @Override
    public void setup() {
        // TODO Auto-generated method stub

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(1.5) .setIrange(0.025);

        ISetupDcVI.IVforce vddForce0V = vdd.vforce("vdd_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI vddq = ds.addDcVI("VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 +VDDQ1_AVI8");
        vddq.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce0V = vddq.vforce("vddq_force_0V").setForceValue(0.0)
                .setVrange(1.5).setIrange(0.05).setIclamp(0.05);




        ISetupDcVI sqp = ds.addDcVI("SQP1_AVI1 +SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 +SQP4_AVI8");
        sqp.setConnect(true).setDisconnect(true);

        ISetupDcVI.IIforce sqpForce150uA = sqp.iforce("sqp_force_150uA").setForceValue(0.000150/8.0).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce sqpForce0V = sqp.vforce("sqp_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas sqpMeasVolt = sqp.vmeas("sqpMeasCurr").setVrange(1.5);




        ISetupDcVI sqm = ds.addDcVI("SQM1_AVI1 +SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 +SQM4_AVI8");
        sqm.setConnect(true).setDisconnect(true);

        ISetupDcVI.IIforce sqmForce150uA = sqm.iforce("sqm_force_150uA").setForceValue(0.000150/8.0).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce sqmForce0V = sqp.vforce("sqm_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas sqmMeasVolt = sqm.vmeas("sqmMeasCurr").setVrange(1.5);



        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        ISetupAction isetCurrForce150uA = iset.iforce("iset_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce isetForce0V = iset.vforce("iset_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas isetMeasVolt = iset.vmeas("isetMeasVolt").setVrange(1.5).setHighAccuracy(false);



        ISetupDcVI test = ds.addDcVI("TEST_PS");
        test.setConnect(true).setDisconnect(true);

        ISetupAction testCurrForce150uA = test.iforce("test_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce testForce0V = test.vforce("test_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas testMeasVolt = test.vmeas("testMeasVolt").setVrange(1.5).setHighAccuracy(false);



        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        ISetupAction armCurrForce150uA = arm.iforce("arm_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce armForce0V = arm.vforce("arm_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas armMeasVolt = arm.vmeas("armMeasVolt").setVrange(1.5).setHighAccuracy(false);



        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);

        ISetupAction hfireCurrForce150uA = hfire.iforce("hfire_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce hfireForce0V = hfire.vforce("hfire_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas hfireMeasVolt = hfire.vmeas("hfireMeasVolt").setVrange(1.5).setHighAccuracy(false);



        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);

        ISetupAction lfireCurrForce150uA = lfire.iforce("lfire_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce lfireForce0V = lfire.vforce("lfire_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas lfireMeasVolt = lfire.vmeas("lfireMeasVolt").setVrange(1.5).setHighAccuracy(false);



        ISetupDcVI vss = ds.addDcVI("VSS_PS");
        vss.setConnect(true).setDisconnect(true);

        ISetupAction vssCurrForce150uA = vss.iforce("vss_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce vssForce0V = vss.vforce("vss_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas vssMeasVolt = vss.vmeas("vssMeasVolt").setVrange(1.5).setHighAccuracy(false);



        ISetupDcVI td = ds.addDcVI("TD_PS");
        td.setConnect(true).setDisconnect(true);

        ISetupAction tdCurrForce150uA = td.iforce("td_force_150uA").setForceValue(0.000150).setVrange(1.5)
                .setVclampHigh(1.5).setVclampLow(0.0);

        ISetupDcVI.IVforce tdForce0V = td.vforce("td_force_0V").setForceValue(0.0)
                .setIrange(0.025).setIclamp(0.025);

        ISetupDcVI.IVmeas tdMeasVolt = td.vmeas("tdMeasVolt").setVrange(1.5).setHighAccuracy(false);

            ds.parallelBegin("seqOdd");{
            ds.sequentialBegin("seqOdd");{

            // Set background configurations
            ds.actionCall(vddForce0V);
            ds.actionCall(vddqForce0V);
            ds.actionCall(vssForce0V);
            ds.actionCall(hfireForce0V);
            ds.actionCall(sqpForce0V);
            ds.actionCall(armForce0V);

            ds.parallelBegin("Par1");{
//                ds.sequentialBegin("seq2");{
//                    ds.actionCall(sqpForce150uA);
//                    ds.actionCall(sqpMeasVolt);
//                }
//                ds.sequentialEnd();
                ds.sequentialBegin("seq3");{
                    ds.actionCall(sqmForce150uA);
                    ds.actionCall(sqmMeasVolt);
                }
                ds.sequentialEnd();
                ds.sequentialBegin("seq4");{
                    ds.actionCall(isetCurrForce150uA);
                    ds.actionCall(isetMeasVolt);
                }
                ds.sequentialEnd();
                ds.sequentialBegin("seq5");{
                    ds.actionCall(testCurrForce150uA);
                    ds.actionCall(testMeasVolt);
                }
                ds.sequentialEnd();
//                ds.sequentialBegin("seq6");{
//                    ds.actionCall(armCurrForce150uA);
//                    ds.actionCall(armMeasVolt);
//                }
//                ds.sequentialEnd();
//                ds.sequentialBegin("seq7");{
//                    ds.actionCall(hfireCurrForce150uA);
//                    ds.actionCall(hfireMeasVolt);
//                }
//                ds.sequentialEnd();
                ds.sequentialBegin("seq8");{
                    ds.actionCall(lfireCurrForce150uA);
                    ds.actionCall(lfireMeasVolt);
                }
                ds.sequentialEnd();
//                ds.sequentialBegin("seq9");{
//                    ds.actionCall(vssCurrForce150uA);
//                    ds.actionCall(vssMeasVolt);
//                }
//                ds.sequentialEnd();
                ds.sequentialBegin("seq10");{
                    ds.actionCall(tdCurrForce150uA);
                    ds.actionCall(tdMeasVolt);
                }
                ds.sequentialEnd();

            }
            ds.parallelEnd();
            }
            ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("seqEven");{

            ds.sequentialBegin("seqEven");{

                // Set background configurations
                ds.actionCall(vddForce0V);
                ds.actionCall(vddqForce0V);
                ds.actionCall(isetForce0V);
                ds.actionCall(testForce0V);
                ds.actionCall(sqmForce0V);
                ds.actionCall(lfireForce0V);
                ds.actionCall(tdForce0V);

                ds.parallelBegin("Par1");{
                    ds.sequentialBegin("seq2");{
                        ds.actionCall(sqpForce150uA);
                        ds.actionCall(sqpMeasVolt);
                    }
                    ds.sequentialEnd();
//                    ds.sequentialBegin("seq3");{
//                        ds.actionCall(sqmForce150uA);
//                        ds.actionCall(sqmMeasVolt);
//                    }
//                    ds.sequentialEnd();
//                    ds.sequentialBegin("seq4");{
//                        ds.actionCall(isetCurrForce150uA);
//                        ds.actionCall(isetMeasVolt);
//                    }
//                    ds.sequentialEnd();
//                    ds.sequentialBegin("seq5");{
//                        ds.actionCall(testCurrForce150uA);
//                        ds.actionCall(testMeasVolt);
//                    }
//                    ds.sequentialEnd();
                    ds.sequentialBegin("seq6");{
                        ds.actionCall(armCurrForce150uA);
                        ds.actionCall(armMeasVolt);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq7");{
                        ds.actionCall(hfireCurrForce150uA);
                        ds.actionCall(hfireMeasVolt);
                    }
                    ds.sequentialEnd();
//                    ds.sequentialBegin("seq8");{
//                        ds.actionCall(lfireCurrForce150uA);
//                        ds.actionCall(lfireMeasVolt);
//                    }
//                    ds.sequentialEnd();
                    ds.sequentialBegin("seq9");{
                        ds.actionCall(vssCurrForce150uA);
                        ds.actionCall(vssMeasVolt);
                    }
                    ds.sequentialEnd();
//                    ds.sequentialBegin("seq10");{
//                        ds.actionCall(tdCurrForce150uA);
//                        ds.actionCall(tdMeasVolt);
//                    }
//                    ds.sequentialEnd();

                }
                ds.parallelEnd();
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();




        measurement.setSetups(ds);


    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

        println("\n<------- ContinuityPos Test START ------->\n");
        measurement.execute();

        /* get value results for all 'iforceVmeas' actions defined in the specification */
        IDcVIResults results = measurement.dcVI("").preserveResults();


        Map<String, MultiSiteDoubleArray> vMeasResults = results.vmeas("").getVoltage();

        println("The Measured Voltages at all pins is : " + vMeasResults + "V" );

        ptdDC.evaluate(vMeasResults,0,measurement);


    }

}
