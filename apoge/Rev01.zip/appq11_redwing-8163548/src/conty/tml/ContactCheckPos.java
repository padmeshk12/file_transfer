package conty.tml;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Positive continuity test for supply and control pins.
 *
 * <p>VDD and VDDQ are forced to 0 V. A positive current is forced on each
 * continuity pin, and the measured voltage is evaluated.
 */
public class ContactCheckPos extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;
    private static Map<String, Map<String, MultiSiteDoubleArray>> storedPreResults = new ConcurrentHashMap<>();

    public List<String> SQPGroup = Arrays.asList("SQP1_AVI1", "SQP1_AVI2", "SQP2_AVI3", "SQP2_AVI4",
            "SQP3_AVI5", "SQP3_AVI6", "SQP4_AVI7", "SQP4_AVI8" );

    public List<String> SQMGroup = Arrays.asList("SQM1_AVI1" , "SQM1_AVI2" , "SQM2_AVI3" , "SQM2_AVI4" ,
    "SQM3_AVI5" , "SQM3_AVI6" , "SQM4_AVI7" , "SQM4_AVI8" );

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        // Configure VDD and its operating range.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(1.5).setIrange(0.00025);

        // Force VDD to 0 V during the continuity test.
        ISetupDcVI.IVforce forceVddTo0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.00025)
                .setIclamp(0.00025);

        // Configure VDDQ and its operating range.
        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(true);

        // Force VDDQ to 0 V during the continuity test.
        ISetupDcVI.IVforce forceVddqTo0V = vddq.vforce("force_vddq_0V")
                .setForceValue(0.0)
                .setVrange(1.5)
                .setIrange(0.0005)
                .setIclamp(0.0005);

        // Configure SQP; 150 uA is shared across eight AVI channels.
        ISetupDcVI sqp = ds.addDcVI("SQPGroup");
        sqp.setConnect(true).setDisconnect(true);

        // Force +150 uA total current on SQP.
        ISetupDcVI.IIforce forceSqp150uA = sqp.iforce("force_sqp_150uA")
                .setForceValue(0.000150)
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);
        //disconnect sqp
        ISetupDcVI.IDisconnect disConnectsqp = sqp.disconnect("disconnect_sqp");

        // Measure voltage on SQP.
        ISetupDcVI.IVmeas measureSqpVoltage = sqp.vmeas("measure_sqp_voltage")
                .setVrange(1.5);


        // Configure SQM; 150 uA is shared across eight AVI channels.
        ISetupDcVI sqm = ds.addDcVI("SQMGroup");
        sqm.setConnect(true).setDisconnect(true);

        // Force +150 uA total current on SQM.
        ISetupDcVI.IIforce forceSqm150uA = sqm.iforce("force_sqm_150uA")
                .setForceValue(0.000150 )
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);


        // Measure voltage on SQM.
        ISetupDcVI.IVmeas measureSqmVoltage = sqm.vmeas("measure_sqm_voltage")
                .setVrange(1.5);
        //disconnect sqm
        ISetupDcVI.IDisconnect disConnectsqm = sqm.disconnect("disconnect_sqm");


//        ISetupUtility.ISetState k4_ISET_utility_0 = null;
//        ISetupUtility.ISetState k4_ISET_utility_1 = null;
        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K4_ISET_PS").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        ISetupUtility iset_k4 = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState k4_ISET_utility_0 = iset_k4.setState("k4_ISET_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState k4_ISET_utility_1= iset_k4.setState("k4_ISET_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility.ISetState K5_VSS_GND_utility_0 = null;
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = null;
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        K5_VSS_GND_utility_1= K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

//        ISetupUtility.ISetState K6_VSS_PS_utility_0 = null;
//        ISetupUtility.ISetState K6_VSS_PS_utility_1 = null;
        ISetupUtility K6_VSS_PS_turnon = ds.addUtility("K6_VSS_PS");
        ISetupUtility.ISetState K6_VSS_PS_utility_0 = K6_VSS_PS_turnon.setState("K6_VSS_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K6_VSS_PS_utility_1= K6_VSS_PS_turnon.setState("K6_VSS_PS_utility_1").setValue(1).setSettlingTime(0.02);


        // Configure IO pins for continuity measurement.
        ISetupDcVI io = ds.addDcVI("CONTYPOS_IO" + "+" + "VSS_PS");
        io.setConnect(true).setDisconnect(true);

        // Force +150 uA current on IO pins.
        ISetupAction forceIO150uA = io.iforce("force_io_150uA")
                .setForceValue(0.000150)
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0)
                .setKeepVclampEnabled();

        // Measure voltage on IO pins.
        ISetupDcVI.IVmeas measureIOVoltage = io.vmeas("measure_io_voltage")
                .setVrange(1.5)
                .setHighAccuracy(false);

        ds.sequentialBegin("ContinuityPos");
        {

            ds.actionCall(k4_ISET_utility_1);
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.actionCall(K6_VSS_PS_utility_1);
            ds.waitCall(0.010);
        ds.actionCall(forceVddTo0V);
        ds.actionCall(forceVddqTo0V);
        ds.waitCall(0.010);
        ds.parallelBegin("parallel_continuity_measurements");
        {
            ds.sequentialBegin("measure_sqp_serial");{
            for (String channel : SQPGroup) {
                ds.actionCall(disConnectsqp);
                ds.actionCall("force_sqp_150uA", Arrays.asList(channel));
                ds.waitCall(0.010);
                ds.actionCall("measure_sqp_voltage", Arrays.asList(channel));
            }
            }
            ds.sequentialEnd();
            ds.sequentialBegin("measure_sqm_serial");{
                for (String channel : SQMGroup) {
                    ds.actionCall(disConnectsqm);
                    ds.actionCall("force_sqm_150uA", Arrays.asList(channel));
                    ds.waitCall(0.010);
                    ds.actionCall("measure_sqm_voltage", Arrays.asList(channel));
                }
                }
                ds.sequentialEnd();

//            ds.sequentialBegin("measure_io");
//            {
//                ds.actionCall(forceIO150uA);
//                ds.waitCall(0.010);
//                ds.actionCall(measureIOVoltage);
//            }
//            ds.sequentialEnd();
        }
        ds.parallelEnd();


        ds.actionCall(k4_ISET_utility_0);
        ds.actionCall(K5_VSS_GND_utility_0);
        ds.actionCall(K6_VSS_PS_utility_0);
        ds.waitCall(0.010);
        ds.sequentialEnd();

        }
        measurement.setSetups(ds);





//        ISetupUtility iset_k4_finaloff = ds.addUtility("K4_ISET_PS").setValue(0);
//        //Turn on the relay for VSS to connect to PS1600
////        ISetupUtility vss_k5_on = ds.addUtility("K5_VSS_GND").setValue(1);
//        ISetupUtility vss_k5_finaloff = ds.addUtility("K5_VSS_GND").setValue(0);
//        ISetupUtility vss_k6_finaloff = ds.addUtility("K6_VSS_PS").setValue(0);
////        ISetupUtility res4k_k2 = ds.addUtility("K2_ISET_R4K").setValue(1);

    }


    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- ContinuityPos Test START ------->\n");


        measurement.execute();


        // Preserve all DCVI voltage measurements before evaluating individual pins.
        IDcVIResults results = measurement.dcVI("").preserveResults();
        Map<String, MultiSiteDoubleArray> measuredVoltages = results.vmeas("").getVoltage();


        int testNumberFromTesttable = ptdDC.getTestNumber();



        int testNumber = ptdDC.getTestNumber();

        for (Entry<String, MultiSiteDoubleArray> entry : measuredVoltages.entrySet()) {

            String pinOrGroupName = entry.getKey();

            MultiSiteDoubleArray voltage = entry.getValue();

            // Assign the test name and number for the current result.
            ptdDC.setTestText("CONTACT_CHECK_POS__" + pinOrGroupName + "=150uA_VDD=0V_VDDQ=0V")
                    .setTestNumber(testNumber);

            // Evaluate the measured continuity voltage.
            ptdDC.evaluate(voltage, 0, measurement);

            // Print the measured voltage for the current pin or pin group.
            println("Measured Contact Check Pos voltage on "
                    + pinOrGroupName + ": " + voltage + " V");

            // Reserve ten test-number slots per measured pin or pin group.
            testNumber += 10;
        }

        ptdDC.setTestText("CONTACT_CHECK_POS__150uA_VDD=0V_VDDQ=0V")
        .setTestNumber(testNumberFromTesttable);

        println("\n<------- ContactCheckPos Test END ------->\n");
    }
}
