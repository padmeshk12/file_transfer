package conty.tml;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Author = Monish/ANORA
 * P2P_Leakage - Pin to Pin Leakage Test
 *
 * Test Plan : Pin to Pin Leakage
 * Force +/-100mV on target group, 0V on neighbor group, measure leakage < 300nA.
 *
 * Only PS1600 channels used for SQM (SQM1_PS) and SQP (SQP1_PS) since all SQM/SQP channels are shorted on die.
 * VDD, VSS, VDDQ channels are supply/ground pins -> forced 0V throughout.
 *
 * ODD Group (green) : TEST_PS + TD_PS
 * EVEN Group (yellow): ISET_PS + LFIRE_PS + HFIRE_PS + ARM_PS + SQM1_PS + SQP1_PS
 *
 * Execution order: all POS (+100mV) first, then all NEG (-100mV).
 */
public class P2P_Leakage extends TestMethod {

    public IMeasurement measurement;

    public IParametricTestDescriptor ptd_P2P_Leakage;
    private static Map<String, Map<String, MultiSiteDoubleArray>> storedPreResults = new ConcurrentHashMap<>();
    private static volatile Double preLowLimit = null;
    private static volatile Double preHighLimit = null;


    public List<String> ODDGroup = Arrays.asList("TEST_PS" /* , "TD_PS" */ );
    public List<String> EVENGroup = Arrays.asList("ISET_PS", "LFIRE_PS", "HFIRE_PS", "ARM_PS", "SQM1_PS", "SQP1_PS");

    private final String ODD_GROUP_EXPR = String.join(" + ", ODDGroup);
    private final String EVEN_GROUP_EXPR = String.join(" + ", EVENGroup);

    private static final String GND_SUPPLY_EXPR =
            "VDD_PS + VDDQ1_AVI1 + VDDQ2_AVI3";

    private static final double V_FORCE_POS = 0.1;
    private static final double V_FORCE_NEG = -0.1;
    private static final double I_RANGE     = 10e-6   /* 10e-6*/ ;
    private static final double I_CLAMP =  10e-6      /*10e-6*/ ;

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

         // =========================================================================
         // K4: K4_ISET_PS (Connects ISET to tester PS)
         // =========================================================================
        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_turnoff = K4_ISET_PS.setState("k4_ISET_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_turnon= K4_ISET_PS.setState("k4_ISET_utility_1").setValue(1).setSettlingTime(0.02);

        // =========================================================================
        // K5: K5_VSS_GND (Connects VSS to GND)
        // =========================================================================
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND").setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_turnoff = K5_VSS_GND.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_turnon = K5_VSS_GND.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

       // =========================================================================
       // K7: K7_SQM1_PS (Connects SQM1 to tester PS)
       // =========================================================================

       ISetupUtility K7_SQM1_PS = ds.addUtility("K7_SQM1_PS").setValue(1);
       ISetupUtility.ISetState K7_SQM1_PS_turnoff = K7_SQM1_PS.setState("K7_SQM1_PS_utility_0").setValue(0).setSettlingTime(0.02);
       ISetupUtility.ISetState K7_SQM1_PS_turnon = K7_SQM1_PS.setState("K7_SQM1_PS_utility_1").setValue(1).setSettlingTime(0.02);

        // =========================================================================
        // K9: K9_VDD_PS (Connects VDD to tester PS)
        // =========================================================================

        ISetupUtility K9_VDD_PS = ds.addUtility("K9_VDD_PS").setValue(1);
        ISetupUtility.ISetState K9_VDD_PS_turnoff = K9_VDD_PS.setState("K9_VDD_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K9_VDD_PS_turnon = K9_VDD_PS.setState("K9_VDD_PS_utility_1").setValue(1).setSettlingTime(0.02);

         // =========================================================================
         // K13: K13_SQP1_PS (Connects SQP1 to tester PS)
         // =========================================================================

         ISetupUtility K13_SQP1_PS = ds.addUtility("K13_SQP1_PS").setValue(1);
         ISetupUtility.ISetState K13_SQP1_PS_turnoff = K13_SQP1_PS.setState("K13_SQP1_PS_utility_0").setValue(0).setSettlingTime(0.02);
         ISetupUtility.ISetState K13_SQP1_PS_turnon = K13_SQP1_PS.setState("K13_SQP1_PS_utility_1").setValue(1).setSettlingTime(0.02);


        ISetupDcVI oddGroup = ds.addDcVI(ODD_GROUP_EXPR);
        oddGroup.setConnect(true).setDisconnect(true);

        ISetupDcVI evenGroup = ds.addDcVI(EVEN_GROUP_EXPR);
        evenGroup.setConnect(true).setDisconnect(true);

        // Supply/ground pins at 0V throughout
        ISetupDcVI gndGroup = ds.addDcVI(GND_SUPPLY_EXPR);
        gndGroup.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce gndForce0V = gndGroup.vforce("gnd_force_0V").setForceValue(0.0).setVrange(5.75).setIrange(0.04).setIclamp(0.04);

        // ODD group actions
        ISetupDcVI.IVforce oddForcePos = oddGroup.vforce("odd_force_pos").setForceValue(V_FORCE_POS).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce oddForceNeg = oddGroup.vforce("odd_force_neg").setForceValue(V_FORCE_NEG).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce oddForce0V = oddGroup.vforce("odd_force_0V").setForceValue(0.0).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IImeas oddMeasPos = oddGroup.imeas("ODDPIN_POS").setIrange(I_RANGE).setRestoreIrange(false);
        ISetupDcVI.IImeas oddMeasNeg = oddGroup.imeas("ODDPIN_NEG").setIrange(I_RANGE).setRestoreIrange(false);

        // EVEN group actions
        ISetupDcVI.IVforce evenForcePos = evenGroup.vforce("even_force_pos").setForceValue(V_FORCE_POS).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce evenForceNeg = evenGroup.vforce("even_force_neg").setForceValue(V_FORCE_NEG).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IVforce evenForce0V = evenGroup.vforce("even_force_0V").setForceValue(0.0).setVrange(5.75).setIrange(I_RANGE).setIclamp(I_CLAMP);
        ISetupDcVI.IImeas evenMeasPos = evenGroup.imeas("EVENPIN_POS").setIrange(I_RANGE).setRestoreIrange(false);
        ISetupDcVI.IImeas evenMeasNeg = evenGroup.imeas("EVENPIN_NEG").setIrange(I_RANGE).setRestoreIrange(false);

        ds.addUtility("K4_ISET_PS").setValue(1);
        ds.addUtility("K5_VSS_GND").setValue(1);


        ds.addUtility("K7_SQM1_PS").setValue(1);

        ds.addUtility("K9_VDD_PS").setValue(1);

        ds.addUtility("K13_SQP1_PS").setValue(1);


        // POS first, NEG next. Supply/ground always 0V.
        ds.sequentialBegin("P2P_Leakage_Seq");
        {

            ds.actionCall(K4_ISET_PS_turnon);
            ds.actionCall(K5_VSS_GND_turnon);
            ds.actionCall(K7_SQM1_PS_turnon);
            ds.actionCall(K9_VDD_PS_turnon);
            ds.actionCall(K13_SQP1_PS_turnon);
            ds.waitCall(0.010);


            ds.actionCall(gndForce0V);
            ds.actionCall(evenForce0V);
            ds.actionCall(oddForce0V);
            ds.waitCall(0.050);
            ds.actionCall(oddForcePos);
            ds.actionCall(evenForce0V);
            ds.waitCall(0.050);
            ds.actionCall(oddMeasPos);

            ds.actionCall(oddForce0V);
            ds.actionCall(evenForcePos);
            ds.waitCall(0.050);
            ds.actionCall(evenMeasPos);

            ds.actionCall(oddForceNeg);
            ds.actionCall(evenForce0V);
            ds.waitCall(0.050);
            ds.actionCall(oddMeasNeg);

            ds.actionCall(oddForce0V);
            ds.actionCall(evenForceNeg);
            ds.waitCall(0.050);
            ds.actionCall(evenMeasNeg);

            // Safe power-down: return all groups to 0V before opening relays
            ds.actionCall(evenForce0V);
            ds.actionCall(oddForce0V);
            ds.actionCall(gndForce0V);
            ds.waitCall(0.010);

            ds.actionCall(K4_ISET_PS_turnoff);
            ds.actionCall(K5_VSS_GND_turnoff);
            ds.actionCall(K7_SQM1_PS_turnoff);
            ds.actionCall(K9_VDD_PS_turnoff);
            ds.actionCall(K13_SQP1_PS_turnoff);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
    }

    @Override
    public void execute() {

        println("\n<------- P2P Leakage Test START ------->\n");

        String suiteName = context.getTestSuiteName();
        String mapKey = "P2PLeakage";

        measurement.execute();
        IDcVIResults result = measurement.dcVI().preserveResults();
        Map<String, MultiSiteDoubleArray> measuredCurrents = result.imeas("").getCurrent();
        println("The stored aresults in map are:"+measuredCurrents);


        int testNumberFromTesttable = ptd_P2P_Leakage.getTestNumber();

        if ("Main.contySubFlow.P2P_Leakage".equals(suiteName)) {
            // PRE: save every pin result for comparison during POST, then run normal continuity limits.
            storedPreResults.put(mapKey, measuredCurrents);
            if (ptd_P2P_Leakage.getLowLimit() != null && ptd_P2P_Leakage.getHighLimit() != null) {
                preLowLimit = ptd_P2P_Leakage.getLowLimit().doubleValue();
                preHighLimit = ptd_P2P_Leakage.getHighLimit().doubleValue();
            }
            int testNumber = ptd_P2P_Leakage.getTestNumber();
            for(int i=0;i<2;i++) {

            for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
                String pinOrGroupName = entry.getKey();
                MultiSiteDoubleArray current = entry.getValue();

                if(i==0) {
                    // Assign the test name and number for the current result.
                    ptd_P2P_Leakage.setTestText("LEAKAGE_P2P__" + pinOrGroupName + "=100mV_VDD=0V_VDDQ=0V_ADJ=0V")
                            .setTestNumber(testNumber);
                } else {
                    // Assign the test name and number for the current result.
                    ptd_P2P_Leakage.setTestText("LEAKAGE_P2P__" + pinOrGroupName + "=-100mV_VDD=0V_VDDQ=0V_ADJ=0V")
                            .setTestNumber(testNumber);
                }

                // Evaluate the measured continuity voltage.
                ptd_P2P_Leakage.evaluate(current, i, measurement);

                // Print the measured voltage for the current pin or pin group.
                println("Measured P2P Leakage current on "
                        + pinOrGroupName + ": " + current + " A");

                // Reserve ten test-number slots per measured pin or pin group.
                testNumber += 10;
            }
           }
           ptd_P2P_Leakage.setTestText("LEAKAGE_P2P__100mV_VDD=0V_VDDQ=0V_ADJ=0V")
                   .setTestNumber(testNumberFromTesttable);
        }
        if ("Main.postContySubFlow.P2P_Leakage".equals(suiteName)) {
            // POST: compare the new current with the matching saved PRE current.
            Map<String, MultiSiteDoubleArray> preMeasuredCurrents = storedPreResults.get(mapKey);
            int testNumber = ptd_P2P_Leakage.getTestNumber();

            double lowLimit = (preLowLimit != null) ? preLowLimit
                    : (ptd_P2P_Leakage.getLowLimit() != null ? ptd_P2P_Leakage.getLowLimit().doubleValue() : -40e-6);
            double highLimit = (preHighLimit != null) ? preHighLimit
                    : (ptd_P2P_Leakage.getHighLimit() != null ? ptd_P2P_Leakage.getHighLimit().doubleValue() : 40e-6);

            // Guard against retaining delta limits (-35e-6, 35e-6) from a previous run or dirty session
            if (Math.abs(lowLimit - (-35e-6)) < 1e-9 && Math.abs(highLimit - 35e-6) < 1e-9) {
                if (preLowLimit != null && preHighLimit != null) {
                    lowLimit = preLowLimit;
                    highLimit = preHighLimit;
                } else {
                    lowLimit = -40e-6;
                    highLimit = 40e-6;
                }
            }

            try {
                if (preMeasuredCurrents == null) {
                    println("No PRE P2P Leakage current found; delta is not evaluated.");
                } else {
                    for(int i=0;i<2;i++) {
                        for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
                            String pinOrGroupName = entry.getKey();
                            MultiSiteDoubleArray preCurrent = preMeasuredCurrents.get(pinOrGroupName);
                            MultiSiteDoubleArray postCurrent = entry.getValue();

                            if (preCurrent == null) {
                                println("No PRE P2P Leakage current found for " + pinOrGroupName
                                        + "; delta is not evaluated.");
                                continue;
                            }
                            ptd_P2P_Leakage.setLowLimit(lowLimit).setHighLimit(highLimit);

                            MultiSiteDoubleArray current = entry.getValue();
                            if(i==0) {
                                // Assign the test name and number for the current result.
                                ptd_P2P_Leakage.setTestText("POST_LEAKAGE_P2P__" + pinOrGroupName + "=100mV_VDD=0V_VDDQ=0V_ADJ=0V")
                                        .setTestNumber(testNumber);
                            } else {
                                // Assign the test name and number for the current result.
                                ptd_P2P_Leakage.setTestText("POST_LEAKAGE_P2P__" + pinOrGroupName + "=-100mV_VDD=0V_VDDQ=0V_ADJ=0V")
                                        .setTestNumber(testNumber);
                            }

                            // Evaluate the measured continuity voltage.
                            ptd_P2P_Leakage.evaluate(current, i, measurement);

                            // Print the measured voltage for the current pin or pin group.
                            println("Measured P2P Leakage current on "
                                    + pinOrGroupName + ": " + current + " A");

                            // Reserve ten test-number slots per measured pin or pin group.
                            testNumber += 10;

                            // Delta is signed: POST voltage minus PRE voltage, calculated per test site.
                            MultiSiteDouble deltaCurrent = new MultiSiteDouble();
                            for (int site : context.getActiveSites()) {
                                double delta = postCurrent.getElement(site, i)
                                        - preCurrent.getElement(site, i);
                                deltaCurrent.set(site, delta);
                            }
                            ptd_P2P_Leakage.setLowLimit(-35e-6).setHighLimit(35e-6);

                            ptd_P2P_Leakage.setTestText("P2P_LEAKAGE_DELTA_" + pinOrGroupName)
                                    .setTestNumber(testNumber);
                            ptd_P2P_Leakage.evaluate(deltaCurrent);

                            println("P2P Leakage current delta on " + pinOrGroupName + ": "
                                    + deltaCurrent + " A");
                            testNumber += 10;
                        }
                    }
                }
            } finally {
                // Restore test table text, number, and leakage limits for subsequent runs
                ptd_P2P_Leakage.setLowLimit(lowLimit).setHighLimit(highLimit);
                ptd_P2P_Leakage.setTestText("POST_LEAKAGE_P2P__100mV_VDD=0V_VDDQ=0V_ADJ=0V")
                        .setTestNumber(testNumberFromTesttable);
            }
        }

        println("\n<------- P2P Leakage Test END ------->\n");
    }
}
