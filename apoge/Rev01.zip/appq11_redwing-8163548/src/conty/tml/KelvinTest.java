package conty.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteBoolean;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.resultaccess.IDcVIResults.ICheckKelvinConnectionResults;
import xoc.dta.resultaccess.IResultPassedPerPogoUploadedResults;
import xoc.dta.testdescriptor.IFunctionalTestDescriptor;

public class KelvinTest extends TestMethod {

    private static final String[] SIGNALS = {
            "VDDQ1_AVI1", "VDDQ1_AVI2", "VDDQ2_AVI3", "VDDQ2_AVI4", "VDDQ2_AVI5", "VDDQ2_AVI6", "VDDQ1_AVI7", "VDDQ1_AVI8",
            "SQP1_AVI1", "SQP1_AVI2", "SQP2_AVI3", "SQP2_AVI4", "SQP3_AVI5", "SQP3_AVI6", "SQP4_AVI7", "SQP4_AVI8",
            "SQM1_AVI1", "SQM1_AVI2", "SQM2_AVI3", "SQM2_AVI4", "SQM3_AVI5", "SQM3_AVI6", "SQM4_AVI7", "SQM4_AVI8"
    };

    // Action names
    private static final String ACTION_P_PS = "posCheckKelvin"; // Force (P) to Sense (PS)
    private static final String ACTION_G_GS = "negCheckKelvin"; // Return/Ground (G) to Sense (GS)

    // Configurable Kelvin parameters (Default HW threshold is ~5k Ohm; 5-10 Ohm is standard for contact checks)
    private static final double MAX_RESISTANCE_OHM = 10.0;
    private static final long   AVERAGING_SAMPLES  = 4;

    MultiSiteBoolean kelvinResultP_PS;
    MultiSiteBoolean kelvinResultG_GS;

    public IFunctionalTestDescriptor ftd;
    public IMeasurement measurement;

    @Override
    public void setup() {
        ftd.initializeFromTestTables();
        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // 1. All pins must be disconnected in Hi-Z for the Kelvin Test Unit to operate
        ISetupDcVI kelvin = ds.addDcVI("VDDQGroup + SQPGroup + SQMGroup")
                .setConnect(false)
                .setDisconnectModeHiz();

        // 2. Kelvin Check 1: P to PS (High Force to High Sense)
        ISetupDcVI.ICheckKelvinConnection posKelvinCheck = kelvin.checkKelvinConnection(ACTION_P_PS)
                .setLineForceSense()
                .setMaxResistance(MAX_RESISTANCE_OHM)
                .setAverages(AVERAGING_SAMPLES);

        // 3. Kelvin Check 2: G to GS (Low Force / Return Ground to Ground Sense)
        ISetupDcVI.ICheckKelvinConnection negKelvinCheck = kelvin.checkKelvinConnection(ACTION_G_GS)
                .setLineReturnSense()
                .setMaxResistance(MAX_RESISTANCE_OHM)
                .setAverages(AVERAGING_SAMPLES);

        ds.setStrict(false);
        ds.actionCall(posKelvinCheck);
        ds.actionCall(negKelvinCheck);

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
    }

    @Override
    public void execute() {
        measurement.execute();
        releaseTester(); // Release HW resources promptly

        // Preserve results
        IDcVIResults actionResults = measurement.dcVI().preserveResults();

        // Retrieve results for both Kelvin loops
        ICheckKelvinConnectionResults resultsP_PS = actionResults.checkKelvinConnection(ACTION_P_PS);
        ICheckKelvinConnectionResults resultsG_GS = actionResults.checkKelvinConnection(ACTION_G_GS);

        int testNumber = ftd.getTestNumber();
        int baseTestNumber = testNumber;

        for (String signal : SIGNALS) {
            // Get action pass/fail status
            kelvinResultP_PS = resultsP_PS.hasPassed(signal).getElement(0);
            kelvinResultG_GS = resultsG_GS.hasPassed(signal).getElement(0);

            // 1. Datalog P <-> PS check
            ftd.setTestText("KELVIN_P_PS_" + signal).setTestNumber(testNumber);
            ftd.evaluate(kelvinResultP_PS, measurement);
            testNumber += 10;

            // 2. Datalog G <-> GS check
            ftd.setTestText("KELVIN_G_GS_" + signal).setTestNumber(testNumber);
            ftd.evaluate(kelvinResultG_GS, measurement);
            testNumber += 10;

            // Console debug output
            for (int site : context.getActiveSites()) {
                boolean passP_PS = kelvinResultP_PS.get(site);
                boolean passG_GS = kelvinResultG_GS.get(site);

                if (!passP_PS || !passG_GS) {
                    System.err.println(String.format(
                        "[Site %d] Kelvin FAIL on %s -> P-PS (Force): %s, G-GS (Return): %s",
                        site, signal, passP_PS ? "PASS" : "FAIL", passG_GS ? "PASS" : "FAIL"
                    ));
                } else {
                    System.out.println(String.format(
                        "[Site %d] Kelvin PASS on %s [P-PS & G-GS OK]", site, signal
                    ));
                }
            }
        }

        // Optional: Per-Pogo Pin Breakdown (useful for ganged channels or multi-pogo pins)
        try {
            IResultPassedPerPogoUploadedResults pogoResults = resultsP_PS.perPogo().upload();
            for (IResultPassedPerPogoUploadedResults.ResultElement elem : pogoResults.iterateValues()) {
                MultiSiteBoolean pogoPass = elem.hasPassed();
                for (int site : context.getActiveSites()) {
                    if (!pogoPass.get(site)) {
                        System.err.println(String.format(
                            "[Site %d] Physical Pogo %s (%s) P-PS Kelvin FAILED",
                            site, elem.getPogoNumber().get(site), elem.getSignal()
                        ));
                    }
                }
            }
        } catch (Exception ignored) {
            // Non-fatal if per-pogo is not mapped
        }

        // Reset main test text
        ftd.setTestText("KELVIN_TEST").setTestNumber(baseTestNumber);
    }
}
