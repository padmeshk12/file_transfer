package conty.tml;

import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Measures VDDQ mold resistance for each VDDQ channel.
 *
 * <p>The test holds all non-VDDQ pins at 0 V, forces current on one VDDQ
 * channel at a time, measures the voltage, and calculates resistance.
 */
public class supplyShort extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    /** Individual VDDQ channels measured during this test. */
//    public List<String> vddqChannels = Arrays.asList( "VDDQ1_AVI1","VDDQ1_AVI2" ,"VDDQ2_AVI3","VDDQ2_AVI4",
//            "VDDQ2_AVI5", "VDDQ2_AVI6" , "VDDQ1_AVI7" , "VDDQ1_AVI8");

    /** Total forced current used for resistance calculation, in amperes. */
    public MultiSiteDouble forceVoltage = new MultiSiteDouble(0.1);

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // Configure VDD and hold it at 0 V.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.00125)
                .setVforce(0.0)
                .setIclamp(0.00125);

        // Configure the VDDQ pin group for current force and voltage measurement.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQ1_AVI1");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force -1 mA total current, shared across eight VDDQ channels.
        ISetupDcVI.IVforce forceVddqTotal100mV =
                vddqGroup.vforce("force_vddq_total_0p1V")
                        .setForceValue(0.1 )
                        .setVrange(3.0)
                        .setIrange(0.010)
                        .setIclamp(0.010);

        // Force 0 V on VDDQ for safe power-down.
        ISetupDcVI.IVforce forceVddq0V =
                vddqGroup.vforce("force_vddq_0V")
                        .setForceValue(0.0)
                        .setVrange(3.0)
                        .setIrange(0.010)
                        .setIclamp(0.010);

        // Measure voltage on the selected VDDQ channel.
        ISetupDcVI.IImeas measureVddqCurrent =
                vddqGroup.imeas("measure_vddq_current")
                        .setIrange(0.001);

        // Disconnect VDDQ before selecting the next VDDQ channel.
        ISetupDcVI.IDisconnect disconnectVddq =
                vddqGroup.disconnect("disconnect_vddq");

        // Configure SQP and SQM groups.
        ISetupDcVI sqGroup = ds.addDcVI("SQPGroup + SQMGroup");
        sqGroup.setConnect(true).setDisconnect(true);

        // Force SQP and SQM groups to 0 V.
        ISetupDcVI.IVforce forceSqGroupsTo0V =
                sqGroup.vforce("force_sqp_sqm_groups_0V")
                        .setForceValue(0.0)
                        .setVrange(3.0)
                        .setIrange(10e-3)
                        .setIclamp(10e-3);

        //Turn on the relay for ISET to connect to PS1600
//        ISetupUtility iset_k4 = ds.addUtility("K4_ISET_PS").setValue(1);
//        //Turn on the relay for VSS to connect to GND
//        ISetupUtility vss_k5 = ds.addUtility("K5_VSS_GND").setValue(1);


        ISetupUtility.ISetState k4_ISET_utility_0 = null;
        ISetupUtility.ISetState k4_ISET_utility_1 = null;
        ISetupUtility iset_k4_turnon = ds.addUtility("K4_ISET_PS");
        k4_ISET_utility_0 = iset_k4_turnon.setState("k4_ISET_utility_0").setValue(0).setSettlingTime(0.02);
        k4_ISET_utility_1= iset_k4_turnon.setState("k4_ISET_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility.ISetState K5_VSS_GND_utility_0 = null;
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = null;
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        K5_VSS_GND_utility_1= K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        // Configure all I/O signals.
        ISetupDcVI ioSignalGroup = ds.addDcVI("IOGroup");
        ioSignalGroup.setConnect(true).setDisconnect(true);

        // Force all I/O signals to 0 V.
        ISetupDcVI.IVforce forceIoSignalsTo0V =
                ioSignalGroup.vforce("force_io_signals_0V")
                        .setForceValue(0.0)
                        .setIrange(0.00025)
                        .setIclamp(0.00025);

        ds.sequentialBegin("vddq_mold_resistance_measurement");
        {

            ds.actionCall(k4_ISET_utility_1);
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.waitCall(0.010);
            // Hold SQP and SQM groups at 0 V.
            ds.actionCall(forceSqGroupsTo0V);

            // Hold all I/O signals at 0 V.
            ds.actionCall(forceIoSignalsTo0V);

            ds.actionCall(forceVddqTotal100mV);
            ds.waitCall(0.010);
            ds.actionCall(measureVddqCurrent);

            // Safe power-down: return VDDQ to 0V before opening relays
            ds.actionCall(forceVddq0V);
            ds.waitCall(0.010);

            ds.actionCall(k4_ISET_utility_0);
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- Supply Short Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredCurrents =
                results.imeas("").getCurrent();

        int testNumber = ptdDC.getTestNumber();
        int testNumberFromTesttable = testNumber;

        MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

        for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
            String pinName = entry.getKey();
            MultiSiteDouble measuredCurrent = entry.getValue().getElement(0);

            // Calculate mold resistance using R = V / I.
//            MultiSiteDouble moldResistance =
//                    measuredVoltage.divide(forceCurrent).abs();

            ptdDC.setTestText("Supply_Short__" + pinName + "=100mV_VDD=0V_SQP=0V_SQM=0V")
                    .setTestNumber(testNumber);

            ptdDC.evaluate(measuredCurrent, measurement);
            totalCurrent.add(measuredCurrent);

            println(pinName
                    + " | Current: " + measuredCurrent + " A");

            testNumber += 10;
        }
        ptdDC.setTestText("Supply_Short__100mV_VDD=0V_SQP=0V_SQM=0V")
        .setTestNumber(testNumberFromTesttable);
    }
}
