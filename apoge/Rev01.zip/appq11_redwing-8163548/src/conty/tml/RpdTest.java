package conty.tml;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.annotations.In;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * RPD resistance test for ARM_PS, LFIRE_PS, and HFIRE_PS.
 *
 * <p>
 * The test holds all non-measured pins at 0 V, forces a known voltage on one target pin, measures
 * its current, and calculates resistance as R = V / I.
 */
public class RpdTest extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdRes;


    /**
     * Forced voltage used in RPD calculation: R = forceVoltage / measuredCurrent.
     */
    @In
    public MultiSiteDouble forceVoltage = new MultiSiteDouble(0.1);

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance(DSAGenerationMode.GENERATE_IN_FILE);
        ds.importSpec("common.pinGroups");


        // Configure VDD and hold it at 0 V.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(2.0).setIrange(0.00125).setVforce(0.0).setIclamp(0.00125);

        // Configure SQP, SQM, and VDDQ high-power pin groups.
        ISetupDcVI highPowerGroup = ds.addDcVI("SQPGroup" + " + " + "SQMGroup" + " + " + "VDDQGroup");
        highPowerGroup.setConnect(true).setDisconnect(true);

        // Force all high-power pins to 0 V.
        ISetupDcVI.IVforce forceHighPowerPinsTo0V = highPowerGroup
                .vforce("force_high_power_pins_0V").setForceValue(0.0).setVrange(1.5)
                .setIrange(0.005).setIclamp(0.005);

        //Turn on the relay for ISET to connect to PS1600
//        ISetupUtility iset_k4 = ds.addUtility("K4_ISET_PS").setValue(1);
//        //Turn on the relay for VSS to connect to GND
//        ISetupUtility vss_k5 = ds.addUtility("K5_VSS_GND").setValue(1);

        ISetupUtility.ISetState k4_ISET_utility_0 = null;
        ISetupUtility.ISetState k4_ISET_utility_1 = null;
        ISetupUtility iset_k4_turnon = ds.addUtility("K4_ISET_PS");
        k4_ISET_utility_0 = iset_k4_turnon.setState("k4_ISET_utility_0").setValue(0).setSettlingTime(0.02);
        k4_ISET_utility_1= iset_k4_turnon.setState("k4_ISET_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility.ISetState K5_VSS_GND_utility_0 = null;
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = null;
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        K5_VSS_GND_utility_1= K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        // Configure all I/O signals used by the RPD test.
        ISetupDcVI ioSignalGroup = ds.addDcVI("IOGroup");
        ioSignalGroup.setConnect(true).setDisconnect(true);

        // Force the selected I/O signal to 0.1 V for resistance measurement.
        ISetupDcVI.IVforce forceIoSignalTo0p1V = ioSignalGroup.vforce("force_io_signal_0p1V")
                .setForceValue(0.1).setIrange(0.00001).setIclamp(0.00001);

        // Force all non-measured I/O signals to 0 V.
        ISetupDcVI.IVforce forceIoSignalTo0V = ioSignalGroup.vforce("force_io_signal_0V")
                .setForceValue(0.0).setIrange(0.00001).setIclamp(0.00001);

        // Measure current on the selected I/O signal.
        ISetupDcVI.IImeas measureIoSignalCurrent = ioSignalGroup.imeas("measure_io_signal_current")
                .setIrange(0.00001).setHighAccuracy(true);


        ds.sequentialBegin("rpd_measurement_sequence");
        {

            ds.actionCall(k4_ISET_utility_1);
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.waitCall(0.010);
            // Hold all SQP, SQM, and VDDQ high-power pins at 0 V.
            ds.actionCall(forceHighPowerPinsTo0V);
            ds.waitCall(0.10);
            // ARM_PS resistance measurement: hold other pins at 0 V, force ARM_PS to 0.1 V, and measure ARM_PS current.
            ds.actionCall("force_io_signal_0V", Arrays.asList("LFIRE_PS + HFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
            ds.actionCall("force_io_signal_0p1V", Arrays.asList("ARM_PS"));
            ds.waitCall(0.010);
            ds.actionCall("measure_io_signal_current", Arrays.asList("ARM_PS"));

            // LFIRE_PS resistance measurement: hold other pins at 0 V, force LFIRE_PS to 0.1 V, and measure LFIRE_PS current.
            ds.actionCall("force_io_signal_0V", Arrays.asList("ARM_PS + HFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
            ds.actionCall("force_io_signal_0p1V", Arrays.asList("LFIRE_PS"));
            ds.waitCall(0.010);
            ds.actionCall("measure_io_signal_current", Arrays.asList("LFIRE_PS"));

            // HFIRE_PS resistance measurement: hold other pins at 0 V, force HFIRE_PS to 0.1 V, and measure HFIRE_PS current.
            ds.actionCall("force_io_signal_0V", Arrays.asList("ARM_PS + LFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
            ds.actionCall("force_io_signal_0p1V", Arrays.asList("HFIRE_PS"));
            ds.waitCall(0.010);
            ds.actionCall("measure_io_signal_current", Arrays.asList("HFIRE_PS"));

            // Safe power-down: return all IO signals to 0V before opening relays
            ds.actionCall("force_io_signal_0V", Arrays.asList("ARM_PS + LFIRE_PS + HFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
            ds.waitCall(0.010);

            ds.actionCall(k4_ISET_utility_0);
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();


        measurement.setSetups(ds);

    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {

        println("\n<------- RPD Resistance Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredCurrents = results.imeas("").getCurrent();

        int testNumber = ptdRes.getTestNumber();
        int testNumberFromTesttable = testNumber;

        for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
            String pinName = entry.getKey();
            MultiSiteDouble measuredCurrent = entry.getValue().getElement(0);

            // Calculate resistance using R = V / I.
            MultiSiteDouble resistance = forceVoltage.divide(measuredCurrent);

            ptdRes.setTestText("RPD_CONTROL__" + pinName + "=0.1V_VDD=0V_VDDQ=0V").setTestNumber(testNumber);

            ptdRes.evaluate(resistance, measurement);

            println(pinName + " | Current: " + measuredCurrent + " A" + " | Resistance: "
                    + resistance + " Ohm");

            testNumber += 10;
        }
        ptdRes.setTestText("RPD_CONTROL__0.1V_VDD=0V_VDDQ=0V").setTestNumber(testNumberFromTesttable);
    }
}
