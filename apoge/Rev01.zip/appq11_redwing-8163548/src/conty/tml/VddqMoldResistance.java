package conty.tml;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Measures VDDQ mold resistance for each VDDQ channel using a 2-point delta method.
 *
 * <p>The test holds all non-VDDQ pins at 0 V, forces two currents (e.g. -1 mA and -100 uA)
 * on one VDDQ channel at a time, measures the respective voltages, and calculates
 * mold resistance: Delta_R = | |V1| - |V2| | / | I1 - I2 |.
 */
public class VddqMoldResistance extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    /** Individual VDDQ channels measured during this test. */
    public List<String> vddqChannels = Arrays.asList( "VDDQ1_AVI1","VDDQ1_AVI2" ,"VDDQ2_AVI3","VDDQ2_AVI4",
            "VDDQ2_AVI5", "VDDQ2_AVI6" , "VDDQ1_AVI7" , "VDDQ1_AVI8");

    /** Forced current 1 used for 2-point delta resistance calculation, in amperes. */
    public double forceCurrent1 = -0.001;

    /** Forced current 2 used for 2-point delta resistance calculation, in amperes. */
    public double forceCurrent2 = -0.0001;

    /** Legacy forced current retained for backward compatibility, in amperes. */
    public MultiSiteDouble forceCurrent = new MultiSiteDouble(-0.001);

    /** Low limit for mold resistance evaluation in ohms. */
    public double lowLimit = 0.0;

    /** High limit for mold resistance evaluation in ohms. */
    public double highLimit = 100.0;

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // Configure VDD and hold it at 0 V.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.00125)
                .setVforce(0.0)
                .setIclamp(0.00125);

        // Configure the VDDQ pin group for current force and voltage measurement.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQGroup");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force current 1 (-1 mA) on selected channel.
        ISetupDcVI.IIforce forceVddq1mA =
                vddqGroup.iforce("force_vddq_1mA")
                        .setForceValue(forceCurrent1)
                        .setVrange(3.0)
                        .setIrange(10e-3)
                        .setVclampHigh(0.0)
                        .setVclampLow(-1.5);

        // Force current 2 (-100 uA) on selected channel.
        ISetupDcVI.IIforce forceVddq100uA =
                vddqGroup.iforce("force_vddq_100uA")
                        .setForceValue(forceCurrent2)
                        .setVrange(3.0)
                        .setIrange(10e-3)
                        .setVclampHigh(0.0)
                        .setVclampLow(-1.5);

        // Measure voltage at forceCurrent1 on the selected VDDQ channel.
        ISetupDcVI.IVmeas measureVddqVoltage1mA =
                vddqGroup.vmeas("measure_vddq_voltage_1mA")
                        .setVrange(3.0);

        // Measure voltage at forceCurrent2 on the selected VDDQ channel.
        ISetupDcVI.IVmeas measureVddqVoltage100uA =
                vddqGroup.vmeas("measure_vddq_voltage_100uA")
                        .setVrange(3.0);

        // Disconnect VDDQ before selecting the next VDDQ channel.
        ISetupDcVI.IDisconnect disconnectVddq =
                vddqGroup.disconnect("disconnect_vddq");

        // Configure SQP and SQM groups.
        ISetupDcVI sqGroup = ds.addDcVI("SQPGroup + SQMGroup");
        sqGroup.setConnect(true).setDisconnect(true);

        // Force SQP and SQM groups to 0 V with 50 mA clamp (standard for AVI64 squib lines).
        ISetupDcVI.IVforce forceSqGroupsTo0V =
                sqGroup.vforce("force_sqp_sqm_groups_0V")
                        .setForceValue(0.0)
                        .setVrange(3.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);

        ISetupDcVI.IDisconnect disconnectSq =
                sqGroup.disconnect("disconnect_sq");

        ISetupUtility.ISetState k4_ISET_utility_0 = null;
        ISetupUtility.ISetState k4_ISET_utility_1 = null;
        ISetupUtility iset_k4_turnon = ds.addUtility("K4_ISET_PS");
        k4_ISET_utility_0 = iset_k4_turnon.setState("k4_ISET_utility_0").setValue(0).setSettlingTime(0.02);
        k4_ISET_utility_1 = iset_k4_turnon.setState("k4_ISET_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility.ISetState K5_VSS_GND_utility_0 = null;
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = null;
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        K5_VSS_GND_utility_1 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        // Disconnect external SQM1 power supply and 47uF capacitor
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);

        // Configure all I/O signals.
        ISetupDcVI ioSignalGroup = ds.addDcVI("IOGroup");
        ioSignalGroup.setConnect(true).setDisconnect(true);

        // Force all I/O signals to 0 V.
        ISetupDcVI.IVforce forceIoSignalsTo0V =
                ioSignalGroup.vforce("force_io_signals_0V")
                        .setForceValue(0.0)
                        .setIrange(0.00025)
                        .setIclamp(0.00025);

        ISetupDcVI.IDisconnect disconnectIo =
                ioSignalGroup.disconnect("disconnect_io");

        ds.sequentialBegin("vddq_mold_resistance_measurement");
        {
            ds.actionCall(k4_ISET_utility_1);
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.waitCall(0.010);

            // Hold SQP and SQM groups at 0 V.
            ds.actionCall(forceSqGroupsTo0V);

            // Hold all I/O signals at 0 V.
            ds.actionCall(forceIoSignalsTo0V);

            // Measure VDDQ channels one at a time using 2 current values.
            for (String vddqChannel : vddqChannels) {
                ds.actionCall(disconnectVddq);
                ds.actionCall("force_vddq_1mA", Arrays.asList(vddqChannel));
                ds.waitCall(0.010);
                ds.actionCall("measure_vddq_voltage_1mA", Arrays.asList(vddqChannel));

                ds.actionCall("force_vddq_100uA", Arrays.asList(vddqChannel));
                ds.waitCall(0.010);
                ds.actionCall("measure_vddq_voltage_100uA", Arrays.asList(vddqChannel));
            }
            ds.actionCall(disconnectVddq);
            ds.actionCall(disconnectSq);
            ds.actionCall(disconnectIo);
            ds.waitCall(0.010);

            ds.actionCall(k4_ISET_utility_0);
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- VDDQ Mold Resistance Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("VDDQGroup").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredVoltages1mA =
                results.vmeas("measure_vddq_voltage_1mA").getVoltage();
        Map<String, MultiSiteDoubleArray> measuredVoltages100uA =
                results.vmeas("measure_vddq_voltage_100uA").getVoltage();

        int testNumber = ptdDC.getTestNumber();
        int testNumberFromTesttable = testNumber;

        // Delta I in Amperes = |I1 - I2|
        double deltaI = Math.abs(forceCurrent1 - forceCurrent2);

        for (String pinName : vddqChannels) {
            MultiSiteDoubleArray v1Array = measuredVoltages1mA.get(pinName);
            MultiSiteDoubleArray v2Array = measuredVoltages100uA.get(pinName);

            if (v1Array == null || v2Array == null) {
                continue;
            }

            MultiSiteDouble v1 = v1Array.getElement(0);
            MultiSiteDouble v2 = v2Array.getElement(0);

            // Delta V = ||V1| - |V2|| (as in CROW: fabs(fabs(mold_volt) - fabs(mold_volt_100uA)))
            MultiSiteDouble deltaV = v1.abs().subtract(v2.abs()).abs();

            // Delta R = Delta V / Delta I (in Ohms)
            MultiSiteDouble moldResistance = deltaV.divide(deltaI);

           // ptdDC.setLowLimit(lowLimit).setHighLimit(highLimit);
            ptdDC.setTestText("MOLD_RESISTANCE__" + pinName + "=-1mA_VDD=0V_SQP=0V_SQM=0V")
                    .setTestNumber(testNumber);

            ptdDC.evaluate(moldResistance, measurement);

            println(pinName
                    + " | V1: " + v1 + " V"
                    + " | V2: " + v2 + " V"
                    + " | Delta V: " + deltaV + " V"
                    + " | Resistance: " + moldResistance + " Ohm");

            testNumber += 10;
        }
        ptdDC.setTestText("MOLD_RESISTANCE__-1mA_VDD=0V_SQP=0V_SQM=0V")
        .setTestNumber(testNumberFromTesttable);
    }
}
