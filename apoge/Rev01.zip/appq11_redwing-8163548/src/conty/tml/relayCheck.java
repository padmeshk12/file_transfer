package conty.tml;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Positive continuity test for supply and control pins.
 *
 * <p>VDD and VDDQ are forced to 0 V. A positive current is forced on each
 * continuity pin, and the measured voltage is evaluated.
 */
public class relayCheck extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;
    private static Map<String, Map<String, MultiSiteDoubleArray>> storedPreResults = new ConcurrentHashMap<>();

    public List<String> SQPGroup = Arrays.asList("SQP1_AVI1", "SQP1_AVI2", "SQP2_AVI3", "SQP2_AVI4",
            "SQP3_AVI5", "SQP3_AVI6", "SQP4_AVI7", "SQP4_AVI8" );

    public List<String> SQMGroup = Arrays.asList("SQM1_AVI1" , "SQM1_AVI2" , "SQM2_AVI3" , "SQM2_AVI4" ,
    "SQM3_AVI5" , "SQM3_AVI6" , "SQM4_AVI7" , "SQM4_AVI8" );

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        // Configure VDD and its operating range.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(1.5).setIrange(0.00025);

        // Force VDD to 0 V during the continuity test.
        ISetupDcVI.IVforce forceVddTo0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.00025)
                .setIclamp(0.00025);

        // Configure VDDQ and its operating range.
        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(true);

        // Force VDDQ to 0 V during the continuity test.
        ISetupDcVI.IVforce forceVddqTo0V = vddq.vforce("force_vddq_0V")
                .setForceValue(0.0)
                .setVrange(1.5)
                .setIrange(0.0005)
                .setIclamp(0.0005);

        // Configure SQP; 150 uA is shared across eight AVI channels.
        ISetupDcVI sqp = ds.addDcVI("SQPGroup");
        sqp.setConnect(true).setDisconnect(true);

        // Force +150 uA total current on SQP.
        ISetupDcVI.IIforce forceSqp150uA = sqp.iforce("force_sqp_150uA")
                .setForceValue(0.000150)
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);
        //disconnect sqp
        ISetupDcVI.IDisconnect disConnectsqp = sqp.disconnect("disconnect_sqp");

        // Measure voltage on SQP.
        ISetupDcVI.IVmeas measureSqpVoltage = sqp.vmeas("measure_sqp_voltage")
                .setVrange(1.5);


        // Configure SQM; 150 uA is shared across eight AVI channels.
        ISetupDcVI sqm = ds.addDcVI("SQMGroup");
        sqm.setConnect(true).setDisconnect(true);

        // Force +150 uA total current on SQM.
        ISetupDcVI.IIforce forceSqm150uA = sqm.iforce("force_sqm_150uA")
                .setForceValue(0.000150 )
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);

        // Measure voltage on SQM.
        ISetupDcVI.IVmeas measureSqmVoltage = sqm.vmeas("measure_sqm_voltage")
                .setVrange(1.5);
        //disconnect sqm
        ISetupDcVI.IDisconnect disConnectsqm = sqm.disconnect("disconnect_sqm");

//        //Turn on the relay for ISET to connect to PS1600
//        ISetupUtility iset_k4 = ds.addUtility("K4_ISET_PS").setValue(1);
//        //Turn on the relay for VSS to connect to PS1600
//        ISetupUtility vss_k6 = ds.addUtility("K6_VSS_PS").setValue(1);

        // Configure IO pins for continuity measurement.
        ISetupDcVI io = ds.addDcVI("CONTYPOS_IO" + "+" + "VSS_PS");
        io.setConnect(true).setDisconnect(true);

        // Force +150 uA current on IO pins.
        ISetupAction forceIO150uA = io.iforce("force_io_150uA")
                .setForceValue(0.000150)
                .setVrange(1.5)
                .setVclampHigh(1.5)
                .setVclampLow(0.0);

        // Measure voltage on IO pins.
        ISetupDcVI.IVmeas measureIOVoltage = io.vmeas("measure_io_voltage")
                .setVrange(1.5)
                .setHighAccuracy(false);

        ds.sequentialBegin("ContinuityPos");
        {
        ds.actionCall(forceVddTo0V);
        ds.actionCall(forceVddqTo0V);
        ds.waitCall(0.010);
        ds.parallelBegin("parallel_continuity_measurements");
        {
            ds.sequentialBegin("measure_sqp_serial");{
            for (String channel : SQPGroup) {
                ds.actionCall(disConnectsqp);
                ds.actionCall("force_sqp_150uA", Arrays.asList(channel));
                ds.waitCall(0.010);
                ds.actionCall("measure_sqp_voltage", Arrays.asList(channel));
            }
            }
            ds.sequentialEnd();
            ds.sequentialBegin("measure_sqm_serial");{
                for (String channel : SQMGroup) {
                    ds.actionCall(disConnectsqm);
                    ds.actionCall("force_sqm_150uA", Arrays.asList(channel));
                    ds.waitCall(0.010);
                    ds.actionCall("measure_sqm_voltage", Arrays.asList(channel));
                }
                }
                ds.sequentialEnd();

            ds.sequentialBegin("measure_io");
            {
                ds.actionCall(forceIO150uA);
                ds.waitCall(0.010);
                ds.actionCall(measureIOVoltage);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }


    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- ContinuityPos Test START ------->\n");

        String suiteName = context.getTestSuiteName();
        String mapKey = "ContinuityPos";

        // Start each PRE run with no values left over from a previous device/run.
        if ("Main.contySubFlow.ContinuityPos".equals(suiteName)) {
            storedPreResults.clear();
        }

        measurement.execute();




        // Preserve all DCVI voltage measurements before evaluating individual pins.
        IDcVIResults results = measurement.dcVI("").preserveResults();
        Map<String, MultiSiteDoubleArray> measuredVoltages = results.vmeas("").getVoltage();


        int testNumberFromTesttable = ptdDC.getTestNumber();


       if ("Main.contySubFlow.ContinuityPos".equals(suiteName)) {
        // PRE: save every pin result for comparison during POST, then run normal continuity limits.
        storedPreResults.put(mapKey, measuredVoltages);
        int testNumber = ptdDC.getTestNumber();

        for (Entry<String, MultiSiteDoubleArray> entry : measuredVoltages.entrySet()) {

            storedPreResults.put(mapKey, measuredVoltages);
            String pinOrGroupName = entry.getKey();

            MultiSiteDoubleArray voltage = entry.getValue();

            // Assign the test name and number for the current result.
            ptdDC.setTestText("CONTINUITY_POS__" + pinOrGroupName + "=150uA_VDD=0V_VDDQ=0V")
                    .setTestNumber(testNumber);

            // Evaluate the measured continuity voltage.
            ptdDC.evaluate(voltage, 0, measurement);

            // Print the measured voltage for the current pin or pin group.
            println("Measured ContinuityPos voltage on "
                    + pinOrGroupName + ": " + voltage + " V");

            // Reserve ten test-number slots per measured pin or pin group.
            testNumber += 10;
        }
       }

       if ("Main.postContySubFlow.ContinuityPos".equals(suiteName)) {
           // POST: compare the new voltage with the matching saved PRE voltage.
           Map<String, MultiSiteDoubleArray> preMeasuredVoltages = storedPreResults.get(mapKey);
           int testNumber = ptdDC.getTestNumber();
           double lowLimit = ptdDC.getLowLimit().doubleValue();
           double highLimit = ptdDC.getHighLimit().doubleValue();

           if (preMeasuredVoltages == null) {
               println("No PRE ContinuityPos results found; ContinuityPos delta is not evaluated.");
           } else {

               for (Entry<String, MultiSiteDoubleArray> entry : measuredVoltages.entrySet()) {
                   String pinOrGroupName = entry.getKey();
                   MultiSiteDoubleArray preVoltage = preMeasuredVoltages.get(pinOrGroupName);
                   MultiSiteDoubleArray postVoltage = entry.getValue();

                   if (preVoltage == null) {
                       println("No PRE continuity voltage found for " + pinOrGroupName
                               + "; delta is not evaluated.");
                       continue;
                   }

                   ptdDC.setLowLimit(lowLimit).setHighLimit(highLimit);

                   // Assign the test name and number for the current result.
                   ptdDC.setTestText("POST_CONTINUITY_POS__" + pinOrGroupName + "=150uA_VDD=0V_VDDQ=0V")
                           .setTestNumber(testNumber);

                   // Evaluate the measured continuity voltage.
                   ptdDC.evaluate(postVoltage, 0, measurement);

                   testNumber += 10;

                   // Delta is signed: POST voltage minus PRE voltage, calculated per test site.
                   MultiSiteDouble deltaVoltage = new MultiSiteDouble();
                   for (int site : context.getActiveSites()) {
                       double delta = postVoltage.getElement(site, 0)
                               - preVoltage.getElement(site, 0);
                       deltaVoltage.set(site, delta );
                   }

                   ptdDC.setLowLimit(-0.025).setHighLimit(0.025);

                   ptdDC.setTestText("CONTINUITYPOS_DELTA_" + pinOrGroupName)
                           .setTestNumber(testNumber);
                   ptdDC.evaluate(deltaVoltage);

                   println("ContinuityPos delta on " + pinOrGroupName + ": "
                           + deltaVoltage + " V");
                   testNumber += 10;
               }
           }
       }
        ptdDC.setTestText("CONTINUITY_POS__150uA_VDD=0V_VDDQ=0V")
        .setTestNumber(testNumberFromTesttable);

        println("\n<------- ContinuityPos Test END ------->\n");
    }
}
