package conty.tml;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Negative continuity test for supply and control pins.
 *
 * <p>VDD and VDDQ are forced to 0 V. A negative current is forced on each
 * continuity pin, and the measured voltage is evaluated.
 */
public class ContinuityNeg extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    private static Map<String, Map<String, MultiSiteDoubleArray>> storedPreResults = new ConcurrentHashMap<>();
    private static volatile Double preLowLimit = null;
    private static volatile Double preHighLimit = null;

    public List<String> SQPGroup = Arrays.asList("SQP1_AVI1", "SQP1_AVI2", "SQP2_AVI3", "SQP2_AVI4",
            "SQP3_AVI5", "SQP3_AVI6", "SQP4_AVI7", "SQP4_AVI8" );

    public List<String> SQMGroup = Arrays.asList("SQM1_AVI1" , "SQM1_AVI2" , "SQM2_AVI3" , "SQM2_AVI4" ,
    "SQM3_AVI5" , "SQM3_AVI6" , "SQM4_AVI7" , "SQM4_AVI8" );

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        // Configure VDD and its operating range.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(1.5).setIrange(0.00025);

        // Force VDD to 0 V during the continuity test.
        ISetupDcVI.IVforce forceVddTo0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.00025)
                .setIclamp(0.00025);

        // Configure VDDQ and its operating range.
        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(true);

        // Force VDDQ to 0 V during the continuity test.
        ISetupDcVI.IVforce forceVddqTo0V = vddq.vforce("force_vddq_0V")
                .setForceValue(0.0)
                .setVrange(1.5)
                .setIrange(0.005)
                .setIclamp(0.005);

        // Configure SQP; -100 uA is shared across eight AVI channels.
        ISetupDcVI sqp = ds.addDcVI("SQPGroup");
        sqp.setConnect(true).setDisconnect(true);

        // Force -100 uA total current on SQP.
        ISetupDcVI.IIforce forceSqpNeg100uA = sqp.iforce("force_sqp_neg_100uA")
                .setForceValue(-0.000100)
                .setVrange(1.5)
                .setVclampHigh(0.0)
                .setVclampLow(-1.5);

        // Measure voltage on SQP.
        ISetupDcVI.IVmeas measureSqpVoltage = sqp.vmeas("measure_sqp_voltage")
                .setVrange(1.5);
        //disconnect sqp
        ISetupDcVI.IDisconnect disConnectsqp = sqp.disconnect("disconnect_sqp");

        // Configure SQM; -100 uA is shared across eight AVI channels.
        ISetupDcVI sqm = ds.addDcVI("SQMGroup");
        sqm.setConnect(true).setDisconnect(true);

        // Force -100 uA total current on SQM.
        ISetupDcVI.IIforce forceSqmNeg100uA = sqm.iforce("force_sqm_neg_100uA")
                .setForceValue(-0.000100)
                .setVrange(1.5)
                .setVclampHigh(0.0)
                .setVclampLow(-1.5);

        // Measure voltage on SQM.
        ISetupDcVI.IVmeas measureSqmVoltage = sqm.vmeas("measure_sqm_voltage")
                .setVrange(1.5);
        //disconnect sqm
        ISetupDcVI.IDisconnect disConnectsqm = sqm.disconnect("disconnect_sqm");



        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_turnoff = K4_ISET_PS.setState("k4_ISET_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_turnon= K4_ISET_PS.setState("k4_ISET_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND").setValue(0);
        ISetupUtility.ISetState K5_VSS_GND_turnoff = K5_VSS_GND.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_turnon = K5_VSS_GND.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);


        ISetupUtility K6_VSS_PS = ds.addUtility("K6_VSS_PS").setValue(1);
        ISetupUtility.ISetState K6_VSS_PS_turnoff = K6_VSS_PS.setState("K6_VSS_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K6_VSS_PS_turnon = K6_VSS_PS.setState("K6_VSS_PS_utility_1").setValue(1).setSettlingTime(0.02);


        // Configure ISET for negative continuity measurement.
        ISetupDcVI io = ds.addDcVI("IOGroup" + "+" + "VSS_PS");
        io.setConnect(true).setDisconnect(true);

        // Force -100 uA current on ISET.
        ISetupAction forceIONeg100uA = io.iforce("force_io_neg_100uA")
                .setForceValue(-0.000100)
                .setVrange(1.5)
                .setVclampHigh(0.0)
                .setVclampLow(-1.5)
                .setKeepVclampEnabled();

        // Force 0 A on IO for safe power-down.
        ISetupAction forceIO0A = io.iforce("force_io_0A")
                .setForceValue(0.0)
                .setVrange(1.5)
                .setVclampHigh(0.0)
                .setVclampLow(-1.5);

        // Measure voltage on ISET.
        ISetupDcVI.IVmeas measureIOVoltage = io.vmeas("measure_io_voltage")
                .setVrange(1.5)
                .setHighAccuracy(false);


        ds.sequentialBegin("ContinuityNeg");
        {


            ds.actionCall(K5_VSS_GND_turnoff);
            ds.waitCall(0.050);
            ds.actionCall(K6_VSS_PS_turnon);
            ds.actionCall(K4_ISET_PS_turnon);
            ds.waitCall(0.050);
        ds.actionCall(forceVddTo0V);
        ds.actionCall(forceVddqTo0V);
        ds.waitCall(0.10);
//
//        ds.sequentialBegin("measure_io");
//        {
            ds.actionCall(forceIONeg100uA);
            ds.waitCall(0.10);
            ds.actionCall(measureIOVoltage);
//        }
//        ds.sequentialEnd();
        ds.parallelBegin("parallel_continuity_measurements");
        {

            ds.sequentialBegin("measure_sqp_serial");{
                for (String channel : SQPGroup) {
                    ds.actionCall(disConnectsqp);
                    ds.actionCall("force_sqp_neg_100uA", Arrays.asList(channel));
                    ds.waitCall(0.010);
                    ds.actionCall("measure_sqp_voltage", Arrays.asList(channel));
                }
                }
                ds.sequentialEnd();
                ds.sequentialBegin("measure_sqm_serial");{
                    for (String channel : SQMGroup) {
                        ds.actionCall(disConnectsqm);
                        ds.actionCall("force_sqm_neg_100uA", Arrays.asList(channel));
                        ds.waitCall(0.010);
                        ds.actionCall("measure_sqm_voltage", Arrays.asList(channel));
                    }
                    }
                    ds.sequentialEnd();
        }
        ds.parallelEnd();

        // Safe power-down: disconnect/zero forced currents
        ds.actionCall(disConnectsqp);
        ds.actionCall(disConnectsqm);
        ds.actionCall(forceIO0A);
        ds.waitCall(0.010);

        ds.actionCall(K4_ISET_PS_turnoff);
        ds.actionCall(K5_VSS_GND_turnoff);
        ds.actionCall(K6_VSS_PS_turnoff);
        ds.waitCall(0.010);
        }
        ds.sequentialEnd();
        measurement.setSetups(ds);
    }


    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- ContinuityNeg Test START ------->\n");

        String suiteName = context.getTestSuiteName();
        String mapKey = "ContinuityNeg";

        // Start each PRE run with no values left over from a previous device/run.
        if ("Main.contySubFlow.ContinuityNeg".equals(suiteName)) {
            storedPreResults.clear();
            if (ptdDC.getLowLimit() != null && ptdDC.getHighLimit() != null) {
                preLowLimit = ptdDC.getLowLimit().doubleValue();
                preHighLimit = ptdDC.getHighLimit().doubleValue();
            }
        }

        measurement.execute();

        // Preserve all DCVI voltage measurements before evaluating individual pins.
        IDcVIResults results = measurement.dcVI("").preserveResults();
        Map<String, MultiSiteDoubleArray> measuredVoltages = results.vmeas("").getVoltage();


        int testNumberFromTesttable = ptdDC.getTestNumber();

        if ("Main.contySubFlow.ContinuityNeg".equals(suiteName)) {
            // PRE: save every pin result for comparison during POST, then run normal continuity limits.
            storedPreResults.put(mapKey, measuredVoltages);
            int testNumber = ptdDC.getTestNumber();

        for (Entry<String, MultiSiteDoubleArray> entry : measuredVoltages.entrySet()) {
            String pinOrGroupName = entry.getKey();

            MultiSiteDoubleArray voltage = entry.getValue();

            // Assign the test name and number for the current result.
            ptdDC.setTestText("CONTINUITY_NEG__" + pinOrGroupName + "=-100uA_VDD=0V_VDDQ=0V")
                    .setTestNumber(testNumber);

            // Evaluate the measured continuity voltage.
            ptdDC.evaluate(voltage, 0, measurement);

            // Print the measured voltage for the current pin or pin group.
            println("Measured ContinuityNeg voltage on "
                    + pinOrGroupName + ": " + voltage + " V");

            // Reserve ten test-number slots per measured pin or pin group.
            testNumber += 10;
        }
        ptdDC.setTestText("CONTINUITY_NEG__-100uA_VDD=0V_VDDQ=0V")
                .setTestNumber(testNumberFromTesttable);
        }
        if ("Main.postContySubFlow.ContinuityNeg".equals(suiteName)) {
            // POST: compare the new voltage with the matching saved PRE voltage.
            Map<String, MultiSiteDoubleArray> preMeasuredVoltages = storedPreResults.get(mapKey);
            int testNumber = ptdDC.getTestNumber();

            double lowLimit = (preLowLimit != null) ? preLowLimit
                    : (ptdDC.getLowLimit() != null ? ptdDC.getLowLimit().doubleValue() : -0.8);
            double highLimit = (preHighLimit != null) ? preHighLimit
                    : (ptdDC.getHighLimit() != null ? ptdDC.getHighLimit().doubleValue() : -0.2);

            // Guard against ptdDC retaining delta limits (-0.035, 0.035) from a previous run or dirty session
            if (Math.abs(lowLimit - (-0.035)) < 1e-6 && Math.abs(highLimit - 0.035) < 1e-6) {
                if (preLowLimit != null && preHighLimit != null) {
                    lowLimit = preLowLimit;
                    highLimit = preHighLimit;
                } else {
                    lowLimit = -0.8;
                    highLimit = -0.2;
                }
            }

            try {
                if (preMeasuredVoltages == null) {
                    println("No PRE ContinuityNeg results found; ContinuityNeg delta is not evaluated.");
                } else {
                    for (Entry<String, MultiSiteDoubleArray> entry : measuredVoltages.entrySet()) {
                        String pinOrGroupName = entry.getKey();
                        MultiSiteDoubleArray preVoltage = preMeasuredVoltages.get(pinOrGroupName);
                        MultiSiteDoubleArray postVoltage = entry.getValue();

                        if (preVoltage == null) {
                            println("No PRE continuity voltage found for " + pinOrGroupName
                                    + "; delta is not evaluated.");
                            continue;
                        }

                        ptdDC.setLowLimit(lowLimit).setHighLimit(highLimit);

                        // Assign the test name and number for the current result.
                        ptdDC.setTestText("POST_CONTINUITY_NEG__" + pinOrGroupName + "=-100uA_VDD=0V_VDDQ=0V")
                                .setTestNumber(testNumber);

                        // Evaluate the measured continuity voltage.
                        ptdDC.evaluate(postVoltage, 0, measurement);

                        testNumber += 10;

                        // Delta is signed: POST voltage minus PRE voltage, calculated per test site.
                        MultiSiteDouble deltaVoltage = new MultiSiteDouble();
                        for (int site : context.getActiveSites()) {
                            double delta = postVoltage.getElement(site, 0)
                                    - preVoltage.getElement(site, 0);
                            deltaVoltage.set(site, delta);
                        }

                        ptdDC.setLowLimit(-0.035).setHighLimit(0.035);

                        ptdDC.setTestText("CONTINUITYNEG_DELTA_" + pinOrGroupName)
                                .setTestNumber(testNumber);
                        ptdDC.evaluate(deltaVoltage);

                        println("ContinuityNeg delta on " + pinOrGroupName + ": "
                                + deltaVoltage + " V");
                        testNumber += 10;
                    }
                }
            } finally {
                // Restore test table text, number, and continuity limits for subsequent runs
                ptdDC.setLowLimit(lowLimit).setHighLimit(highLimit);
                ptdDC.setTestText("POST_CONTINUITY_NEG__-100uA_VDD=0V_VDDQ=0V")
                        .setTestNumber(testNumberFromTesttable);
            }
        }

        println("\n<------- ContinuityNeg Test END ------->\n");
    }
}
