package leakage.tml;

import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : IQ_VDDQ
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Force VDD to 5.5 V.
 * 2. Force VDDQGroup and SQMGroup to 50 V.
 * 3. Force SQPGroup, LFIRE, and HFIRE to 0 V.
 * 4. Force ARM to 5.5 V.
 * 5. Measure total VDDQ current at ISET = 100 uA and ISET = 1 mA.
 * 6. Datalog and optionally store both total VDDQ-current results.
 */
public class IQ_VDDQ extends TestMethod {

    public IMeasurement measurement;

    public IParametricTestDescriptor ptdDC1;
    public IParametricTestDescriptor ptdDC2;
    public IParametricTestDescriptor ptdDelta1;
    public IParametricTestDescriptor ptdDelta2;

    public String gVariableNameOutput1 = "";
    public String gVariableNameOutput2 = "";

    /** Total VDDQ current measured at ISET = 100 uA. */
    public MultiSiteDouble totalCurrent100uA = new MultiSiteDouble(0.0);

    /** Total VDDQ current measured at ISET = 1 mA. */
    public MultiSiteDouble totalCurrent1mA = new MultiSiteDouble(0.0);

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND").setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        // Configure VDD for the VDDQ current test.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.025);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Configure ARM for the VDDQ current test.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM to 5.5 V.
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure LFIRE and HFIRE as one setup group.
        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        // Force selected LFIRE/HFIRE signal to 0 V.
        ISetupDcVI.IVforce forceLfireHfireTo0V =
                lfireHfire.vforce("force_lfire_hfire_0V")
                        .setForceValue(0.0)
                        .setVrange(6.0)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Configure the VDDQ pin group.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQ1_AVI1");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force VDDQGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceVddqGroupTo50V =
                vddqGroup.vforce("force_vddq_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);
        forceVddqGroupTo50V.regulation().setVslewrate(100e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Measure current on each VDDQ channel.
        ISetupDcVI.IImeas measureVddqCurrent =
                vddqGroup.imeas("measure_vddq_current")
                        .setIrange(0.005);

        // Configure the SQP pin group.
        ISetupDcVI sqpGroup = ds.addDcVI("SQP1_AVI1");
        sqpGroup.setConnect(true).setDisconnect(true);

        // Force SQPGroup to 0 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqpGroupTo0V =
                sqpGroup.vforce("force_sqp_group_0V")
                        .setForceValue(0.0)
                        .setVrange(3.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);
        forceSqpGroupTo0V.regulation().setVslewrate(50e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure the SQM pin group.
        ISetupDcVI sqmGroup = ds.addDcVI("SQM1_AVI1");
        sqmGroup.setConnect(true).setDisconnect(true);

        // Force SQMGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqmGroupTo50V =
                sqmGroup.vforce("force_sqm_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);
        forceSqmGroupTo50V.regulation().setVslewrate(50e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure ISET for the two VDDQ current conditions.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force 100 uA on ISET.
        ISetupAction forceIset100uA = iset.iforce("force_iset_100uA")
                .setForceValue(-100e-6)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Force 1 mA on ISET.
        ISetupAction forceIset1mA = iset.iforce("force_iset_1mA")
                .setForceValue(-1e-3)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        ds.parallelBegin("IQ_VDDQ_100UA");
        {
            ds.sequentialBegin("measure_vddq_current_at_100uA");
            {
                // Dynamic relay control: connect VSS to GND, connect ISET to PS
                ds.actionCall(K5_VSS_GND_utility_1);
                ds.actionCall(K4_ISET_PS_utility_1);
                ds.waitCall(0.010);

                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqGroupTo50V);
                ds.actionCall(forceSqpGroupTo0V);
                ds.actionCall(forceSqmGroupTo50V);
                ds.actionCall(forceIset100uA);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfireHfireTo0V);
                ds.waitCall(0.02);
                ds.actionCall(measureVddqCurrent);

                // Safe shutdown: turn off dynamic relays
                ds.actionCall(K5_VSS_GND_utility_0);
                ds.actionCall(K4_ISET_PS_utility_0);
                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        ds.parallelBegin("IQ_VDDQ_1MA");
        {
            ds.sequentialBegin("measure_vddq_current_at_1mA");
            {
                // Dynamic relay control: connect VSS to GND, connect ISET to PS
                ds.actionCall(K5_VSS_GND_utility_1);
                ds.actionCall(K4_ISET_PS_utility_1);
                ds.waitCall(0.010);

                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqGroupTo50V);
                ds.actionCall(forceSqpGroupTo0V);
                ds.actionCall(forceSqmGroupTo50V);
                ds.actionCall(forceIset1mA);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfireHfireTo0V);
                ds.waitCall(0.05);
                ds.actionCall(measureVddqCurrent);

                // Safe shutdown: turn off dynamic relays
                ds.actionCall(K5_VSS_GND_utility_0);
                ds.actionCall(K4_ISET_PS_utility_0);
                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- IQ_VDDQ Leakage Current Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("VDDQ1_AVI1").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredCurrents =
                results.imeas("").getCurrent();

        for (int site : context.getActiveSites()) {
            double totalCurrentAt100uA = 0.0;
            double totalCurrentAt1mA = 0.0;

            println("------ SITE " + site + " ------");

            for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
                String signalName = entry.getKey();
                MultiSiteDoubleArray currentMeasurements = entry.getValue();

                double currentAt100uA =
                        currentMeasurements.getElement(0).get(site);

                double currentAt1mA =
                        currentMeasurements.getElement(1).get(site);

                totalCurrentAt100uA += currentAt100uA;
                totalCurrentAt1mA += currentAt1mA;

                println(signalName
                        + " | ISET = 100 uA: " + currentAt100uA + " A"
                        + " | ISET = 1 mA: " + currentAt1mA + " A");
            }

            totalCurrent100uA.set(site, totalCurrentAt100uA);
            totalCurrent1mA.set(site, totalCurrentAt1mA);

            println("Total VDDQ current at ISET = 100 uA: "
                    + totalCurrentAt100uA + " A");

            println("Total VDDQ current at ISET = 1 mA: "
                    + totalCurrentAt1mA + " A");
        }

        println("Final total VDDQ current at ISET = 100 uA: "
                + totalCurrent100uA + " A");

        println("Final total VDDQ current at ISET = 1 mA: "
                + totalCurrent1mA + " A");

        // Store total VDDQ current at 100 uA when configured.
        if (!gVariableNameOutput1.isEmpty()) {
            context.testProgram().variables().set(
                    gVariableNameOutput1,
                    totalCurrent100uA);

            println("Stored VDDQ current at 100 uA in "+ gVariableNameOutput1 + ": "
                    + context.testProgram().variables().getDouble(gVariableNameOutput1)+ " A");
        }

        // Store total VDDQ current at 1 mA when configured.
        if (!gVariableNameOutput2.isEmpty()) {
            context.testProgram().variables().set(gVariableNameOutput2,totalCurrent1mA);

            println("Stored VDDQ current at 1 mA in " + gVariableNameOutput2 + ": "
                    + context.testProgram().variables().getDouble(gVariableNameOutput2)+ " A");
        }

        // Datalog total VDDQ current measured at ISET = 100 uA.
        ptdDC1.evaluate(totalCurrent100uA);

        // Datalog total VDDQ current measured at ISET = 1 mA.
        ptdDC2.evaluate(totalCurrent1mA);

        String suiteName = context.getTestSuiteName();

        if ("Main.leakageIPostStressSubFlow.IQ_VDDQ".equals(suiteName)) {

            MultiSiteDouble IQ_VDDQ_PreStressIset100uA = context.testProgram().variables().getDouble("IQ_VDDQ_PreStressIset100uA");

            MultiSiteDouble delta_IQ_VDDQ_ISET100uA = totalCurrent100uA.subtract(IQ_VDDQ_PreStressIset100uA);
            ptdDelta1.evaluate(delta_IQ_VDDQ_ISET100uA);

            MultiSiteDouble IQ_VDDQ_PreStressIset1mA = context.testProgram().variables().getDouble("IQ_VDDQ_PreStressIset1mA");

            MultiSiteDouble delta_IQ_VDDQ_ISET1mA = totalCurrent1mA.subtract(IQ_VDDQ_PreStressIset1mA);
            ptdDelta2.evaluate(delta_IQ_VDDQ_ISET1mA);
        }

        println("\n<------- IQ_VDDQ Leakage Current Test END ------->\n");
    }
}
