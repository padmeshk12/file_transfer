package leakage.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformRamp;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : IQ_VDD
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Force VDD to 5.5 V.
 * 2. Force VDDQGroup and SQMGroup to 50 V.
 * 3. Force SQPGroup, LFIRE, and HFIRE to 0 V.
 * 4. Force ARM to 5.5 V.
 * 5. Measure VDD current with ISET forced first to 100 uA and then to 1 mA.
 * 6. Datalog and optionally store each VDD-current result.
 */
public class IQ_VDD extends TestMethod {

    public IMeasurement measurement;

    public IParametricTestDescriptor ptdDC1;
    public IParametricTestDescriptor ptdDC2;
    public IParametricTestDescriptor ptdDelta1;
    public IParametricTestDescriptor ptdDelta2;

    public String gVariableNameOutput1 = "";
    public String gVariableNameOutput2 = "";

    // Hardware current ramp parameters for ISET (0 uA to 1 mA)
    public double isetRampStart = -0.0;     // 0 uA
    public double isetRampStop = -1e-3;     // 1 mA (1000 uA)
    public long rampSamples = 200;         // 200 samples (5 uA resolution)
    public long rampSampleRate = 10000;    // 10 kHz -> 20 ms ramp duration

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND").setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        // Configure VDD for current measurement.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.025);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Measure the current drawn from VDD.
        ISetupDcVI.IImeas measureVddCurrent = vdd.imeas("measure_vdd_current")
                .setIrange(0.0025)
                .setRestoreIrange(true);

        // Configure ARM for the VDD current test.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM to 5.5 V.
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure LFIRE and HFIRE as one setup group.
        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        // Force selected LFIRE/HFIRE signal to 0 V.
        ISetupDcVI.IVforce forceLfireHfireTo0V =
                lfireHfire.vforce("force_lfire_hfire_0V")
                        .setForceValue(0.0)
                        .setVrange(6.0)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Configure the VDDQ pin group.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQGroup");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force VDDQGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceVddqGroupTo50V =
                vddqGroup.vforce("force_vddq_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclampSource(0.1)
                        .setIclampSink(0.1);
        forceVddqGroupTo50V.regulation().setVslewrate(10e3).setCapacitance(1e-6).setVbandwidth(10e3).setIbandwidth(10e3); // 100 mV/us = 0.1 V/us = 100e3 V/s
        ISetupDcVI.IVforce forceVddqGroupTo0V =
                vddqGroup.vforce("force_vddq_group_0V")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclamp(0.1);
        forceVddqGroupTo0V.regulation().setVslewrate(10e3).setCapacitance(1e-6).setVbandwidth(10e3).setIbandwidth(10e3); // 100 mV/us = 0.1 V/us = 100e3 V/s


        // Configure the SQP pin group.
        ISetupDcVI sqpGroup = ds.addDcVI("SQPGroup");
        sqpGroup.setConnect(true).setDisconnect(true);

        // Force SQPGroup to 0 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqpGroupTo0V =
                sqpGroup.vforce("force_sqp_group_0V")
                .setForceValue(0)
                .setVrange(5.5)
                .setIclamp(0.1);

        forceSqpGroupTo0V.regulation().setVslewrate(10e3).setCapacitance(1e-6).setVbandwidth(10e3).setIbandwidth(10e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure the SQM pin group.
        ISetupDcVI sqmGroup = ds.addDcVI("SQMGroup");
        sqmGroup.setConnect(true).setDisconnect(true);

        // Force SQMGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqmGroupTo50V =
                sqmGroup.vforce("force_sqm_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclampSource(0.1)
                        .setIclampSink(0.1);
        forceSqmGroupTo50V.regulation().setVslewrate(10e3).setCapacitance(1e-6).setVbandwidth(10e3).setIbandwidth(10e3); // 100 mV/us = 0.1 V/us = 100e3 V/s
        ISetupDcVI.IVforce forceSqmGroupTo0V =
                sqmGroup.vforce("force_sqm_group_0V")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclamp(0.1);
        forceSqmGroupTo0V.regulation().setVslewrate(10e3).setCapacitance(1e-6).setVbandwidth(10e3).setIbandwidth(10e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure ISET for the two VDD current conditions.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force 100 uA on ISET.
        ISetupAction forceIset100uA = iset.iforce("force_iset_100uA")
                .setForceValue(-100e-6)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Force 1 mA on ISET.
        ISetupAction forceIset1mA = iset.iforce("force_iset_1mA")
                .setForceValue(-1e-3)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Define ISET hardware current ramp from 0 uA to 1 mA
        ISetupWaveformRamp isetRamp = ds.addWaveformRamp("iset_ramp_0_to_1mA")
                .setStartValue(isetRampStart)
                .setStopValue(isetRampStop)
                .setSamples(rampSamples)
                .setSampleRate(rampSampleRate);

        ISetupDcVI.ISourceWaveform sourceIsetRamp = iset.sourceWaveform("source_iset_ramp")
                .setForceTypeCurrent()
                .setWaveform(isetRamp)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Current waveform measurement on VDD_DPS during the ISET ramp
        ISetupDcVI.IMeasureWaveform measureVddCurrentWaveform = vdd.measureWaveform("measure_vdd_current_waveform")
                .setMeasTypeCurrent()
                .setIrange(0.025)
                .setRestoreIrange(true)
                .setSamples(rampSamples)
                .setSampleRate(rampSampleRate);

        ds.parallelBegin("IQ_VDD_100UA");
        {
            ds.sequentialBegin("measure_vdd_current_at_100uA");
            {
                // Dynamic relay control: connect VSS to GND, connect ISET to PS
                ds.actionCall(K5_VSS_GND_utility_1);
                ds.actionCall(K4_ISET_PS_utility_1);

                ds.waitCall(0.010);

                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqGroupTo50V);
                ds.actionCall(forceSqpGroupTo0V);
                ds.actionCall(forceSqmGroupTo50V);

                ds.actionCall(forceIset100uA);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfireHfireTo0V);
                ds.waitCall(0.1);
                ds.actionCall(measureVddCurrent);
                ds.waitCall(0.1);
                // Safe shutdown: turn off dynamic relays
//                ds.actionCall(K5_VSS_GND_utility_0);
//                ds.actionCall(K4_ISET_PS_utility_0);
                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        ds.parallelBegin("IQ_VDD_1MA");
        {
            ds.sequentialBegin("measure_vdd_current_at_1mA");
            {
                // Dynamic relay control: connect VSS to GND, connect ISET to PS
//                ds.actionCall(K5_VSS_GND_utility_1);
//                ds.actionCall(K4_ISET_PS_utility_1);
                ds.waitCall(0.010);

                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqGroupTo50V);
                ds.actionCall(forceSqpGroupTo0V);
                ds.actionCall(forceSqmGroupTo50V);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfireHfireTo0V);
                ds.waitCall(0.1);

                // Hardware current ramp on ISET while capturing VDD current waveform
                ds.parallelBegin("ramp_iset_and_measure_vdd");
                {
                    ds.sequentialBegin();
                    {
                        ds.actionCall(sourceIsetRamp);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin();
                    {
                        ds.actionCall(measureVddCurrentWaveform);
                    }
                    ds.sequentialEnd();
                }
                ds.parallelEnd();

                // Static DC measurement at 1 mA for ptdDC2 (Test 11010)
                ds.actionCall(forceIset1mA);
                ds.waitCall(0.050);
                ds.actionCall(measureVddCurrent);

                // Safe shutdown: turn off dynamic relays
                ds.actionCall(K5_VSS_GND_utility_0);
                ds.actionCall(K4_ISET_PS_utility_0);
                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- IQ_VDD Leakage Current Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("").preserveResults();

        MultiSiteDoubleArray vddCurrentMeasurements =
                results.imeas("").getCurrent("VDD_DPS");

        MultiSiteDouble vddCurrentAt100uA =
                vddCurrentMeasurements.getElement(0);

        MultiSiteDouble vddCurrentAt1mA =
                vddCurrentMeasurements.getElement(1);

        println("VDD current at ISET = 100 uA: "
                + vddCurrentAt100uA + " A");

        println("VDD current at ISET = 1 mA: "
                + vddCurrentAt1mA + " A");

        // Retrieve and process continuous VDD current waveform captured during ISET ramp (0 uA to 1 mA)
        try {
            MultiSiteWaveDouble vddWaveform = results.measureWaveform("measure_vdd_current_waveform")
                    .getWaveform("VDD_DPS").getElement(0);

            for (int site : context.getActiveSites()) {
                double[] vddSamples = vddWaveform.getArray(site);
                int count = vddSamples.length;
                println("\n================================================================================");
                println("  Site " + site + ": VDD Current vs ISET Ramp (0 uA -> 1000 uA, " + count + " samples)");
                println("================================================================================");

                double zeroCrossingIset = -1.0;
                double prevCurrent = (count > 0) ? vddSamples[0] * 1e6 : 0.0;

                for (int i = 0; i < count; i++) {
                    double isetVal_uA = (isetRampStart + i * (isetRampStop - isetRampStart) / Math.max(1, count - 1)) * 1e6;
                    double vddCurr_uA = vddSamples[i] * 1e6;

                    // Log every 10th sample, endpoints, and fine detail around the critical 450 uA - 700 uA transition
                    if (i % 10 == 0 || (isetVal_uA >= 450.0 && isetVal_uA <= 700.0) || i == count - 1) {
                        println(String.format("  [Sample %3d]  ISET = %7.1f uA  -->  VDD Current = %+8.3f uA", i, isetVal_uA, vddCurr_uA));
                    }

                    // Zero-crossing detection: when current flips from positive to negative
                    if (i > 0 && prevCurrent >= 0.0 && vddCurr_uA < 0.0 && zeroCrossingIset < 0) {
                        zeroCrossingIset = isetVal_uA;
                        println(String.format("  >>> [ZERO-CROSSING] at ISET ~ %.1f uA: VDD Current flips from POSITIVE to NEGATIVE <<<", isetVal_uA));
                    }
                    prevCurrent = vddCurr_uA;
                }

                if (zeroCrossingIset >= 0) {
                    println(String.format(">>> Summary (Site %d): VDD Current crosses 0 uA into negative at ISET ~ %.1f uA\n", site, zeroCrossingIset));
                } else {
                    println(String.format(">>> Summary (Site %d): No zero-crossing detected in 0 uA to 1000 uA range.\n", site));
                }
            }
        } catch (Exception e) {
            println("Info: Could not retrieve/process VDD current waveform: " + e.getMessage());
        }

        // Store VDD current at 100 uA when an output variable is configured.
        if (!gVariableNameOutput1.isEmpty()) {
            context.testProgram().variables().set(
                    gVariableNameOutput1,
                    vddCurrentAt100uA);

            println("Stored VDD current at 100 uA in "
                    + gVariableNameOutput1 + ": "
                    + context.testProgram().variables()
                            .getDouble(gVariableNameOutput1)
                    + " A");
        }

        // Store VDD current at 1 mA when an output variable is configured.
        if (!gVariableNameOutput2.isEmpty()) {
            context.testProgram().variables().set(
                    gVariableNameOutput2,
                    vddCurrentAt1mA);

            println("Stored VDD current at 1 mA in "
                    + gVariableNameOutput2 + ": "
                    + context.testProgram().variables()
                            .getDouble(gVariableNameOutput2)
                    + " A");
        }

        // Datalog VDD current measured with 100 uA ISET force.
        ptdDC1.evaluate(vddCurrentAt100uA);

        // Datalog VDD current measured with 1 mA ISET force.
        ptdDC2.evaluate(vddCurrentAt1mA);

        String suiteName = context.getTestSuiteName();

        if ("Main.leakageIPostStressSubFlow.IQ_VDD".equals(suiteName)) {

            MultiSiteDouble IQ_VDD_PreStressIset100uA = context.testProgram().variables().getDouble("IQ_VDD_PreStressIset100uA");

            MultiSiteDouble delta_IQ_VDD_ISET100uA = vddCurrentAt100uA.subtract(IQ_VDD_PreStressIset100uA);
            ptdDelta1.evaluate(delta_IQ_VDD_ISET100uA);

            MultiSiteDouble IQ_VDD_PreStressIset1mA = context.testProgram().variables().getDouble("IQ_VDD_PreStressIset1mA");

            MultiSiteDouble delta_IQ_VDD_ISET1mA = vddCurrentAt1mA.subtract(IQ_VDD_PreStressIset1mA);
            ptdDelta2.evaluate(delta_IQ_VDD_ISET1mA);
        }

        println("\n<------- IQ_VDD Leakage Current Test END ------->\n");
    }
}
