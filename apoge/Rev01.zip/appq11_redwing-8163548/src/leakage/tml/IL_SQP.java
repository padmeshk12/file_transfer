package leakage.tml;

import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : IL_SQP
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Force VDD to 5.5 V.
 * 2. Force VDDQGroup and SQMGroup to 50 V.
 * 3. Force SQPGroup, LFIRE, and HFIRE to 0 V.
 * 4. Force ARM to 5.5 V and ISET to 1 mA.
 * 5. Measure current on each SQP channel.
 * 6. Calculate, datalog, and optionally store total SQP leakage current.
 */
public class IL_SQP extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;
    public IParametricTestDescriptor ptdDelta;

    public String gVariableNameOutput = "";

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND").setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        // Configure VDD for the SQP leakage-current test.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.025);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Configure ARM for the SQP leakage-current test.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM to 5.5 V.
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure LFIRE and HFIRE as one setup group.
        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        // Force selected LFIRE/HFIRE signal to 0 V.
        ISetupDcVI.IVforce forceLfireHfireTo0V =
                lfireHfire.vforce("force_lfire_hfire_0V")
                        .setForceValue(0.0)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Configure the VDDQ pin group.
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQ1_AVI1");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force VDDQGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceVddqGroupTo50V =
                vddqGroup.vforce("force_vddq_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);
        forceVddqGroupTo50V.regulation().setVslewrate(100e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure the SQP pin group.
        ISetupDcVI sqpGroup = ds.addDcVI("SQP1_AVI1");
        sqpGroup.setConnect(true).setDisconnect(true);

        // Force SQPGroup to 0 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqpGroupTo0V =
                sqpGroup.vforce("force_sqp_group_0V")
                        .setForceValue(0.0)
                        .setVrange(3.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);
        forceSqpGroupTo0V.regulation().setVslewrate(100e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Measure current on each SQP channel.
        ISetupDcVI.IImeas measureSqpCurrent =
                sqpGroup.imeas("measure_sqp_current")
                        .setIrange(5e-6);

        // Configure the SQM pin group.
        ISetupDcVI sqmGroup = ds.addDcVI("SQM1_AVI1");
        sqmGroup.setConnect(true).setDisconnect(true);

        // Force SQMGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqmGroupTo50V =
                sqmGroup.vforce("force_sqm_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.005)
                        .setIclamp(0.005);
        forceSqmGroupTo50V.regulation().setVslewrate(100e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure ISET for the SQP leakage-current test.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force 1 mA on ISET.
        ISetupAction forceIset1mA = iset.iforce("force_iset_1mA")
                .setForceValue(-1e-3)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        ds.parallelBegin("IL_SQP");
        {
            ds.sequentialBegin("measure_sqp_leakage_current");
            {
                // Dynamic relay control: connect VSS to GND, connect ISET to PS
                ds.actionCall(K5_VSS_GND_utility_1);
                ds.actionCall(K4_ISET_PS_utility_1);
                ds.waitCall(0.010);

                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqGroupTo50V);
                ds.actionCall(forceSqpGroupTo0V);
                ds.actionCall(forceSqmGroupTo50V);
                ds.actionCall(forceIset1mA);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfireHfireTo0V);
                ds.waitCall(0.02);
                ds.actionCall(measureSqpCurrent);

                // Safe shutdown: turn off dynamic relays
                ds.actionCall(K5_VSS_GND_utility_0);
                ds.actionCall(K4_ISET_PS_utility_0);
                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- IL_SQP Leakage Current Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("SQP1_AVI1").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredCurrents =
                results.imeas("").getCurrent();

        MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {
            double totalCurrentPerSite = 0.0;

            println("------ SITE " + site + " ------");

            for (Entry<String, MultiSiteDoubleArray> entry : measuredCurrents.entrySet()) {
                String signalName = entry.getKey();
                MultiSiteDouble measuredCurrent = entry.getValue().getElement(0);

                double currentPerSignal = measuredCurrent.get(site);
                totalCurrentPerSite += currentPerSignal;

                println("Signal: " + signalName
                        + " | Current: " + currentPerSignal + " A");
            }

            // Test plan Table 9: "Measure leakage current from SQP pin".
            // Current emerging from DUT pin into tester instrument is negative in ATE sign convention;
            // take absolute value so positive leakage magnitude is evaluated against the [0, 2000] uA limits.
            double absLeakageCurrent = Math.abs(totalCurrentPerSite);
            totalCurrent.set(site, absLeakageCurrent);

            println("Total SQP leakage current from pin at site "
                    + site + ": " + absLeakageCurrent + " A");
        }

        println("Final total SQP current: " + totalCurrent + " A");

        // Store total SQP current when an output variable is configured.
        if (!gVariableNameOutput.isEmpty()) {
            context.testProgram().variables().set(
                    gVariableNameOutput,
                    totalCurrent);

            println("Stored total SQP current in "
                    + gVariableNameOutput + ": "
                    + context.testProgram().variables()
                            .getDouble(gVariableNameOutput)
                    + " A");
        }

        // Datalog total SQP leakage current.
        ptdDC.evaluate(totalCurrent);

        String suiteName = context.getTestSuiteName();

        if ("Main.leakageIPostStressSubFlow.IL_SQP".equals(suiteName)) {
            MultiSiteDouble IL_SQP_PreStress = context.testProgram().variables().getDouble("IL_SQP_PreStress");

            MultiSiteDouble delta_IL_SQP = totalCurrent.subtract(IL_SQP_PreStress);
            ptdDelta.evaluate(delta_IL_SQP);
        }

        println("\n<------- IL_SQP Leakage Current Test END ------->\n");
    }
}
