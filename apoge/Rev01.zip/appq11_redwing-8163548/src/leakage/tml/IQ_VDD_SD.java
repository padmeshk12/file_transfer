package leakage.tml;

import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : IQ_VDD_SD
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Force VDD to 5.5 V.
 * 2. Force VDDQGroup and SQMGroup to 50 V.
 * 3. Force SQPGroup and ARM to 0 V.
 * 4. Measure the current drawn from VDD.
 * 5. Datalog and optionally store the measured VDD leakage current.
 */
public class IQ_VDD_SD extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;
    public IParametricTestDescriptor ptdDelta;

    /**
     * Optional test-program variable used to store the measured VDD leakage current.
     */
    public String gVariableNameOutput = "";

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ds.importSpec("common.pinGroups");

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND").setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS").setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        // Configure VDD for leakage-current measurement.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.025);

        // Force VDD to 5.5 V (DPS channel does not support hardware vslewrate).
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Measure the current drawn from VDD.
        ISetupDcVI.IImeas measureVddCurrent = vdd.imeas("measure_vdd_current")
                .setIrange(0.0025)
                .setRestoreIrange(true);

        // Configure ARM for the shutdown leakage condition.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM to 0 V.
        ISetupDcVI.IVforce forceArmTo0V = arm.vforce("force_arm_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure LFIRE and HFIRE to ensure solid ground
        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce forceLfireHfireTo0V =
                lfireHfire.vforce("force_lfire_hfire_0V")
                        .setForceValue(0.0)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Configure the VDDQ pin group (AVI channels).
        ISetupDcVI vddqGroup = ds.addDcVI("VDDQGroup");
        vddqGroup.setConnect(true).setDisconnect(true);

        // Force VDDQGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceVddqGroupTo50V =
                vddqGroup.vforce("force_vddq_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);
        forceVddqGroupTo50V.regulation().setVslewrate(100e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        // Configure the SQP pin group.
        ISetupDcVI sqpGroup = ds.addDcVI("SQPGroup");
        sqpGroup.setConnect(true).setDisconnect(true);

        // Force SQPGroup to 0 V.
        ISetupDcVI.IVforce forceSqpGroupTo0V =
                sqpGroup.vforce("force_sqp_group_0V")
                        .setForceValue(0.0)
                        .setVrange(3.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);

        // Configure the SQM pin group (AVI channels).
        ISetupDcVI sqmGroup = ds.addDcVI("SQMGroup");
        sqmGroup.setConnect(true).setDisconnect(true);

        // Force SQMGroup to 50 V with 100 mV/us slew rate (100e3 V/s)
        ISetupDcVI.IVforce forceSqmGroupTo50V =
                sqmGroup.vforce("force_sqm_group_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);
        forceSqmGroupTo50V.regulation().setVslewrate(100e3); // 100 mV/us = 0.1 V/us = 100e3 V/s

        ds.sequentialBegin("IQ_VDD_SD");
        {
            // Dynamic relay control: connect VSS to GND, disconnect ISET
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_0);
            ds.waitCall(0.010);

            ds.actionCall(forceVdd5p5V);
            ds.actionCall(forceVddqGroupTo50V);
            ds.actionCall(forceSqpGroupTo0V);
            ds.actionCall(forceSqmGroupTo50V);
            ds.actionCall(forceArmTo0V);
            ds.actionCall(forceLfireHfireTo0V);
            ds.waitCall(0.02);
            ds.actionCall(measureVddCurrent);

            // Safe shutdown: turn off dynamic relays
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        println("\n<------- IQ_VDD_SD Leakage Current Test START ------->\n");

        measurement.execute();

        IDcVIResults results = measurement.dcVI("VDD_DPS").preserveResults();

        Map<String, MultiSiteDoubleArray> measuredCurrents =
                results.imeas("").getCurrent();

        MultiSiteDoubleArray vddCurrentMeasurements =
                results.imeas("").getCurrent("VDD_DPS");

        MultiSiteDouble measuredVddCurrent =
                vddCurrentMeasurements.getElement(0);

        println("Measured VDD leakage current: "
                + measuredVddCurrent + " A");

        // Datalog the VDD leakage-current result.
        ptdDC.evaluate(measuredVddCurrent);

        // Store VDD leakage current when an output variable is configured.
        if (!gVariableNameOutput.isEmpty()) {
            context.testProgram().variables().set(gVariableNameOutput,measuredVddCurrent);

            println("Stored VDD leakage current in " + gVariableNameOutput + ": " + context.testProgram().variables()
                            .getDouble(gVariableNameOutput) + " A");
        }


        String suiteName = context.getTestSuiteName();

        if ("Main.leakageIPostStressSubFlow.IQ_VDD_SD".equals(suiteName)) {
            MultiSiteDouble IQ_VDD_SD_PreStress = context.testProgram().variables().getDouble("IQ_VDD_SD_PreStress");

            MultiSiteDouble delta_IQ_VDD_SD = measuredVddCurrent.subtract(IQ_VDD_SD_PreStress);
            ptdDelta.evaluate(delta_IQ_VDD_SD);
        }

        println("\n<------- IQ_VDD_SD Leakage Current Test END ------->\n");
    }
}
