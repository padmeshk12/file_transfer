package threshold.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformRamp;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Procedure:
 * Apply VDD = 3.3 V, VDDQ = 12 V, TEST = 0.5 V, and hold LFIRE/HFIRE low.
 * Ramp ARM from low to high while monitoring TEST current and ISET voltage
 * to determine ARM_VIH. Ramp ARM from high to low using the same measurements
 * to determine ARM_VIL. Calculate ARM_VHYS = ARM_VIH - ARM_VIL.
 * Datalog ITestARM0, ARM_VIH, ARM_VIL, and ARM_VHYS.
 */

public class ThresholdARMRamp extends TestMethod {

    public IMeasurement measurement;

    public IParametricTestDescriptor ptdDCVIH;
    public IParametricTestDescriptor ptdDCVIL;
    public IParametricTestDescriptor ptdDCVHYS;
    public IParametricTestDescriptor ptdDCARM0;

    public double Vmax = 5.5;
    public double Vmin = 0.0;
    public long nSamples = 128;
    public long rSample = 60000;

    public MultiSiteDouble ITest0 = new MultiSiteDouble(0.0);

    public String gVariableNameInput = "";

    @Override
    public void setup() {
        IDeviceSetup ds = DeviceSetupFactory.createInstance(
                DSAGenerationMode.GENERATE_IN_FILE);

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.05);

        // Force 5.5 V on VDD.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.05)
                .setIclamp(0.05);

        // Force 0 V on VDD for safe power-down.
        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI vddq = ds.addDcVI(
                "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + "
                        + "VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8");
        vddq.setConnect(true).setDisconnect(true);

        // Force 12 V on all VDDQ pins (safe 16V range, <= 12V operation).
        ISetupDcVI.IVforce forceVddq12V = vddq.vforce("force_vddq_12V")
                .setForceValue(12.0)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        // Force 0 V on all VDDQ pins for safe power-down.
        ISetupDcVI.IVforce forceVddq0V = vddq.vforce("force_vddq_0V")
                .setForceValue(0.0)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(true);

        // Hold LFIRE and HFIRE low during the ARM threshold measurement.
        ISetupDcVI.IVforce forceLfireHfireLow =
                lfireHfire.vforce("force_lfire_hfire_low")
                        .setForceValue(0.0)
                        .setVrange(5.75)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Dynamic Relays: K5 (VSS GND), K4 (ISET PS), K2 (ISET 4k), K8 (SQM cap), K12 (SQP cap), K9 (VDD PS)
        ISetupUtility K5_VSS_GND_util = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_0 = K5_VSS_GND_util.setState("K5_VSS_GND_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_1 = K5_VSS_GND_util.setState("K5_VSS_GND_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_util = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_0 = K4_ISET_PS_util.setState("K4_ISET_PS_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_1 = K4_ISET_PS_util.setState("K4_ISET_PS_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_util = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_0 = K2_ISET_R4K_util.setState("K2_ISET_R4K_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_1 = K2_ISET_R4K_util.setState("K2_ISET_R4K_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K8_SQM1_C47UF_util = ds.addUtility("K8_SQM1_C47UF");
        ISetupUtility.ISetState K8_SQM1_C47UF_0 = K8_SQM1_C47UF_util.setState("K8_SQM1_C47UF_0").setValue(0).setSettlingTime(0.02);

        ISetupUtility K12_SQP4_C47UF_util = ds.addUtility("K12_SQP4_C47UF");
        ISetupUtility.ISetState K12_SQP4_C47UF_0 = K12_SQP4_C47UF_util.setState("K12_SQP4_C47UF_0").setValue(0).setSettlingTime(0.02);

        ISetupUtility K9_VDD_PS_util = ds.addUtility("K9_VDD_PS");
        ISetupUtility.ISetState K9_VDD_PS_0 = K9_VDD_PS_util.setState("K9_VDD_PS_0").setValue(0).setSettlingTime(0.02);

        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);

        // Measure ISET voltage during the ARM rising ramp.
        ISetupDcVI.IMeasureWaveform measureIsetVoltageRampUp =
                iset.measureWaveform("measure_iset_voltage_ramp_up")
                        .setMeasTypeVoltage()
                        .setVrange(5.75)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true)
                        .setClockModeLowJitter();

        // Measure ISET voltage during the ARM falling ramp.
        ISetupDcVI.IMeasureWaveform measureIsetVoltageRampDown =
                iset.measureWaveform("measure_iset_voltage_ramp_down")
                        .setMeasTypeVoltage()
                        .setVrange(5.75)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true)
                        .setClockModeLowJitter();

        ISetupDcVI test = ds.addDcVI("TEST_PS");
        test.setConnect(true).setDisconnect(true).setConnectModeStandard();

        // Force 0.5 V on TEST.
        ISetupDcVI.IVforce forceTest0p5V = test.vforce("force_test_0p5V")
                .setForceValue(0.5)
                .setVrange(5.75)
                .setIrange(0.0001)
                .setIclamp(0.0001);

        // Force 0 V on TEST for safe power-down.
        ISetupDcVI.IVforce forceTest0V = test.vforce("force_test_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.0001)
                .setIclamp(0.0001);

        // Measure TEST current during the ARM rising ramp.
        ISetupDcVI.IMeasureWaveform measureTestCurrentRampUp =
                test.measureWaveform("measure_test_current_ramp_up")
                        .setMeasTypeCurrent()
                        .setIrange(0.0001)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true)
                        .setClockModeLowJitter();

        // Measure TEST current during the ARM falling ramp.
        ISetupDcVI.IMeasureWaveform measureTestCurrentRampDown =
                test.measureWaveform("measure_test_current_ramp_down")
                        .setMeasTypeCurrent()
                        .setIrange(0.0001)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true)
                        .setClockModeLowJitter();

        // Define the ARM low-to-high voltage ramp.
        ISetupWaveformRamp armRampUp = ds.addWaveformRamp("arm_ramp_up")
                .setStartValue(Vmin)
                .setStopValue(Vmax)
                .setSamples(nSamples)
                .setSampleRate(rSample);

        // Define the ARM high-to-low voltage ramp.
        ISetupWaveformRamp armRampDown = ds.addWaveformRamp("arm_ramp_down")
                .setStartValue(Vmax)
                .setStopValue(Vmin)
                .setSamples(nSamples)
                .setSampleRate(rSample);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM low before starting the voltage ramp.
        ISetupDcVI.IVforce forceArmLow = arm.vforce("force_arm_low")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Force the ARM low-to-high voltage ramp.
        ISetupDcVI.ISourceWaveform sourceArmRampUp =
                arm.sourceWaveform("source_arm_ramp_up")
                        .setForceTypeVoltage()
                        .setWaveform(armRampUp)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Force the ARM high-to-low voltage ramp.
        ISetupDcVI.ISourceWaveform sourceArmRampDown =
                arm.sourceWaveform("source_arm_ramp_down")
                        .setForceTypeVoltage()
                        .setWaveform(armRampDown)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        ds.sequentialBegin("ARM_THRESHOLD_RAMP");
        {
            // Turn on dynamic relays: K5 (VSS GND), K4 (ISET PS), K2 (ISET 4k)
            // Disconnect unused caps & supplies: K8, K12, K9
            ds.actionCall(K5_VSS_GND_1);
            ds.actionCall(K4_ISET_PS_1);
            ds.actionCall(K2_ISET_R4K_1);
            ds.actionCall(K8_SQM1_C47UF_0);
            ds.actionCall(K12_SQP4_C47UF_0);
            ds.actionCall(K9_VDD_PS_0);
            ds.waitCall(0.010);

            // Static biasing
            ds.actionCall(forceVdd5p5V);
            ds.actionCall(forceVddq12V);
            ds.actionCall(forceArmLow);
            ds.actionCall(forceLfireHfireLow);
            ds.actionCall(forceTest0p5V);
            ds.waitCall(0.1);

            ds.parallelBegin("measure_arm_vih");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(sourceArmRampUp);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureTestCurrentRampUp);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureIsetVoltageRampUp);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.waitCall(0.1);
            ds.parallelBegin("measure_arm_vil");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(sourceArmRampDown);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureTestCurrentRampDown);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureIsetVoltageRampDown);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Safe power-down sequence: return supplies and IOs to 0V before opening relays
            ds.actionCall(forceArmLow);
            ds.actionCall(forceTest0V);
            ds.actionCall(forceVdd0V);
            ds.actionCall(forceVddq0V);
            ds.actionCall(forceLfireHfireLow);
            ds.waitCall(0.010);

            // Safe shutdown & turn off relays
            ds.actionCall(K5_VSS_GND_0);
            ds.actionCall(K4_ISET_PS_0);
            ds.actionCall(K2_ISET_R4K_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        measurement.execute();

        IDcVIResults results = measurement.dcVI("").preserveResults();

        MultiSiteWaveDouble testCurrentRampUp = results.measureWaveform("measure_test_current_ramp_up")
                .getWaveform("TEST_PS").getElement(0);

        MultiSiteWaveDouble testCurrentRampDown = results.measureWaveform("measure_test_current_ramp_down")
                        .getWaveform("TEST_PS").getElement(0);

        MultiSiteWaveDouble isetVoltageRampUp = results.measureWaveform("measure_iset_voltage_ramp_up")
                        .getWaveform("ISET_PS").getElement(0);

        MultiSiteWaveDouble isetVoltageRampDown = results.measureWaveform("measure_iset_voltage_ramp_down")
                        .getWaveform("ISET_PS").getElement(0);

        MultiSiteDouble ARM_VIH = new MultiSiteDouble(999.0);
//        MultiSiteBoolean ARM_VIH_FLAG = new MultiSiteBoolean(false);
        MultiSiteDouble ARM_VIL = new MultiSiteDouble(999.0);
//        MultiSiteBoolean ARM_VIL_FLAG = new MultiSiteBoolean(false);
        MultiSiteDouble ARM_VHYS = new MultiSiteDouble(999.0);

        MultiSiteDouble ITestARM0 = new MultiSiteDouble(0.0);

        int sampleIndex = 0;

        println("\n<------- ARM Threshold Test START ------->");

        if (gVariableNameInput != null && !gVariableNameInput.isEmpty()) {
            ITest0.set(context.testProgram().variables().getDouble(gVariableNameInput));
        }

        // Process the ARM low-to-high ramp to find ARM_VIH.
        for (int site : context.getActiveSites()) {
            double[] testCurrentSamples = testCurrentRampUp.getArray(site);
            double[] isetVoltageSamples = isetVoltageRampUp.getArray(site);
            int sampleCount = testCurrentSamples.length;

            ITestARM0.set(site, testCurrentSamples[0]);
            boolean ARM_VIH_FLAG = false;
            double itest0Val = ITest0.get(site);
            double failsafeLimit = (itest0Val > 0.0) ? (1.5 * itest0Val) : 10e-6;

            for (sampleIndex = 0; sampleIndex < sampleCount; sampleIndex++) {
                if (testCurrentSamples[sampleIndex] < failsafeLimit
                        && isetVoltageSamples[sampleIndex] > 0.2 && !ARM_VIH_FLAG) {
                    ARM_VIH.set(site,
                            Vmin + sampleIndex * (Vmax - Vmin) / (nSamples - 1));
                    ARM_VIH_FLAG = true;
                }
//                println("Site " + site
//                        + " | ARM Ramp Up Voltage: "
//                        + (Vmin + sampleIndex * (Vmax - Vmin) / (nSamples - 1))
//                        + " V | TEST Current: " + testCurrentSamples[sampleIndex]
//                        + " A | ISET Voltage: " + isetVoltageSamples[sampleIndex] + " V");
            }
        }

        // Process the ARM high-to-low ramp to find ARM_VIL.
        for (int site : context.getActiveSites()) {
            double[] testCurrentSamples = testCurrentRampDown.getArray(site);
            double[] isetVoltageSamples = isetVoltageRampDown.getArray(site);
            int sampleCount = testCurrentSamples.length;
            boolean ARM_VIL_FLAG = false;
            double itest0Val = ITest0.get(site);
            double failsafeLimit = (itest0Val > 0.0) ? (1.5 * itest0Val) : 10e-6;

            for (sampleIndex = 0; sampleIndex < sampleCount; sampleIndex++) {
                if (testCurrentSamples[sampleIndex] < failsafeLimit
                        && isetVoltageSamples[sampleIndex] < 0.2 && !ARM_VIL_FLAG) {
                    ARM_VIL.set(site,
                            Vmax - sampleIndex * (Vmax - Vmin) / (nSamples - 1));
                    ARM_VIL_FLAG = true;
                }
//                println("Site " + site
//                        + " | ARM Ramp Down Voltage: "
//                        + (Vmax - sampleIndex * (Vmax - Vmin) / (nSamples - 1))
//                        + " V | TEST Current: " + testCurrentSamples[sampleIndex]
//                        + " A | ISET Voltage: " + isetVoltageSamples[sampleIndex] + " V");
            }
        }

        ARM_VHYS = ARM_VIH.subtract(ARM_VIL);

        for (int site : context.getActiveSites()) {
            println("Site " + site
                    + " | ITestARM0: " + ITestARM0.get(site) + " A"
                    + " | ARM_VIH: " + ARM_VIH.get(site) + " V"
                    + " | ARM_VIL: " + ARM_VIL.get(site) + " V"
                    + " | ARM_VHYS: " + ARM_VHYS.get(site) + " V");
            double itest0Value = ITest0.get(site);
            if (itest0Value > 0.0) {
                ptdDCARM0.setLowLimit(0.9 * itest0Value).setHighLimit(1.1 * itest0Value);
            }
        }

        ptdDCARM0.evaluate(ITestARM0);
        ptdDCVIH.evaluate(ARM_VIH);
        ptdDCVIL.evaluate(ARM_VIL);
        ptdDCVHYS.evaluate(ARM_VHYS);

        println("<------- ARM Threshold Test END ------->\n");
    }
}
