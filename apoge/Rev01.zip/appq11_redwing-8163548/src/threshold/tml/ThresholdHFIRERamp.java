package threshold.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformRamp;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : HFIRE Threshold Ramp Test
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * Apply VDD = 3.3 V, VDDQ = 12 V, TEST = 0.5 V, SQP1_AVI1 = 5 V,
 * hold ARM high and LFIRE low. Ramp HFIRE up and down while monitoring
 * TEST current and SQP voltage to calculate HFIRE_VIH, HFIRE_VIL,
 * and HFIRE_VHYS.
 */
public class ThresholdHFIRERamp extends TestMethod {

    public IMeasurement measurement;

    public IParametricTestDescriptor ptdDCVIH;
    public IParametricTestDescriptor ptdDCVIL;
    public IParametricTestDescriptor ptdDCVHYS;
    public IParametricTestDescriptor ptdDCHFIRE0;

    public double Vmax = 5.5;
    public double Vmin = 0.0;
    public long nSamples = 128;
    public long rSample = 60000;

    public MultiSiteDouble Itest0 = new MultiSiteDouble(0.0);

    public String gVariableNameInput = "";

    @Override
    public void setup() {
        IDeviceSetup ds = DeviceSetupFactory.createInstance(
                DSAGenerationMode.GENERATE_IN_FILE);

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.05);

        // Force 3.3 V on VDD.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_3p3V")
                .setForceValue(5.5)
                .setIrange(0.05)
                .setIclamp(0.05);

        // Force 0 V on VDD for safe power-down.
        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI vddq = ds.addDcVI(
                "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + "
                        + "VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8");
        vddq.setConnect(true).setDisconnect(true);

        // Force 12 V on all VDDQ pins (safe 16V range, <= 12V operation).
        ISetupDcVI.IVforce forceVddq12V = vddq.vforce("force_vddq_12V")
                .setForceValue(12.0)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        // Force 0 V on all VDDQ pins for safe power-down.
        ISetupDcVI.IVforce forceVddq0V = vddq.vforce("force_vddq_0V")
                .setForceValue(0.0)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM low before applying the HFIRE threshold condition.
        ISetupDcVI.IVforce forceArmLow = arm.vforce("force_arm_low")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Force ARM high during the HFIRE threshold ramp.
        ISetupDcVI.IVforce forceArmHigh = arm.vforce("force_arm_high")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Define the HFIRE low-to-high voltage ramp.
        ISetupWaveformRamp hfireRampUp = ds.addWaveformRamp("hfire_ramp_up")
                .setStartValue(Vmin)
                .setStopValue(Vmax)
                .setSamples(nSamples)
                .setSampleRate(rSample);

        // Define the HFIRE high-to-low voltage ramp.
        ISetupWaveformRamp hfireRampDown = ds.addWaveformRamp("hfire_ramp_down")
                .setStartValue(Vmax)
                .setStopValue(Vmin)
                .setSamples(nSamples)
                .setSampleRate(rSample);

        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);

        // Force HFIRE low before starting the voltage ramp.
        ISetupDcVI.IVforce forceHfireLow = hfire.vforce("force_hfire_low")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Force the HFIRE low-to-high voltage ramp.
        ISetupDcVI.ISourceWaveform sourceHfireRampUp =
                hfire.sourceWaveform("source_hfire_ramp_up")
                        .setForceTypeVoltage()
                        .setWaveform(hfireRampUp)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        // Force the HFIRE high-to-low voltage ramp.
        ISetupDcVI.ISourceWaveform sourceHfireRampDown =
                hfire.sourceWaveform("source_hfire_ramp_down")
                        .setForceTypeVoltage()
                        .setWaveform(hfireRampDown)
                        .setIrange(0.001)
                        .setIclamp(0.001);

        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);

        // Hold LFIRE low during the HFIRE threshold ramp.
        ISetupDcVI.IVforce forceLfireLow = lfire.vforce("force_lfire_low")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Dynamic Relays: K5 (VSS GND), K2 (ISET 4k), K4 (ISET PS), K8 (SQM cap), K12 (SQP cap), K9 (VDD PS)
        ISetupUtility K5_VSS_GND_util = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_0 = K5_VSS_GND_util.setState("K5_VSS_GND_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_1 = K5_VSS_GND_util.setState("K5_VSS_GND_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_util = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_0 = K2_ISET_R4K_util.setState("K2_ISET_R4K_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_1 = K2_ISET_R4K_util.setState("K2_ISET_R4K_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_util = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_0 = K4_ISET_PS_util.setState("K4_ISET_PS_0").setValue(0).setSettlingTime(0.02);

        ISetupUtility K8_SQM1_C47UF_util = ds.addUtility("K8_SQM1_C47UF");
        ISetupUtility.ISetState K8_SQM1_C47UF_0 = K8_SQM1_C47UF_util.setState("K8_SQM1_C47UF_0").setValue(0).setSettlingTime(0.02);

        ISetupUtility K12_SQP4_C47UF_util = ds.addUtility("K12_SQP4_C47UF");
        ISetupUtility.ISetState K12_SQP4_C47UF_0 = K12_SQP4_C47UF_util.setState("K12_SQP4_C47UF_0").setValue(0).setSettlingTime(0.02);

        ISetupUtility K9_VDD_PS_util = ds.addUtility("K9_VDD_PS");
        ISetupUtility.ISetState K9_VDD_PS_0 = K9_VDD_PS_util.setState("K9_VDD_PS_0").setValue(0).setSettlingTime(0.02);

        ISetupDcVI test = ds.addDcVI("TEST_PS");
        test.setConnect(true).setDisconnect(true).setConnectModeStandard();

        // Force 0.5 V on TEST.
        ISetupDcVI.IVforce forceTest0p5V = test.vforce("force_test_0p5V")
                .setForceValue(0.5)
                .setVrange(5.75)
                .setIrange(0.0001)
                .setIclamp(0.0001);

        // Force 0 V on TEST for safe power-down.
        ISetupDcVI.IVforce forceTest0V = test.vforce("force_test_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.0001)
                .setIclamp(0.0001);

        // Measure TEST current during the HFIRE rising ramp.
        ISetupDcVI.IMeasureWaveform measureTestCurrentRampUp =
                test.measureWaveform("measure_test_current_ramp_up")
                        .setMeasTypeCurrent()
                        .setIrange(0.0001)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true)
                        .setClockModeLowJitter();

        // Measure TEST current during the HFIRE falling ramp.
        ISetupDcVI.IMeasureWaveform measureTestCurrentRampDown =
                test.measureWaveform("measure_test_current_ramp_down")
                        .setMeasTypeCurrent()
                        .setIrange(0.0001)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true)
                        .setClockModeLowJitter();

        ISetupDcVI sqpReference = ds.addDcVI("SQP1_AVI1");
        sqpReference.setConnect(true).setDisconnect(true);

        // Force 5 V on SQP1_AVI1 (50 mA clamp maintained per debug requirement).
        ISetupDcVI.IVforce forceSqpReference5V =
                sqpReference.vforce("force_sqp1_avi1_5V")
                        .setForceValue(5.0)
                        .setVrange(10.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);

        // Force 0 V on SQP1_AVI1 for safe power-down.
        ISetupDcVI.IVforce forceSqpReference0V =
                sqpReference.vforce("force_sqp1_avi1_0V")
                        .setForceValue(0.0)
                        .setVrange(10.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);

        ISetupDcVI sqpMonitor = ds.addDcVI(
                "SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + "
                        + "SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8");
        sqpMonitor.setConnectModeHighImpedance();

        // Measure SQP voltage during the HFIRE rising ramp (16V range to accurately measure 12V without clipping).
        ISetupDcVI.IMeasureWaveform measureSqpVoltageRampUp =
                sqpMonitor.measureWaveform("measure_sqp_voltage_ramp_up")
                        .setMeasTypeVoltage()
                        .setVrange(16.0)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true);

        // Measure SQP voltage during the HFIRE falling ramp (16V range to accurately measure 12V without clipping).
        ISetupDcVI.IMeasureWaveform measureSqpVoltageRampDown =
                sqpMonitor.measureWaveform("measure_sqp_voltage_ramp_down")
                        .setMeasTypeVoltage()
                        .setVrange(16.0)
                        .setSamples(nSamples)
                        .setSampleRate(rSample)
                        .setHighAccuracy(true);

        ds.sequentialBegin("HFIRE_THRESHOLD_RAMP");
        {
            // Turn on dynamic relays: K5 (VSS GND), K2 (ISET 4k)
            // Disconnect unused caps & supplies: K4, K8, K12, K9
            ds.actionCall(K5_VSS_GND_1);
            ds.actionCall(K2_ISET_R4K_1);
            ds.actionCall(K4_ISET_PS_0);
            ds.actionCall(K8_SQM1_C47UF_0);
            ds.actionCall(K12_SQP4_C47UF_0);
            ds.actionCall(K9_VDD_PS_0);
            ds.waitCall(0.010);

            // Static biasing
            ds.actionCall(forceVdd5p5V);
            ds.actionCall(forceVddq12V);
            ds.actionCall(forceArmLow);
            ds.actionCall(forceLfireLow);
            ds.actionCall(forceHfireLow);
            ds.actionCall(forceTest0p5V);
            ds.actionCall(forceSqpReference5V);
            ds.actionCall(forceArmHigh);
            ds.waitCall(0.005);

            ds.parallelBegin("measure_hfire_vih");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(sourceHfireRampUp);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureTestCurrentRampUp);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureSqpVoltageRampUp);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_hfire_vil");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall(sourceHfireRampDown);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureTestCurrentRampDown);
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall(measureSqpVoltageRampDown);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Safe power-down sequence: return supplies and IOs to 0V before opening relays
            ds.actionCall(forceArmLow);
            ds.actionCall(forceLfireLow);
            ds.actionCall(forceHfireLow);
            ds.actionCall(forceTest0V);
            ds.actionCall(forceSqpReference0V);
            ds.actionCall(forceVdd0V);
            ds.actionCall(forceVddq0V);
            ds.waitCall(0.010);

            // Safe shutdown & turn off relays
            ds.actionCall(K5_VSS_GND_0);
            ds.actionCall(K2_ISET_R4K_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        measurement.execute();

        IDcVIResults results = measurement.dcVI("").preserveResults();

        MultiSiteWaveDouble testCurrentRampUp =
                results.measureWaveform("measure_test_current_ramp_up")
                        .getWaveform("TEST_PS")
                        .getElement(0);

        MultiSiteWaveDouble testCurrentRampDown =
                results.measureWaveform("measure_test_current_ramp_down")
                        .getWaveform("TEST_PS")
                        .getElement(0);

        MultiSiteWaveDouble sqpVoltageRampUp =
                results.measureWaveform("measure_sqp_voltage_ramp_up")
                        .getWaveform("SQP1_AVI2")
                        .getElement(0);

        MultiSiteWaveDouble sqpVoltageRampDown =
                results.measureWaveform("measure_sqp_voltage_ramp_down")
                        .getWaveform("SQP1_AVI2")
                        .getElement(0);

        MultiSiteDouble HFIRE_VIH = new MultiSiteDouble(999.0);
        MultiSiteDouble HFIRE_VIL = new MultiSiteDouble(999.0);
        MultiSiteDouble HFIRE_VHYS = new MultiSiteDouble(999.0);

        MultiSiteDouble ITestHFIRE0 = new MultiSiteDouble(0.0);

        println("\n<------- HFIRE Threshold Test START ------->");

        if (gVariableNameInput != null && !gVariableNameInput.isEmpty()) {
            Itest0.set(context.testProgram().variables().getDouble(gVariableNameInput));
        }

        int sampleIndex = 0;

        // Process the HFIRE low-to-high ramp to find HFIRE_VIH.
        for (int site : context.getActiveSites()) {
            double[] testCurrentSamples = testCurrentRampUp.getArray(site);
            double[] sqpVoltageSamples = sqpVoltageRampUp.getArray(site);
            int sampleCount = testCurrentSamples.length;
            boolean HFIRE_VIH_FLAG = false;
            double itest0Val = Itest0.get(site);
            double failsafeLimit = (itest0Val > 0.0) ? (1.5 * itest0Val) : 10e-6;

            ITestHFIRE0.set(site, testCurrentSamples[0]);

            for (sampleIndex = 0; sampleIndex < sampleCount; sampleIndex++) {
                if (testCurrentSamples[sampleIndex] < failsafeLimit
                        && sqpVoltageSamples[sampleIndex] > 8.5 && !HFIRE_VIH_FLAG) {

                    HFIRE_VIH.set(site,
                            Vmin + sampleIndex * (Vmax - Vmin) / (nSamples - 1));
                    HFIRE_VIH_FLAG = true;
                }

//                println("Site " + site
//                        + " | HFIRE Ramp Up Voltage: "
//                        + (Vmin + sampleIndex * (Vmax - Vmin) / (nSamples - 1))
//                        + " V | TEST Current: " + testCurrentSamples[sampleIndex]
//                        + " A | SQP Voltage: " + sqpVoltageSamples[sampleIndex] + " V");
            }
        }

        // Process the HFIRE high-to-low ramp to find HFIRE_VIL.
        for (int site : context.getActiveSites()) {
            double[] testCurrentSamples = testCurrentRampDown.getArray(site);
            double[] sqpVoltageSamples = sqpVoltageRampDown.getArray(site);
            int sampleCount = testCurrentSamples.length;
            boolean HFIRE_VIL_FLAG = false;
            double itest0Val = Itest0.get(site);
            double failsafeLimit = (itest0Val > 0.0) ? (1.5 * itest0Val) : 10e-6;

            double vSqpOn = sqpVoltageSamples[0];
            double vilThreshold = (vSqpOn > 8.0) ? (vSqpOn - 0.4) : 8.5;

            for (sampleIndex = 0; sampleIndex < sampleCount; sampleIndex++) {
                if (testCurrentSamples[sampleIndex] < failsafeLimit
                        && sqpVoltageSamples[sampleIndex] < vilThreshold && !HFIRE_VIL_FLAG) {

                    HFIRE_VIL.set(site,
                            Vmax - sampleIndex * (Vmax - Vmin) / (nSamples - 1));
                    HFIRE_VIL_FLAG = true;
                }

//                println("Site " + site
//                        + " | HFIRE Ramp Down Voltage: "
//                        + (Vmax - sampleIndex * (Vmax - Vmin) / (nSamples - 1))
//                        + " V | TEST Current: " + testCurrentSamples[sampleIndex]
//                        + " A | SQP Voltage: " + sqpVoltageSamples[sampleIndex] + " V");
            }
        }

        HFIRE_VHYS = HFIRE_VIH.subtract(HFIRE_VIL);

        for (int site : context.getActiveSites()) {
            println("Site " + site
                    + " | ITestHFIRE0: " + ITestHFIRE0.get(site) + " A"
                    + " | HFIRE_VIH: " + HFIRE_VIH.get(site) + " V"
                    + " | HFIRE_VIL: " + HFIRE_VIL.get(site) + " V"
                    + " | HFIRE_VHYS: " + HFIRE_VHYS.get(site) + " V");

            double itest0Value = Itest0.get(site);
            if (itest0Value > 0.0) {
                ptdDCHFIRE0.setLowLimit(0.9 * itest0Value).setHighLimit(1.1 * itest0Value);
            }
        }

        ptdDCHFIRE0.evaluate(ITestHFIRE0);
        ptdDCVIH.evaluate(HFIRE_VIH);
        ptdDCVIL.evaluate(HFIRE_VIL);
        ptdDCVHYS.evaluate(HFIRE_VHYS);

        println("<------- HFIRE Threshold Test END ------->\n");
    }
}
