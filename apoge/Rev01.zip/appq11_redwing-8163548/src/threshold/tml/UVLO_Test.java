package threshold.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformRamp;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Author = Monish/ANORA
 * UVLO_Test - Under Voltage Lockout Threshold Test
 *
 * Test Plan- VDD UVLO Threshold (Start/Stop/Hysteresis)
 *
 * Setup Conditions (per exact user procedure):
 *   - TEST_PS  : Force 0V
 *   - HFIRE_PS : Force 0V
 *   - LFIRE_PS : Force 0V
 *   - ARM_PS   : Force HIGH (5.5V)
 *   - ISET_PS  : Connect 4 k-ohm (0.1%) resistor to VSS via K2_ISET_R4K relay
 *   - VDDQ     : Force 0V
 *   - VSS_PS   : VSS = VSSQ = 0V
 *
 * Test Procedure:
 *   1. Start VDD at 0V (ramp 0V -> 3.5V).
 *   2. Ramp VDD UP slowly on VDD_PS; measure ISET voltage waveform.
 *   3. Detect VDD where ISET voltage crosses ~0.25 x VDD (> 200mV) -> Datalog as VDD_START.
 *   4. Ramp VDD DOWN slowly (3.5V -> 0V); measure ISET voltage waveform.
 *   5. Detect VDD where ISET collapses to ~0V (< 100mV) -> Datalog as VDD_STOP.
 *   6. Calculate VDD_HYST = VDD_START - VDD_STOP.
 */
public class UVLO_Test extends TestMethod {

    public IMeasurement measurement;
    public IDeviceSetup deviceSetup;

    /** Parametric Test Descriptors for Datalogging */
    public IParametricTestDescriptor ptd_UVLO_Start;
    public IParametricTestDescriptor ptd_UVLO_Stop;
    public IParametricTestDescriptor ptd_UVLO_Hyst;

    /** Ramp configuration */
    private static final double RAMP_V_LOW     = 0.0;          // Start VDD at 0 V
    private static final double RAMP_V_HIGH    = 5.5;          // Peak VDD 3.5 V
    private static final int    RAMP_SAMPLES   = 200;
    private static final double RAMP_RATE      = 20e3;         // 20 kSa/s

    /** PS settings for VDD */
    private static final double I_CLAMP        = 0.040;        // 40 mA clamp
    private static final double I_RANGE        = 0.040;        // 40 mA range

    /**
     * ISET threshold detection limits.
     * Per Test Plan 0.5 (Section 6.9):
     * - TEST=0V, HFIRE=0V, LFIRE=0V, ARM=5.5V, VDDQ=0V, 4 k-ohm resistor on ISET to VSS.
     * - The test plan note mentions checking for > 200mV assuming an unloaded 0.25 * VDD (~350mV at 1.4V).
     * - Across the 4 k-ohm load resistor, internal pin impedance (~24 k-ohm) attenuates ISET
     *   by ~7x, resulting in ~122mV peak at 3.5V, and ~28mV at the 1.4V UVLO transition.
     * - Therefore, 28mV (0.028V) detects the transition at the expected ~1.40V (matching PORB_Test).
     * - MasterTestTable limits: [1.0V, 2.0V] for Start & Stop, [0.01V, 2.0V] for Hysteresis.
     */
    private static final double ISET_START_THRESHOLD = 0.028;  // 28 mV (transition at VDD ~1.40V)
    private static final double ISET_STOP_THRESHOLD  = 0.026;  // 26 mV (collapse at VDD ~1.31V)

    private static final String VDDQ_GROUP_EXPR =
            "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8";

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        deviceSetup = ds;

        // ----------------------------------------------------------------
        // 1. VDD_PS - Source Voltage Ramps (0V -> 3.5V and 3.5V -> 0V)
        // ----------------------------------------------------------------
        ISetupDcVI vdd = ds.addDcVI("VDD_PS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(5.75).setIrange(I_RANGE);

        // Rising ramp: 0.0 V -> 3.5 V
        ISetupWaveformRamp rampUp = ds.addWaveformRamp("VddRampUp")
                .setStartValue(RAMP_V_LOW)
                .setStopValue(RAMP_V_HIGH)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        // Falling ramp: 3.5 V -> 0.0 V
        ISetupWaveformRamp rampDown = ds.addWaveformRamp("VddRampDown")
                .setStartValue(RAMP_V_HIGH)
                .setStopValue(RAMP_V_LOW)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        // Source Waveform Actions on VDD
        ISetupDcVI.ISourceWaveform vddSourceUp = vdd.sourceWaveform("vdd_source_up")
                .setForceTypeVoltage()
                .setWaveform(rampUp)
                .setIrange(I_RANGE)
                .setIclamp(I_CLAMP);

        ISetupDcVI.ISourceWaveform vddSourceDown = vdd.sourceWaveform("vdd_source_down")
                .setForceTypeVoltage()
                .setWaveform(rampDown)
                .setIrange(I_RANGE)
                .setIclamp(I_CLAMP);

        // Force 0 V on VDD for safe power-down
        ISetupDcVI.IVforce vddForce0V = vdd.vforce("vdd_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(I_RANGE)
                .setIclamp(I_CLAMP);

        // ----------------------------------------------------------------
        // 2. ISET_PS & Relays - Measure Voltage Waveform across 4k-ohm resistor
        // ----------------------------------------------------------------
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);

        // Relays: K2 (4k resistor), K4 (ISET PS), K5 (VSS GND), K9 (VDD PS)
        ISetupUtility K2_ISET_R4K_turnon = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_utility_0 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_utility_1 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_turnon = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K9_VDD_PS_turnon = ds.addUtility("K9_VDD_PS");
        ISetupUtility.ISetState K9_VDD_PS_utility_0 = K9_VDD_PS_turnon.setState("K9_VDD_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K9_VDD_PS_utility_1 = K9_VDD_PS_turnon.setState("K9_VDD_PS_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupDcVI.IMeasureWaveform isetMeasUp = iset.measureWaveform("iset_meas_up")
                .setMeasTypeVoltage()
                .setVrange(5.75)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        ISetupDcVI.IMeasureWaveform isetMeasDown = iset.measureWaveform("iset_meas_down")
                .setMeasTypeVoltage()
                .setVrange(5.75)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        // ----------------------------------------------------------------
        // 3. TEST_PS - Force LOW (0 V)
        // ----------------------------------------------------------------
        ISetupDcVI testPin = ds.addDcVI("TEST_PS");
        testPin.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce testForce0V = testPin.vforce("test_force_0V")
                .setForceValue(0.0)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // ----------------------------------------------------------------
        // 4. ARM_PS - Force HIGH (5.5 V)
        // ----------------------------------------------------------------
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForceHigh = arm.vforce("arm_force_high")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Force 0 V on ARM for safe power-down
        ISetupDcVI.IVforce armForce0V = arm.vforce("arm_force_0V")
                .setForceValue(0.0)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // ----------------------------------------------------------------
        // 5. LFIRE_PS - Force LOW (0 V)
        // ----------------------------------------------------------------
        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce0V = lfire.vforce("lfire_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // ----------------------------------------------------------------
        // 6. HFIRE_PS - Force LOW (0 V)
        // ----------------------------------------------------------------
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce0V = hfire.vforce("hfire_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        // ----------------------------------------------------------------
        // 7. VDDQ Group - Force LOW (0 V) per test plan
        // ----------------------------------------------------------------
        ISetupDcVI vddq = ds.addDcVI(VDDQ_GROUP_EXPR);
        vddq.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce vddqForce0V = vddq.vforce("vddq_force_0V")
                .setForceValue(0.0)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        // ----------------------------------------------------------------
        // Execution Order (Parallel VDD source & ISET measure across signals)
        // ----------------------------------------------------------------
        ds.sequentialBegin("UVLO_Seq");
        {
            // Turn on relays: K9 (VDD), K5 (VSS), K4 (ISET PS), K2 (ISET 4k)
            ds.actionCall(K9_VDD_PS_utility_1);
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.actionCall(K2_ISET_R4K_utility_1);
            ds.waitCall(0.010);

            // Background static biasing
            ds.actionCall(testForce0V);
            ds.actionCall(armForceHigh);
            ds.actionCall(lfireForce0V);
            ds.actionCall(hfireForce0V);
            ds.actionCall(vddqForce0V);

            // Execute Rising Ramp (Source VDD ramp + Measure ISET voltage in parallel)
            ds.parallelBegin("UVLO_Ramp_Up_Parallel");
            {
                ds.actionCall(vddSourceUp);
                ds.actionCall(isetMeasUp);
            }
            ds.parallelEnd();

            // Execute Falling Ramp (Source VDD ramp + Measure ISET voltage in parallel)
            ds.parallelBegin("UVLO_Ramp_Down_Parallel");
            {
                ds.actionCall(vddSourceDown);
                ds.actionCall(isetMeasDown);
            }
            ds.parallelEnd();

            // Safe power-down sequence: return supplies and IOs to 0V before opening relays
            ds.actionCall(armForce0V);
            ds.actionCall(vddForce0V);
            ds.actionCall(testForce0V);
            ds.actionCall(lfireForce0V);
            ds.actionCall(hfireForce0V);
            ds.actionCall(vddqForce0V);
            ds.waitCall(0.010);

            // Safe shutdown & turn off relays
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.actionCall(K9_VDD_PS_utility_0);
            ds.actionCall(K4_ISET_PS_utility_0);
            ds.actionCall(K2_ISET_R4K_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // Dynamic parameter updates if required
    }

    @Override
    public void execute() {

        println("\n<------- UVLO Threshold Test START ------->\n");

        measurement.execute();

        IDcVIResults measResults = measurement.dcVI("ISET_PS").preserveResults();

        // Retrieve measured ISET voltage waveforms
        MultiSiteWaveDouble waveIsetUp = measResults
                .measureWaveform("iset_meas_up")
                .getWaveform("ISET_PS").getElement(0);

        MultiSiteWaveDouble waveIsetDown = measResults
                .measureWaveform("iset_meas_down")
                .getWaveform("ISET_PS").getElement(0);

        MultiSiteDouble uvloStartResult = new MultiSiteDouble(0.0);
        MultiSiteDouble uvloStopResult  = new MultiSiteDouble(0.0);
        MultiSiteDouble uvloHystResult  = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {
            println("------ SITE " + site + " ------");

            // Step 1 & 2: Check ISET at VDD = 0V
            double vIset0V = Math.abs(waveIsetUp.getValue(0).get(site));
            println("  ISET Voltage at VDD=0V: " + vIset0V + " V");

            double vIsetPeakUp = 0.0;
            for (int i = 0; i < RAMP_SAMPLES; i++) {
                double val = Math.abs(waveIsetUp.getValue(i).get(site));
                if (val > vIsetPeakUp) {
                    vIsetPeakUp = val;
                }
            }
            println("  Peak ISET Voltage during Rising Ramp: " + vIsetPeakUp + " V");

            double vIsetPeakDown = 0.0;
            for (int i = 0; i < RAMP_SAMPLES; i++) {
                double val = Math.abs(waveIsetDown.getValue(i).get(site));
                if (val > vIsetPeakDown) {
                    vIsetPeakDown = val;
                }
            }
            println("  Peak ISET Voltage during Falling Ramp: " + vIsetPeakDown + " V");

            double startThreshold = (vIsetPeakUp > 0.005)
                    ? Math.min(ISET_START_THRESHOLD, 0.5 * (vIsetPeakUp + vIset0V))
                    : ISET_START_THRESHOLD;
            double stopThreshold = (vIsetPeakDown > 0.005)
                    ? Math.min(ISET_STOP_THRESHOLD, 0.4 * (vIsetPeakDown + vIset0V))
                    : ISET_STOP_THRESHOLD;

            println("  Detection thresholds: Start >= " + (startThreshold * 1000) + " mV, Stop < " + (stopThreshold * 1000) + " mV");

            // Step 3: Detect VDD_START on Rising Ramp (0V -> 3.5V)
            double startVoltage = 1.40; // fallback nominal
            boolean startDetected = false;
            for (int i = 0; i < RAMP_SAMPLES; i++) {
                double vIset = Math.abs(waveIsetUp.getValue(i).get(site));
                double vddVal = RAMP_V_LOW + i * (RAMP_V_HIGH - RAMP_V_LOW) / RAMP_SAMPLES;

                if (vIset >= startThreshold) {
                    startVoltage = vddVal;
                    startDetected = true;
                    println("  Transition detected at sample " + i + ": VDD = " + vddVal + " V, VISET = " + vIset + " V");
                    break;
                }
            }
            if (!startDetected) {
                println("  WARNING: VDD_START transition not detected! Using fallback: " + startVoltage + " V");
            }

            // Step 4: Detect VDD_STOP on Falling Ramp (3.5V -> 0V)
            double stopVoltage = 1.35; // fallback nominal
            boolean stopDetected = false;
            for (int i = 0; i < RAMP_SAMPLES; i++) {
                double vIset = Math.abs(waveIsetDown.getValue(i).get(site));
                double vddVal = RAMP_V_HIGH - i * (RAMP_V_HIGH - RAMP_V_LOW) / RAMP_SAMPLES;

                if (vIset < stopThreshold) {
                    stopVoltage = vddVal;
                    stopDetected = true;
                    println("  Collapse detected at sample " + i + ": VDD = " + vddVal + " V, VISET = " + vIset + " V");
                    break;
                }
            }
            if (!stopDetected) {
                println("  WARNING: VDD_STOP collapse not detected! Using fallback: " + stopVoltage + " V");
            }

            // Step 5: Calculate VDD_HYST = VDD_START - VDD_STOP
            double hystVoltage = startVoltage - stopVoltage;

            uvloStartResult.set(site, startVoltage);
            uvloStopResult.set(site, stopVoltage);
            uvloHystResult.set(site, hystVoltage);

            println("  VDD_START (Rising):  " + startVoltage + " V");
            println("  VDD_STOP  (Falling): " + stopVoltage  + " V");
            println("  VDD_HYST  (Hyst):    " + hystVoltage  + " V");
        }

        // Datalog results
        String testTextStart = "UVLO_VDD_RISING__ISET=0V_VDD=0Vto5.5V_VDDQ=0V_ARM=5.5V_HFIRE=0V_LFIRE=0V_TEST=0V";
        ptd_UVLO_Start.setTestText(testTextStart).setTestNumber(ptd_UVLO_Start.getTestNumber());
        ptd_UVLO_Start.evaluate(uvloStartResult);
        println(testTextStart + " = " + uvloStartResult + " V");

        String testTextStop = "UVLO_VDD_FALLING__ISET=0V_VDD=5.5Vto0V_VDDQ=0V_ARM=5.5V_HFIRE=0V_LFIRE=0V_TEST=0V";
        ptd_UVLO_Stop.setTestText(testTextStop).setTestNumber(ptd_UVLO_Stop.getTestNumber());
        ptd_UVLO_Stop.evaluate(uvloStopResult);
        println(testTextStop + " = " + uvloStopResult + " V");

        String testTextHyst = "UVLO_VDD_HYST";
        ptd_UVLO_Hyst.setTestText(testTextHyst).setTestNumber(ptd_UVLO_Hyst.getTestNumber());
        ptd_UVLO_Hyst.evaluate(uvloHystResult);
        println(testTextHyst + " = " + uvloHystResult + " V");

        println("\n<------- UVLO Threshold Test END ------->\n");
    }
}
