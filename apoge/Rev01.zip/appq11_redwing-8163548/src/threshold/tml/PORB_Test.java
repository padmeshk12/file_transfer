package threshold.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformRamp;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Author = Monish/ANORA
 * PORB_Test - PORB / Failsafe Supervisor Threshold Test
 *
 * Setup:
 *   - TEST_PS  : Force 0.5V, measure current (Itest)
 *   - ARM_PS   : Force 0V
 *   - LFIRE_PS : Force 0V
 *   - HFIRE_PS : Force 0V
 *   - ISET_PS  : Connect 4 k-ohm resistor to VSS via K2_ISET_R4K
 *   - VDDQ     : DPS128 supply (0V -> 2V ramp for Step 2, then 5V for Step 3-5)
 *   - VDD_PS   : PS1600 supply (0V -> 3.5V -> 0V ramps for Step 4-5)
 *
 * Test Procedure:
 *   1. Measure Itest0 at VDD = 0V, VDDQ = 0V (expected Itest0 ~ 3.5 uA).
 *   2. Step VDDQ voltage up (0V -> 2V) with VDD = 0V:
 *      - Monitor Itest until Itest > 1.5 * Itest0 (indicates failsafe detection)
 *      - Datalog VDDQ voltage as vddq_fs_voltage (vddq_fs_voltage < 1.2V)
 *      - Datalog peak Itest as ItestFS (5.25 uA <= ItestFS <= 17.5 uA)
 *   3. Force VDDQ = 5V.
 *   4. Ramp VDD up (0V -> 3.5V) until Itest < 1.5 * Itest0:
 *      - Datalog VDD voltage as vdd_porb_rising (vdd_porb_rising < 1.6V)
 *   5. Ramp VDD down (3.5V -> 0V) until 1.5 * Itest0 < Itest < 2.5 * Itest0:
 *      - Datalog VDD voltage as vdd_porb_falling (vdd_porb_falling < 1.6V)
 *   6. Calculate vdd_porb_hysteresis = vdd_porb_rising - vdd_porb_falling (> 10mV)
 */
public class PORB_Test extends TestMethod {

    public IMeasurement measurement;
    public IDeviceSetup deviceSetup;

    public String gVariableNameOutput = "";

    /** Parametric Test Descriptors for Datalogging */
    public IParametricTestDescriptor ptd_Itest0;
    public IParametricTestDescriptor ptd_ItestFS;
    public IParametricTestDescriptor ptd_vddq_fs_voltage;
    public IParametricTestDescriptor ptd_vdd_porb_rising;
    public IParametricTestDescriptor ptd_vdd_porb_falling;
    public IParametricTestDescriptor ptd_vdd_porb_hysteresis;

    /** VDD Ramp settings */
    private static final double RAMP_V_LOW     = 0.0;          // V
    private static final double RAMP_V_HIGH    = 5.5;          // V
    private static final int    RAMP_SAMPLES   = 200;
    private static final double RAMP_RATE      = 10e3;         // 20 kSa/s

    /** VDDQ Ramp settings */
    private static final double VDDQ_RAMP_V_LOW  = 0.0;        // 0 V
    private static final double VDDQ_RAMP_V_HIGH = 2.0;        // 2 V
    private static final int    VDDQ_RAMP_SAMPLES = 200;

    /** TEST pin settings */
    private static final double TEST_FORCE_V   = 0.5;          // 0.5 V forced on TEST
    private static final double TEST_I_RANGE   = 0.0001;       // 100 uA current range

    private static final String VDDQ_GROUP_EXPR =
            "VDDQ1_AVI1"; //+ VDDQ2_AVI3 "; //+ VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        deviceSetup = ds;

        // ----------------------------------------------------------------
        // 1. TEST_PS Pin - Force 0.5V, measure current (Itest)
        // ----------------------------------------------------------------
        ISetupDcVI testPin = ds.addDcVI("TEST_PS");
        testPin.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce testForce0p5V = testPin.vforce("test_force_0p5V")
                .setForceValue(TEST_FORCE_V)
                .setVrange(2.0)
                .setIrange(TEST_I_RANGE)
                .setIclamp(TEST_I_RANGE);

        // Force 0 V on TEST for safe power-down
        ISetupDcVI.IVforce testForce0V = testPin.vforce("test_force_0V")
                .setForceValue(0.0)
                .setVrange(2.0)
                .setIrange(TEST_I_RANGE)
                .setIclamp(TEST_I_RANGE);

        // Baseline measurement at VDD=0V, VDDQ=0V (Itest0)
        ISetupDcVI.IImeas testMeasItest0 = testPin.imeas("test_meas_itest0")
                .setIrange(TEST_I_RANGE)
                .setRestoreIrange(false);

        // Current waveform measurement during VDDQ ramp up (Step 2)
        ISetupDcVI.IMeasureWaveform testMeasWaveVddqUp = testPin.measureWaveform("test_meas_wave_vddq_up")
                .setMeasTypeCurrent()
                .setIrange(TEST_I_RANGE)
                .setSamples(VDDQ_RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        // Current waveform measurement during VDD ramps (Step 4 & 5)
        ISetupDcVI.IMeasureWaveform testMeasWaveUp = testPin.measureWaveform("test_meas_wave_up")
                .setMeasTypeCurrent()
                .setIrange(TEST_I_RANGE)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        ISetupDcVI.IMeasureWaveform testMeasWaveDown = testPin.measureWaveform("test_meas_wave_down")
                .setMeasTypeCurrent()
                .setIrange(TEST_I_RANGE)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        // ----------------------------------------------------------------
        // 2. VDD_PS - Voltage Source Ramps (0V -> 3.5V and 3.5V -> 0V)
        // ----------------------------------------------------------------
        ISetupDcVI vdd = ds.addDcVI("VDD_PS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(5.75).setIrange(0.040);

        ISetupDcVI.IVforce vddForce0V = vdd.vforce("vdd_force_0V")
                .setForceValue(0.0)
                .setIrange(0.040)
                .setIclamp(0.040);

        ISetupWaveformRamp vddRampUp = ds.addWaveformRamp("VddRampUp")
                .setStartValue(RAMP_V_LOW)
                .setStopValue(RAMP_V_HIGH)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        ISetupWaveformRamp vddRampDown = ds.addWaveformRamp("VddRampDown")
                .setStartValue(RAMP_V_HIGH)
                .setStopValue(RAMP_V_LOW)
                .setSamples(RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        ISetupDcVI.ISourceWaveform vddSourceUp = vdd.sourceWaveform("vdd_source_up")
                .setForceTypeVoltage()
                .setWaveform(vddRampUp)
                .setIrange(0.040)
                .setIclamp(0.040);

        ISetupDcVI.ISourceWaveform vddSourceDown = vdd.sourceWaveform("vdd_source_down")
                .setForceTypeVoltage()
                .setWaveform(vddRampDown)
                .setIrange(0.040)
                .setIclamp(0.040);

        // ----------------------------------------------------------------
        // 3. VDDQ Group - (0V -> 2V ramp for Step 2, then 5V for Step 3-5)
        // ----------------------------------------------------------------
        ISetupDcVI vddq = ds.addDcVI(VDDQ_GROUP_EXPR);
        vddq.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce0V = vddq.vforce("vddq_force_0V")
                .setForceValue(0.0)
                .setVrange(12.0)
                .setIrange(0.04)
                .setIclamp(0.04);

        ISetupWaveformRamp vddqRampUp = ds.addWaveformRamp("VddqRampUp")
                .setStartValue(VDDQ_RAMP_V_LOW)
                .setStopValue(VDDQ_RAMP_V_HIGH)
                .setSamples(VDDQ_RAMP_SAMPLES)
                .setSampleRate(RAMP_RATE);

        ISetupDcVI.ISourceWaveform vddqSourceUp = vddq.sourceWaveform("vddq_source_up")
                .setForceTypeVoltage()
                .setWaveform(vddqRampUp)
                .setIrange(0.04)
                .setIclamp(0.04);

        ISetupDcVI.IVforce vddqForce5V = vddq.vforce("vddq_force_5V")
                .setForceValue(5.0)
                .setVrange(12.0)
                .setIrange(0.04)
                .setIclamp(0.04);

        // ----------------------------------------------------------------
        // 4. ARM_PS, LFIRE_PS, HFIRE_PS - Force LOW (0V)
        // ----------------------------------------------------------------
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForce0V = arm.vforce("arm_force_0V")
                .setForceValue(0.0).setVrange(5.75).setIrange(0.01).setIclamp(0.01);

        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce0V = lfire.vforce("lfire_force_0V")
                .setForceValue(0.0).setVrange(5.75).setIrange(0.01).setIclamp(0.01);

        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce0V = hfire.vforce("hfire_force_0V")
                .setForceValue(0.0).setVrange(5.75).setIrange(0.01).setIclamp(0.01);

        // ----------------------------------------------------------------
        // 5. ISET_PS - 4 k-ohm to VSS via K2_ISET_R4K relay
        // ----------------------------------------------------------------
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

//        ISetupUtility iset_k2 = ds.addUtility("K2_ISET_R4K").setValue(1);

        ISetupUtility.ISetState K2_ISET_R4K_utility_0 = null;
        ISetupUtility.ISetState K2_ISET_R4K_utility_1 = null;
        ISetupUtility K2_ISET_R4K_turnon = ds.addUtility("K2_ISET_R4K");
        K2_ISET_R4K_utility_0 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_0").setValue(0).setSettlingTime(0.02);
        K2_ISET_R4K_utility_1 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_1").setValue(1).setSettlingTime(0.02);

         // =========================================================================
         // K9: K9_VDD_PS (Connects VDD to tester PS)
         // =========================================================================
         ISetupUtility.ISetState K9_VDD_PS_utility_0 = null;
         ISetupUtility.ISetState K9_VDD_PS_utility_1 = null;
         ISetupUtility K9_VDD_PS_turnon = ds.addUtility("K9_VDD_PS");
         K9_VDD_PS_utility_0 = K9_VDD_PS_turnon.setState("K9_VDD_PS_utility_0").setValue(0).setSettlingTime(0.02);
         K9_VDD_PS_utility_1 = K9_VDD_PS_turnon.setState("K9_VDD_PS_utility_1").setValue(1).setSettlingTime(0.02);

      // =========================================================================
         // K5: K5_VSS_GND (Connects VSS to GND)
         // =========================================================================
         ISetupUtility.ISetState K5_VSS_GND_utility_0 = null;
         ISetupUtility.ISetState K5_VSS_GND_utility_1 = null;
         ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
         K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
         K5_VSS_GND_utility_1 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupDcVI.IIforce isetForce0A = iset.iforce("iset_force_0A")
                .setForceValue(0.0).setVrange(3.0).setVclampHigh(3.0).setVclampLow(0.0);

        // ----------------------------------------------------------------
        // Execution Order
        // ----------------------------------------------------------------
        ds.sequentialBegin("PORB_Seq");
        {
            // Initial static biasing: VDD=0V, VDDQ=0V, ARM=0V, LFIRE=0V, HFIRE=0V, TEST=0.5V, ISET=4k
            ds.actionCall(K9_VDD_PS_utility_1);
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K2_ISET_R4K_utility_1);
            ds.waitCall(0.010);
            ds.actionCall(vddForce0V);
            ds.actionCall(vddqForce0V);
            ds.actionCall(armForce0V);
            ds.actionCall(lfireForce0V);
            ds.actionCall(hfireForce0V);

            ds.actionCall(testForce0p5V);
            ds.actionCall(isetForce0A);
            ds.waitCall(0.050);

            // Step 1: Measure Itest0 at VDD=0V, VDDQ=0V
            ds.actionCall(testMeasItest0);

            // Step 2: Ramp VDDQ up (0V -> 2.0V) and measure TEST current waveform in parallel
            ds.parallelBegin("VDDQ_Ramp_Up_Parallel");
            {
                ds.actionCall(vddqSourceUp);
                ds.actionCall(testMeasWaveVddqUp);
            }
            ds.parallelEnd();

            // Step 3: Force VDDQ = 5V
            ds.actionCall(vddqForce5V);
            ds.waitCall(0.050);

            // Step 4: Ramp VDD Up (0V -> 3.5V) and measure TEST current waveform
            ds.parallelBegin("VDD_Ramp_Up_Parallel");
            {
                ds.actionCall(vddSourceUp);
                ds.actionCall(testMeasWaveUp);
            }
            ds.parallelEnd();
//            ds.actionCall(vddForce0V);
            ds.waitCall(0.100);

            // Step 5: Ramp VDD Down (3.5V -> 0V) and measure TEST current waveform
            ds.parallelBegin("VDD_Ramp_Down_Parallel");
            {
                ds.actionCall(vddSourceDown);
                ds.actionCall(testMeasWaveDown);
            }
            ds.parallelEnd();

            // Safe power-down sequence: return supplies and IOs to 0V before opening relays
            ds.actionCall(testForce0V);
            ds.actionCall(vddForce0V);
            ds.actionCall(vddqForce0V);
            ds.actionCall(armForce0V);
            ds.actionCall(lfireForce0V);
            ds.actionCall(hfireForce0V);
            ds.waitCall(0.010);

            // Safe shutdown & turn off relays
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.actionCall(K9_VDD_PS_utility_0);
            ds.actionCall(K2_ISET_R4K_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // Dynamic parameter updates if required
    }

    @Override
    public void execute() {

        println("\n<------- PORB / Failsafe Supervisor Test START ------->\n");

        measurement.execute();

        IDcVIResults testResults = measurement.dcVI("TEST_PS").preserveResults();

        // 1. Retrieve Itest0 baseline measurement
        MultiSiteDoubleArray itest0Map = testResults.imeas("test_meas_itest0").getCurrent("TEST_PS");

        // 2. Retrieve TEST current waveforms
        MultiSiteWaveDouble waveItestVddqUp = testResults
                .measureWaveform("test_meas_wave_vddq_up")
                .getWaveform("TEST_PS").getElement(0);

        MultiSiteWaveDouble waveItestVddUp = testResults
                .measureWaveform("test_meas_wave_up")
                .getWaveform("TEST_PS").getElement(0);

        MultiSiteWaveDouble waveItestVddDown = testResults
                .measureWaveform("test_meas_wave_down")
                .getWaveform("TEST_PS").getElement(0);

        MultiSiteDouble itest0Result       = new MultiSiteDouble(0.0);
        MultiSiteDouble itestFSResult      = new MultiSiteDouble(0.0);
        MultiSiteDouble vddqFsResult       = new MultiSiteDouble(0.0);
        MultiSiteDouble porbRisingResult   = new MultiSiteDouble(0.0);
        MultiSiteDouble porbFallingResult  = new MultiSiteDouble(0.0);
        MultiSiteDouble porbHystResult     = new MultiSiteDouble(0.0);

        for (int site : context.getActiveSites()) {
            println("------ SITE " + site + " ------");

            // Step 1: Baseline Itest0 at VDD=0V, VDDQ=0V
            double itest0 = Math.abs(itest0Map.get(site)[0]);
            itest0Result.set(site, itest0);
            println("  Step 1 - Itest0 (Baseline): " + (itest0 * 1e6) + " uA");

            double fsThreshold = 1.5 * itest0;

            // Step 2: VDDQ ramp (0V -> 2V) -> detect failsafe activation (Itest > 1.5 * Itest0)
            double vddqFsVolt = VDDQ_RAMP_V_HIGH; // fallback
            double itestFS = 0.0;
            for (int i = 0; i < VDDQ_RAMP_SAMPLES; i++) {
                double iVal = Math.abs(waveItestVddqUp.getValue(i).get(site));
                double vddqVal = VDDQ_RAMP_V_LOW + i * (VDDQ_RAMP_V_HIGH - VDDQ_RAMP_V_LOW) / VDDQ_RAMP_SAMPLES;

                if (iVal > itestFS) {
                    itestFS = iVal;
                }

                if (iVal > fsThreshold && vddqFsVolt == VDDQ_RAMP_V_HIGH) {
                    vddqFsVolt = vddqVal;
                    println("  Step 2 - Failsafe triggered at sample " + i + ": VDDQ = " + vddqVal + " V, Itest = " + (iVal * 1e6) + " uA");
                }
            }
            itestFSResult.set(site, itestFS);
            vddqFsResult.set(site, vddqFsVolt);
            println("  Step 2 - Peak ItestFS: " + (itestFS * 1e6) + " uA");
            println("  Step 2 - vddq_fs_voltage: " + vddqFsVolt + " V");

            // Step 4: VDD Rising Ramp (0V -> 3.5V) -> detect PORB rising threshold (Itest < 1.5 * Itest0)
            double porbRisingVolt = RAMP_V_HIGH; // fallback
            for (int i = 0; i < RAMP_SAMPLES; i++) {
                double iVal = Math.abs(waveItestVddUp.getValue(i).get(site));
                double vddVal = RAMP_V_LOW + i * (RAMP_V_HIGH - RAMP_V_LOW) / RAMP_SAMPLES;

                if (iVal < fsThreshold) {
                    porbRisingVolt = vddVal;
                    println("  Step 4 - PORB Rising transition at sample " + i + ": VDD = " + vddVal + " V, Itest = " + (iVal * 1e6) + " uA");
                    break;
                }
            }
            porbRisingResult.set(site, porbRisingVolt);
            println("  Step 4 - vdd_porb_rising: " + porbRisingVolt + " V");

            // Step 5: VDD Falling Ramp (3.5V -> 0V) -> detect PORB falling threshold (1.5 * Itest0 < Itest < 2.5 * Itest0)
            double porbFallingVolt = RAMP_V_LOW; // fallback
            double upperFsThreshold = 2.5 * itest0;
            for (int i = 0; i < RAMP_SAMPLES; i++) {
                double iVal = Math.abs(waveItestVddDown.getValue(i).get(site));
                double vddVal = RAMP_V_HIGH - i * (RAMP_V_HIGH - RAMP_V_LOW) / RAMP_SAMPLES;

                if (iVal >= fsThreshold && iVal <= upperFsThreshold) {
                    porbFallingVolt = vddVal;
                    println("  Step 5 - PORB Falling transition at sample " + i + ": VDD = " + vddVal + " V, Itest = " + (iVal * 1e6) + " uA");
                    break;
                }
            }
            porbFallingResult.set(site, porbFallingVolt);
            println("  Step 5 - vdd_porb_falling: " + porbFallingVolt + " V");

            // Step 6: Hysteresis = Rising - Falling
            double porbHystVolt = porbRisingVolt - porbFallingVolt;
            porbHystResult.set(site, porbHystVolt);
            println("  Step 6 - vdd_porb_hysteresis: " + porbHystVolt + " V");
        }

        // Store total VDDQ leakage current when an output variable is configured.
        if (!gVariableNameOutput.isEmpty()) {
            context.testProgram().variables().set(gVariableNameOutput,itest0Result);

            println("Measured current on TEST pin and updated in TP Variable " + gVariableNameOutput + ": " + context.testProgram().variables()
                            .getDouble(gVariableNameOutput) + " A");
        }

        // Datalog results
        String testTextItest0 = "POR_VDD_INIT__TEST=0.5V_HFIRE=0V_LFIRE=0V_VDD=0V_VDDQ=0V_ARM=0V_ISET=0V";
        ptd_Itest0.setTestText(testTextItest0).setTestNumber(ptd_Itest0.getTestNumber());
        ptd_Itest0.evaluate(itest0Result);
        println(testTextItest0 + " = " + itest0Result.multiply(1e6) + " uA");

        String testTextItestFS = "POR_ItestFS__TEST=0.5V_HFIRE=0V_LFIRE=0V_VDD=0V_VDDQ=0Vto2V_ARM=0V_ISET=0V";
        ptd_ItestFS.setTestText(testTextItestFS).setTestNumber(ptd_ItestFS.getTestNumber());
        ptd_ItestFS.evaluate(itestFSResult);
        println(testTextItestFS + " = " + itestFSResult.multiply(1e6) + " uA");

        String testTextVddqFs = "POR_VDDQ_FS_Voltage__TEST=0.5V_HFIRE=0V_LFIRE=0V_VDD=0V_VDDQ=0Vto2V_ARM=0V_ISET=0V";
        ptd_vddq_fs_voltage.setTestText(testTextVddqFs).setTestNumber(ptd_vddq_fs_voltage.getTestNumber());
        ptd_vddq_fs_voltage.evaluate(vddqFsResult);
        println(testTextVddqFs + " = " + vddqFsResult + " V");

        String testTextPorbRising = "POR_VDD_RISING__TEST=0.5V_HFIRE=0V_LFIRE=0V_VDD=0Vto5.5V_VDDQ=5V_ARM=0V_ISET=0V";
        ptd_vdd_porb_rising.setTestText(testTextPorbRising).setTestNumber(ptd_vdd_porb_rising.getTestNumber());
        ptd_vdd_porb_rising.evaluate(porbRisingResult);
        println(testTextPorbRising + " = " + porbRisingResult + " V");

        String testTextPorbFalling = "POR_VDD_FALLING__TEST=0.5V_HFIRE=0V_LFIRE=0V_VDD=5.5Vto0V_VDDQ=5V_ARM=0V_ISET=0V";
        ptd_vdd_porb_falling.setTestText(testTextPorbFalling).setTestNumber(ptd_vdd_porb_falling.getTestNumber());
        ptd_vdd_porb_falling.evaluate(porbFallingResult);
        println(testTextPorbFalling + " = " + porbFallingResult + " V");

        String testTextPorbHyst = "POR_VDD_HYST";
        ptd_vdd_porb_hysteresis.setTestText(testTextPorbHyst).setTestNumber(ptd_vdd_porb_hysteresis.getTestNumber());
        ptd_vdd_porb_hysteresis.evaluate(porbHystResult);
        println(testTextPorbHyst + " = " + porbHystResult + " V");

        println("\n<------- PORB / Failsafe Supervisor Test END ------->\n");
    }
}
