package threshold.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class ThresholdHFIRE extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDCVIH;
    public IParametricTestDescriptor ptdDCVIL;
    public IParametricTestDescriptor ptdDCVHYS;
    public Double startV = 0.0;
    public Double stopV = 5.5;
    public Double stepSize = 0.1;

    @Override
    public void setup() {
        // TODO Auto-generated method stub
        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
//        .setVforce(voltageForce)           // Force voltage (V)
        .setVrange(7.0)           // Voltage range (V)
        .setIrange(0.025);       // Current range (A)
//        .setIclamp(currentClamp);

        ISetupDcVI.IVforce vddForce3p3V = vdd.vforce("VDD_force_3p3V")
                .setForceValue(3.3)
                .setIrange(0.025)
                .setIclamp(0.025);

        ISetupDcVI vddq = ds.addDcVI("VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 +VDDQ1_AVI8");
        vddq.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce12V = vddq.vforce("vddq_force_12V").setForceValue(12.0)
                .setVrange(30.0).setIrange(0.05).setIclamp(0.05);

        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce = lfire.vforce("lfire_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce = hfire.vforce("hfire_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);
        ISetupDcVI.IIforce isetForceCurr = iset.iforce("isetForceCurr1mA")
                .setForceValue(0.001)
                .setVclampHigh(1.0)
                .setVclampLow(0);
//        ISetupDcVI.IVmeas isetMeasUP = iset.vmeas("iset_measUP")
//                .setVrange(5.5).setHighAccuracy(false);
//        ISetupDcVI.IVmeas isetMeasDOWN = iset.vmeas("iset_measDOWN")
//                .setVrange(5.5).setHighAccuracy(false);

        ISetupDcVI test = ds.addDcVI("TEST_PS");
        test.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce testForce0p5V = test.vforce("test_force_0p5V")
                .setForceValue(0.5)
                .setVrange(5.75)
                .setIrange(0.0001)
                .setIclamp(0.0001);
        ISetupDcVI.IImeas testMeasUP = test.imeas("test_measUP")
                .setIrange(0.0001).setHighAccuracy(true);
        ISetupDcVI.IImeas testMeasDOWN = test.imeas("test_measDOWN")
                .setIrange(0.0001).setHighAccuracy(true);

        ISetupDcVI sqps = ds.addDcVI("SQP1_AVI1");
        sqps.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce sqpForce5V = sqps.vforce("sqp_force_5V").setForceValue(5.0)
                .setVrange(10.0).setIrange(0.05).setIclamp(0.01);

//        ISetupDcVI.IIforce sqpForce0A = sqp.iforce("sqp_force_0A").setForceValue(0.0)
//                .setVrange(10.0).setIrange(0.01).setVclampHigh(5.0).setVclampLow(0.0);


//        ISetupDcVI.IVmeas sqpMeasUP = sqp.vmeas("sqp_measUP")
//                .setVrange(5.5);
//        ISetupDcVI.IVmeas sqpMeasDOWN = sqp.vmeas("sqp_measDOWN")
//                .setVrange(5.5);

        ISetupDcVI sqpg = ds.addDcVI("SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 +SQP4_AVI8");
        sqpg.setConnectModeHighImpedance();

//        ISetupDcVI.IVforce sqpForce5V = sqp.vforce("sqp_force_5V").setForceValue(5.0)
//                .setVrange(10.0).setIrange(0.05).setIclamp(0.01);
//
//        ISetupDcVI.IIforce sqpForce0A = sqp.iforce("sqp_force_0A").setForceValue(0.0)
//                .setVrange(10.0).setIrange(0.01).setVclampHigh(5.0).setVclampLow(0.0);


        ISetupDcVI.IVmeas sqpMeasUP = sqpg.vmeas("sqp_measUP")
                .setVrange(5.5);
        ISetupDcVI.IVmeas sqpMeasDOWN = sqpg.vmeas("sqp_measDOWN")
                .setVrange(5.5);


        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce armForceLow = arm.vforce("arm_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce armForceHigh = arm.vforce("arm_force_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);


//        ISetupDcVI.ISourceWaveform armForceUp = arm.sourceWaveform("RampWaveformUp")
//                .setForceTypeVoltage().setWaveform(RampWaveformUp)
//                .setIrange(0.001)
//                .setIclamp(0.001)
//                ;
        ds.parallelBegin("par");{
        ds.sequentialBegin("seq1");
        {
        ds.actionCall(vddForce3p3V);
        ds.actionCall(vddqForce12V);
        ds.actionCall(armForceLow);
        ds.actionCall(lfireForce);
        ds.actionCall(hfireForce);
        ds.actionCall(isetForceCurr);
        ds.actionCall(testForce0p5V);
        ds.actionCall(sqpForce5V);
        ds.actionCall(armForceHigh);
        }
        ds.sequentialEnd();
        }
        ds.parallelEnd();

        int vForceActionCount = (int) Math.abs((startV - stopV)/Math.abs(stepSize));
        int i;
//        double startV=0;
        double startTemp1=startV;
        double stopTemp1=stopV;

        ISetupDcVI.IVforce[] vforceHFIRE_PSUP = new ISetupDcVI.IVforce[vForceActionCount+1];
        for (i=0; i<=vForceActionCount;i+=1) {
            vforceHFIRE_PSUP[i] = hfire.vforce("vforceHFIRE_PSUP"+(i)).setForceValue(startTemp1).setIclamp(0.025).setIrange(0.025);
            startTemp1+=stepSize;
        }
        ISetupDcVI.IVforce[] vforceHFIRE_PSDOWN = new ISetupDcVI.IVforce[vForceActionCount+1];
        for (i=0; i<=vForceActionCount;i+=1) {
            vforceHFIRE_PSDOWN[i] = hfire.vforce("vforceHFIRE_PSDOWN"+(i)).setForceValue(stopTemp1).setIclamp(0.025).setIrange(0.025);
            stopTemp1-=stepSize;
        }

        i=0;
        ds.sequentialBegin("LFIRE_PS Threshold UP");{
            for (i=0; i<=vForceActionCount;i++) {
                ds.parallelBegin("par_"+i);{
                    ds.sequentialBegin("seqLFire"+i);{
                        ds.actionCall(vforceHFIRE_PSUP[i]);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seqSQP"+i);{
                        ds.actionCall(sqpMeasUP);

                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seqtest"+i);{
                        ds.actionCall(testMeasUP);
                    }
                    ds.sequentialEnd();
                }
                ds.parallelEnd();
            }
        }
        ds.sequentialEnd();

        ds.sequentialBegin("LFIRE_PS Threshold DOWN");{
            for (i=0; i<=vForceActionCount;i++) {
                ds.parallelBegin("par_"+i);{
                    ds.sequentialBegin("seqArm"+i);{
                        ds.actionCall(vforceHFIRE_PSDOWN[i]);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seqiset"+i);{
                        ds.actionCall(sqpMeasDOWN);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seqtest"+i);{
                        ds.actionCall(testMeasDOWN);
                    }
                    ds.sequentialEnd();
                }
                ds.parallelEnd();
            }
        }
        ds.sequentialEnd();


        measurement.setSetups(ds);


    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub


        measurement.execute();

        /* get value results for all 'iforceVmeas' actions defined in the specification */
        IDcVIResults resultstest = measurement.dcVI("TEST_PS").preserveResults();
        IDcVIResults resultsiset = measurement.dcVI("SQP1_AVI2").preserveResults();

        MultiSiteDoubleArray iMeasResultstestUP = resultstest.imeas("test_measUP").getCurrent("TEST_PS");

        MultiSiteDoubleArray vMeasResultsUP = resultsiset.vmeas("sqp_measUP").getVoltage("SQP1_AVI2");

        MultiSiteDoubleArray iMeasResultstestDOWN = resultstest.imeas("test_measDOWN").getCurrent("TEST_PS");

        MultiSiteDoubleArray vMeasResultsDOWN = resultsiset.vmeas("sqp_measDOWN").getVoltage("SQP1_AVI2");



        println("The measured Currents at TEST_PS pin when ramp up on LFIRE_PS "+ iMeasResultstestUP);

        println("The measured Currents at TEST_PS pin when ramp down on LFIRE_PS "+ iMeasResultstestDOWN);

        println("The measured Voltagess at SQP pin when ramp up on LFIRE_PS "+ iMeasResultstestUP);

        println("The measured Voltagess at SQP pin when ramp down on LFIRE_PS "+ iMeasResultstestUP);

        MultiSiteDouble HFIRE_PS_VIH = new MultiSiteDouble(999.0);
        MultiSiteDouble HFIRE_PS_VIL = new MultiSiteDouble(999.0);
        MultiSiteDouble HFIRE_PS_VHYS = new MultiSiteDouble(999.0);

        MultiSiteDouble ItestLFIRE_PS0 = iMeasResultstestUP.getElement(0);
        MultiSiteDouble Itest0 = new MultiSiteDouble(0.0);

        int len =0;

        Double startTemp2 = startV;
        for (int site:context.getActiveSites()) {
            for(len =0; len < iMeasResultstestUP.length();len++ ) {
                if(iMeasResultstestUP.getElement(site, len) < 1.5 * Itest0.get(site) &&  vMeasResultsUP.getElement(site, len) < 5.0) {
                    HFIRE_PS_VIH.set(site, startTemp2);

                }
                println("site" + site + ": Voltage at HFIRE_PS pin During Ramp Up : "+startTemp2 +" Current at SQP pin :"+iMeasResultstestUP.getElement(site, len)+" Voltage at ISET pin :"+vMeasResultsUP.getElement(site, len));
                startTemp2 += stepSize;
            }
        }

        len =0;

        Double stopTemp2 = stopV;
        for (int site:context.getActiveSites()) {
            for(len =0; len < iMeasResultstestDOWN.length();len++ ) {
                if(iMeasResultstestDOWN.getElement(site, len) < 1.5 * Itest0.get(site) &&  vMeasResultsDOWN.getElement(site, len) > 5.0) {
                    HFIRE_PS_VIL.set(site, stopTemp2);

                }
                println("site" + site + ": Voltage at HFIRE_PS pin During Ramp Down :"+stopTemp2 +" Current at SQP pin :"+iMeasResultstestDOWN.getElement(site, len)+" Voltage at ISET pin :"+vMeasResultsDOWN.getElement(site, len));
                stopTemp2 -= stepSize;
            }
        }
        HFIRE_PS_VHYS = HFIRE_PS_VIH.subtract(HFIRE_PS_VIL);

        ptdDCVIH.evaluate(HFIRE_PS_VIH);
        ptdDCVIL.evaluate(HFIRE_PS_VIL);
        ptdDCVHYS.evaluate(HFIRE_PS_VHYS);





    }

}
