package gain.tml;

import java.util.ArrayList;
import java.util.List;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * RON_VARYING_LOAD - By ///--MonishKumar--//
 *
 * This test method measures the ON resistance (RON) of the power switch
 * under three different current pulsing loads: 200mA, 500mA, and Full Load (FL).
 *
 * The calculations average the voltages on the 8 VIN pins relative to VOUT pins.
 */
public class KSQM_Mult extends TestMethod {

    public IMeasurement measurement;
    public IDeviceSetup deviceSetup;
    public IParametricTestDescriptor ptdDC1;
    public IParametricTestDescriptor ptdDC2;
    public IParametricTestDescriptor ptdDC3;
    public IParametricTestDescriptor ptdDC4;

    public List<Double> isetValues = new ArrayList<>();
    public List<Double> sqmValues = new ArrayList<>();

    /** Parametric test descriptors for datalogging */
//    public IParametricTestDescriptor ptd_RON_200mA;
//    public IParametricTestDescriptor ptd_RON_500mA;
//    public IParametricTestDescriptor ptd_RON_FL;

    /** Test method parameters (mapped from C++ GET_USER_DOUBLE) */

//    public double[] isetValues = { 100e-6, 200e-6, 600e-6, 1e-3 };
//    public double[] sqmValues = { 2, 2, 4, 6 };

    public MultiSiteDoubleArray totalCurrent = new MultiSiteDoubleArray(4,0.0);
    public MultiSiteDoubleArray gain = new MultiSiteDoubleArray(4,0.0);

    @Override
    public void setup() {



        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        deviceSetup = ds;


        // ----------------------------------------------------------------
        // Instrument Actions and Measurement Setup Declarations
        // ----------------------------------------------------------------

        for (int i = 0; i < isetValues.size(); i++) {

        // Configure VSS supply (AVI/DcVI) connect/disconnect settings and actions
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
//        .setVforce(voltageForce)           // Force voltage (V)
        .setVrange(7.0)           // Voltage range (V)
        .setIrange(0.2);       // Current range (A)
//        .setIclamp(currentClamp);

        ISetupDcVI.IVforce vddForce5p5V = vdd.vforce("vdd_force_5p5V_"+ i)
                .setForceValue(5.5)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForce5p5V = arm.vforce("arm_force_5p5V_"+ i)
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce5p5V = lfire.vforce("lfire_force_5p5V_"+i)
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce5p5V = hfire.vforce("hfire_force_5p5V_"+i)
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);



        ISetupWaveformDc dcWaveformSQMS1 = ds.addWaveformDc("PulseSQMS1"+"_" + (int)Math.abs(sqmValues.get(i)) + "V_" + i).setDcValue(sqmValues.get(i)).setSamples(200).setSampleRate(100e3);

        ISetupDcVI sqms1 = ds.addDcVI("SQM1_AVI1"); // Need to check state of SQM and VSSQ
        sqms1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqms1_Vpulse_Source_Meas =
                sqms1.sourceMeasureWaveform("sqms1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

//        ISetupDcVI.IVforce sqmForce44V = sqms1.vforce("sqms_force_44V")
//                .setForceValue(44.0)
//                .setVrange(60.0)
//                .setIrange(0.05)
//                .setIclamp(0.05);
//        ISetupDcVI.IImeas sqms1Meas = sqms1.imeas("sqms_meas").setIrange(0.2);

        ISetupDcVI sqmg1 = ds.addDcVI("SQM1_AVI2 ");
        sqmg1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();
        ISetupDcVI.ISourceMeasureWaveform sqmg1_Vpulse_Source_Meas =
                sqmg1.sourceMeasureWaveform("sqmg1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);


////        sqmg.level().setIrange(4.0).setIclamp(4.0);
//        sqmg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU1 = sqmg1.imeas("meas_HCU1")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VSSQ_G1");

        ISetupDcVI sqmg2 = ds.addDcVI("SQM2_AVI3 ");
        sqmg2.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();
        ISetupDcVI.ISourceMeasureWaveform sqmg2_Vpulse_Source_Meas =
                sqmg2.sourceMeasureWaveform("sqmg2_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);
////        sqmg.level().setIrange(4.0).setIclamp(4.0);
//        sqmg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU2 = sqmg2.imeas("meas_HCU2")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VSSQ_G2");
        ISetupDcVI sqmg3 = ds.addDcVI("SQM2_AVI4 ");
        sqmg3.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg3_Vpulse_Source_Meas =
                sqmg3.sourceMeasureWaveform("sqmg3_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);
////        sqmg.level().setIrange(4.0).setIclamp(4.0);
//        sqmg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU3 = sqmg3.imeas("meas_HCU3")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VSSQ_G3");
        ISetupDcVI sqmg4 = ds.addDcVI("SQM3_AVI5 ");
        sqmg4.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg4_Vpulse_Source_Meas =
                sqmg4.sourceMeasureWaveform("sqmg4_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

        ISetupDcVI sqmg5 = ds.addDcVI("SQM3_AVI6 ");
        sqmg5.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg5_Vpulse_Source_Meas =
                sqmg5.sourceMeasureWaveform("sqmg5_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

        ISetupDcVI sqmg6 = ds.addDcVI("SQM4_AVI7 ");
        sqmg6.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg6_Vpulse_Source_Meas =
                sqmg6.sourceMeasureWaveform("sqmg6_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

        ISetupDcVI sqmg7 = ds.addDcVI("SQM4_AVI8 ");
        sqmg7.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg7_Vpulse_Source_Meas =
                sqmg7.sourceMeasureWaveform("sqmg7_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQMS1).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);
//        ISetupDcVI sqmg = ds.addDcVI("SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4");
//        sqmg.setConfigOptionHighCurrent().setConnectModeStandard();
//        sqmg.setDisconnect(true);
//        ISetupAction sqmgDisconnect = sqmg.disconnect();
//
//        IMeasureWaveform sqmgMeasHCU = sqmg.measureWaveform("meas_HCU")
//                .setMeasTypeCurrent()
//                .setIrange(4.0).setSamples(256).setSampleRate(100000).setNeg("VSSQ_G1 ");

        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        ISetupAction isetCurrForce = iset.iforce("iset_force_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA")
                .setForceValue(isetValues.get(i))
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);
        ISetupAction iset0mA = iset.iforce("iset_force_0mA")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);


        // ----------------------------------------------------------------
        // Operating Sequence Execution (Dynamic Call Area)
        // ----------------------------------------------------------------
        ds.parallelBegin("kqsm_seq_"+i);{
        ds.sequentialBegin("kqsm_seq_"+i);
        {

            // Set background configurations
            ds.actionCall(vddForce5p5V);
            ds.actionCall(isetCurrForce);
            ds.actionCall(armForce5p5V);
            ds.actionCall(lfireForce5p5V);
            ds.actionCall(hfireForce5p5V);


//            ds.actionCall(sqmForce44V);


            ds.parallelBegin();



                    ds.sequentialBegin("seq1");
                    {
                        ds.actionCall(sqms1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq2");
                    {
                        ds.actionCall(sqmg1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq3");
                    {
                        ds.actionCall(sqmg2_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq4");
                    {
                        ds.actionCall(sqmg3_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq5");
                    {
                        ds.actionCall(sqmg4_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq6");
                    {
                        ds.actionCall(sqmg5_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq7");
                    {
                        ds.actionCall(sqmg6_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq8");
                    {
                        ds.actionCall(sqmg7_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

            ds.parallelEnd();

            ds.actionCall(iset0mA);

        }
        ds.sequentialEnd();

        }
        ds.parallelEnd();}

        measurement.setSetups(ds);

    }

    @Override
    public void update() {
        // No dynamic parameter updates needed
    }


    @Override
    public void execute() {

        // Run measurement
        measurement.execute();

        IDcVIResults measResults = measurement.dcVI("SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 + SQM4_AVI8").preserveResults();







        boolean isOffline = context.testProgram().variables().getBoolean("SYS.OFFLINE").get();
//
////        if (!isOffline) {
            // Retrieve differential VIN waveforms (each VIN measures VIN - paired VOUT via setNeg)
            // VIN1_Wave_200mA gives VIN1 - VOUT6, VIN2_Wave_200mA gives VIN2 - VOUT5, etc."sqmg4_Source_Measure_"+i
        for (int i = 0; i < isetValues.size(); i++) {
            MultiSiteWaveDouble w200_sqms1 = measResults.sourceMeasureWaveform("sqms1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM1_AVI1").getElement(0);
            MultiSiteWaveDouble w200_sqmg1 = measResults.sourceMeasureWaveform("sqmg1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM1_AVI2").getElement(0);
            MultiSiteWaveDouble w200_sqmg2 = measResults.sourceMeasureWaveform("sqmg2_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM2_AVI3").getElement(0);
            MultiSiteWaveDouble w200_sqmg3 = measResults.sourceMeasureWaveform("sqmg3_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM2_AVI4").getElement(0);
            MultiSiteWaveDouble w200_sqmg4 = measResults.sourceMeasureWaveform("sqmg4_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM3_AVI5").getElement(0);
            MultiSiteWaveDouble w200_sqmg5 = measResults.sourceMeasureWaveform("sqmg5_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM3_AVI6").getElement(0);
            MultiSiteWaveDouble w200_sqmg6 = measResults.sourceMeasureWaveform("sqmg6_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM4_AVI7").getElement(0);
            MultiSiteWaveDouble w200_sqmg7 = measResults.sourceMeasureWaveform("sqmg7_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQM4_AVI8").getElement(0);



            // Perform calculations across active sites




            for (int site : context.getActiveSites()) {

                double totalCurrentSite = (Math.abs(w200_sqms1.getValue(125).get(site) + w200_sqms1.getValue(130).get(site) + w200_sqms1.getValue(135).get(site) + w200_sqms1.getValue(140).get(site) + w200_sqms1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqmg1.getValue(125).get(site) + w200_sqmg1.getValue(130).get(site) + w200_sqmg1.getValue(135).get(site) + w200_sqmg1.getValue(140).get(site) + w200_sqmg1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqmg2.getValue(125).get(site) + w200_sqmg2.getValue(130).get(site) + w200_sqmg2.getValue(135).get(site) + w200_sqmg2.getValue(140).get(site) + w200_sqmg2.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg3.getValue(125).get(site) + w200_sqmg3.getValue(130).get(site) + w200_sqmg3.getValue(135).get(site) + w200_sqmg3.getValue(140).get(site) + w200_sqmg3.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg4.getValue(125).get(site) + w200_sqmg4.getValue(130).get(site) + w200_sqmg4.getValue(135).get(site) + w200_sqmg4.getValue(140).get(site) + w200_sqmg4.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg5.getValue(125).get(site) + w200_sqmg5.getValue(130).get(site) + w200_sqmg5.getValue(135).get(site) + w200_sqmg5.getValue(140).get(site) + w200_sqmg5.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg6.getValue(125).get(site) + w200_sqmg6.getValue(130).get(site) + w200_sqmg6.getValue(135).get(site) + w200_sqmg6.getValue(140).get(site) + w200_sqmg6.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg7.getValue(125).get(site) + w200_sqmg7.getValue(130).get(site) + w200_sqmg7.getValue(135).get(site) + w200_sqmg7.getValue(140).get(site) + w200_sqmg7.getValue(145).get(site))/5.0);
                totalCurrent.setElement(site,i, totalCurrentSite);

             // Print individual currents

                println("SQM1_AVI1 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqms1.getValue(125).get(site) + w200_sqms1.getValue(130).get(site) + w200_sqms1.getValue(135).get(site) + w200_sqms1.getValue(140).get(site) + w200_sqms1.getValue(145).get(site))/5.0) + " A");
                println("SQM1_AVI2 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg1.getValue(125).get(site) + w200_sqmg1.getValue(130).get(site) + w200_sqmg1.getValue(135).get(site) + w200_sqmg1.getValue(140).get(site) + w200_sqmg1.getValue(145).get(site))/5.0) + " A");
                println("SQM2_AVI3 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg2.getValue(125).get(site) + w200_sqmg2.getValue(130).get(site) + w200_sqmg2.getValue(135).get(site) + w200_sqmg2.getValue(140).get(site) + w200_sqmg2.getValue(145).get(site))/5.0) + " A");
                println("SQM2_AVI4 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg3.getValue(125).get(site) + w200_sqmg3.getValue(130).get(site) + w200_sqmg3.getValue(135).get(site) + w200_sqmg3.getValue(140).get(site) + w200_sqmg3.getValue(145).get(site))/5.0) + " A");
                println("SQM3_AVI5 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg4.getValue(125).get(site) + w200_sqmg4.getValue(130).get(site) + w200_sqmg4.getValue(135).get(site) + w200_sqmg4.getValue(140).get(site) + w200_sqmg4.getValue(145).get(site))/5.0) + " A");
                println("SQM3_AVI6 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg5.getValue(125).get(site) + w200_sqmg5.getValue(130).get(site) + w200_sqmg5.getValue(135).get(site) + w200_sqmg5.getValue(140).get(site) + w200_sqmg5.getValue(145).get(site))/5.0) + " A");
                println("SQM4_AVI7 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg6.getValue(125).get(site) + w200_sqmg6.getValue(130).get(site) + w200_sqmg6.getValue(135).get(site) + w200_sqmg6.getValue(140).get(site) + w200_sqmg6.getValue(145).get(site))/5.0) + " A");
                println("SQM4_AVI8 Absolute Average Current = " + "at site :" + site + " and at iset current " + (int)Math.abs(isetValues.get(i)*1000000) + "uA"+ " is :" + (Math.abs(w200_sqmg7.getValue(125).get(site) + w200_sqmg7.getValue(130).get(site) + w200_sqmg7.getValue(135).get(site) + w200_sqmg7.getValue(140).get(site) + w200_sqmg7.getValue(145).get(site))/5.0) + " A");

            }





            println("--------------------------------------");
            println("Total Measured Current = "+ "at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA is :"+ totalCurrent + " A");

          MultiSiteDouble isetCurrent = new MultiSiteDouble(0.001); // 1mA

          println("Forced ISET Current    = " + isetCurrent + " A");

          gain.setElement(i,(totalCurrent.getElement(i)).divide(isetCurrent));

          println("--------------------------------------");
          println("Calculated Gain KQSP   = " + gain);






//    }

        }
        ptdDC1.evaluate(gain,0);
        ptdDC2.evaluate(gain,1);
        ptdDC3.evaluate(gain,2);
        ptdDC4.evaluate(gain,3);

    }
}


