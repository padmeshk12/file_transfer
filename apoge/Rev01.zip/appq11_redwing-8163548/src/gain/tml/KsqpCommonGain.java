package gain.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformDc;
import xoc.dsa.ISetupWaveformRamp;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Common KSQP gain test for one ISET-current and KSQP-voltage pair.
 *
 * <p>Use multiple instances of this test in the test flow, with different
 * values for {@code isetForceCurrent} and {@code ksqpForceVoltage}.
 */
public class KsqpCommonGain extends TestMethod {

    private static final int[] AVERAGE_SAMPLE_INDICES ={70, 75, 80, 85, 90};  // {30, 35, 40, 45, 50}

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    /** ISET current forced during this gain-test instance, in amperes. */
    public double isetForceCurrent;

    /** KSQP waveform voltage forced during this gain-test instance, in volts. */
    public double ksqpForceVoltage;

    /** Number of samples in the KSQP waveform. */
    public int waveformSamples = 100;

    /** KSQP waveform sample rate, in samples per second. */
    public double waveformSampleRate = 300e3;

    public MultiSiteDoubleArray totalMeasuredCurrent =
            new MultiSiteDoubleArray(1, 0.0);

    public MultiSiteDoubleArray calculatedGain =
            new MultiSiteDoubleArray(1, 0.0);

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        String isetCurrentLabel =
                (int) Math.abs(isetForceCurrent * 1_000_000) + "uA";

        String ksqpVoltageLabel =
                (int) Math.abs(ksqpForceVoltage) + "V";


        ISetupUtility VDDQ_C47uF = ds.addUtility("K10_VDDQ2_C47UF").setValue(1);
        ISetupUtility SQP_C47uF = ds.addUtility("K12_SQP4_C47UF").setValue(1);
        ds.addUtility("K11_SQP4_GND").setValue(1);
        ISetupUtility SQM_C47uF = ds.addUtility("K8_SQM1_C47UF").setValue(1);

        // Configure VDD and its operating range.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.1);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.1)
                .setIclamp(0.1);

        // Force VDD to 0 V for powerdown.
        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.1)
                .setIclamp(0.1);

        // Configure ARM_PS for the gain test.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM_PS to 5.5 V.
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Force ARM_PS to 0 V for powerdown.
        ISetupDcVI.IVforce forceArm0V = arm.vforce("force_arm_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Configure LFIRE_PS for the gain test.
        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);

        // Force LFIRE_PS to 5.5 V.
        ISetupDcVI.IVforce forceLfire5p5V = lfire.vforce("force_lfire_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Force LFIRE_PS to 0 V for powerdown.
        ISetupDcVI.IVforce forceLfire0V = lfire.vforce("force_lfire_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Configure HFIRE_PS for the gain test.
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);

        // Force HFIRE_PS to 5.5 V.
        ISetupDcVI.IVforce forceHfire5p5V = hfire.vforce("force_hfire_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Force HFIRE_PS to 0 V for powerdown.
        ISetupDcVI.IVforce forceHfire0V = hfire.vforce("force_hfire_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Configure VDDQ1_AVI1 as the negative reference for SQP1_AVI1.
        ISetupDcVI vddqAvi1 = ds.addDcVI("VDDQ1_AVI1");
        vddqAvi1.setConnect(true).setDisconnect(true);

        // Force VDDQ1_AVI1 to 50 V.
        ISetupDcVI.IVforce forceVddqAvi1To50V =
                vddqAvi1.vforce("force_VDDQ1_AVI1_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.05)
                        .setIclamp(0.05);

        // Force VDDQ1_AVI1 to 0 V for powerdown (kept on 16V range to avoid range-switch clamping).
        ISetupDcVI.IVforce forceVddqAvi1To0V =
                vddqAvi1.vforce("force_VDDQ1_AVI1_0V")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclamp(0.1);

         //Configure VDDQ1_AVI2 for high-current operation.
        ISetupDcVI vddqAvi2 = ds.addDcVI("VDDQ1_AVI2").setConfigOptionHighCurrent();
        vddqAvi2.setConnect(true).setDisconnect(true);

        // Configure VDDQ2_AVI3 for high-current operation.
        ISetupDcVI vddqAvi3 = ds.addDcVI("VDDQ2_AVI3").setConfigOptionHighCurrent();
        vddqAvi3.setConnect(true).setDisconnect(true);

        // Configure VDDQ2_AVI4 for high-current operation.
        ISetupDcVI vddqAvi4 = ds.addDcVI("VDDQ2_AVI4").setConfigOptionHighCurrent();
        vddqAvi4.setConnect(true).setDisconnect(true);

        // Configure VDDQ2_AVI5 for high-current operation.
        ISetupDcVI vddqAvi5 = ds.addDcVI("VDDQ2_AVI5").setConfigOptionHighCurrent();
        vddqAvi5.setConnect(true).setDisconnect(true);

        // Configure VDDQ2_AVI6 for high-current operation.
        ISetupDcVI vddqAvi6 = ds.addDcVI("VDDQ2_AVI6").setConfigOptionHighCurrent();
        vddqAvi6.setConnect(true).setDisconnect(true);

        // Configure VDDQ1_AVI7 for high-current operation.
        ISetupDcVI vddqAvi7 = ds.addDcVI("VDDQ1_AVI7").setConfigOptionHighCurrent();
        vddqAvi7.setConnect(true).setDisconnect(true);

        // Configure VDDQ1_AVI8 for high-current operation.
        ISetupDcVI vddqAvi8 = ds.addDcVI("VDDQ1_AVI8").setConfigOptionHighCurrent();
        vddqAvi8.setConnect(true).setDisconnect(true);

        // Create the DC waveform for the configured KSQP voltage.
        ISetupWaveformDc ksqpWaveform = ds.addWaveformDc(
                "ksqp_waveform_" + ksqpVoltageLabel + "_" + isetCurrentLabel)
                .setDcValue(ksqpForceVoltage)
                .setSamples(waveformSamples)
                .setSampleRate(waveformSampleRate);

        // Configure SQP1_AVI1 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi1 = ds.addDcVI("SQP1_AVI1");
        sqpAvi1.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP1_AVI1.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi1 =
                sqpAvi1.sourceMeasureWaveform(
                        "source_measure_SQP1_AVI1_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ1_AVI1")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP1_AVI2 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi2 = ds.addDcVI("SQP1_AVI2").setConfigOptionHighCurrent();
        sqpAvi2.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP1_AVI2.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi2 =
                sqpAvi2.sourceMeasureWaveform(
                        "source_measure_SQP1_AVI2_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ1_AVI2")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP2_AVI3 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi3 = ds.addDcVI("SQP2_AVI3").setConfigOptionHighCurrent();
        sqpAvi3.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP2_AVI3.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi3 =
                sqpAvi3.sourceMeasureWaveform(
                        "source_measure_SQP2_AVI3_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ2_AVI3")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP2_AVI4 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi4 = ds.addDcVI("SQP2_AVI4").setConfigOptionHighCurrent();
        sqpAvi4.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP2_AVI4.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi4 =
                sqpAvi4.sourceMeasureWaveform(
                        "source_measure_SQP2_AVI4_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ2_AVI4")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP3_AVI5 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi5 = ds.addDcVI("SQP3_AVI5").setConfigOptionHighCurrent();
        sqpAvi5.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP3_AVI5.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi5 =
                sqpAvi5.sourceMeasureWaveform(
                        "source_measure_SQP3_AVI5_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ2_AVI5")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP3_AVI6 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi6 = ds.addDcVI("SQP3_AVI6").setConfigOptionHighCurrent();
        sqpAvi6.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP3_AVI6.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi6 =
                sqpAvi6.sourceMeasureWaveform(
                        "source_measure_SQP3_AVI6_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ2_AVI6")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP4_AVI7 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi7 = ds.addDcVI("SQP4_AVI7").setConfigOptionHighCurrent();
        sqpAvi7.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP4_AVI7.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi7 =
                sqpAvi7.sourceMeasureWaveform(
                        "source_measure_SQP4_AVI7_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ1_AVI7")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure SQP4_AVI8 for waveform voltage force and current measurement.
        ISetupDcVI sqpAvi8 = ds.addDcVI("SQP4_AVI8").setConfigOptionHighCurrent();
        sqpAvi8.setConnect(true)
                .setDisconnect(true);

        // Force KSQP waveform voltage and measure current on SQP4_AVI8.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqpAvi8 =
                sqpAvi8.sourceMeasureWaveform(
                        "source_measure_SQP4_AVI8_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqpWaveform)
                        .setNeg("VDDQ1_AVI8")
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setIrange(4.0);

        // Configure dynamic relays: K5 (VSS to GND) and K4 (ISET to PS1600).
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_1 = K5_VSS_GND.setState("K5_VSS_GND_1").setValue(1).setSettlingTime(0.01);
        ISetupUtility.ISetState K5_VSS_GND_0 = K5_VSS_GND.setState("K5_VSS_GND_0").setValue(0).setSettlingTime(0.01);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_1 = K4_ISET_PS.setState("K4_ISET_PS_1").setValue(1).setSettlingTime(0.01);
        ISetupUtility.ISetState K4_ISET_PS_0 = K4_ISET_PS.setState("K4_ISET_PS_0").setValue(0).setSettlingTime(0.01);

        // Configure ISET for the gain test.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force the configured ISET current.
        ISetupAction forceIsetCurrent = iset.iforce(
                "force_iset_" + isetCurrentLabel)
                .setForceValue(isetForceCurrent)
                .setVrange(5.75)
                .setVclampHigh(5.75)
                .setVclampLow(0.0);

        // Force ISET to 0 A after completing the measurement.
        ISetupAction forceIsetTo0A = iset.iforce("force_iset_0A")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);


        ISetupWaveformRamp isetRamp = ds.addWaveformRamp("iset_ramp_0_to_1mA")
                .setStartValue(isetForceCurrent)
                .setStopValue(isetForceCurrent)
                .setSamples(100)
                .setSampleRate(100e3);

        ISetupDcVI.ISourceWaveform sourceIsetRamp = iset.sourceWaveform("source_iset_ramp")
                .setForceTypeCurrent()
                .setWaveform(isetRamp)
                .setVrange(5.5)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Keep the operating sequence explicit and unchanged in structure.
        ds.parallelBegin("ksqp_gain_test");
        {
            ds.sequentialBegin("ksqp_gain_test");
            {
                // Turn on dynamic relays first
                ds.actionCall(K5_VSS_GND_1);
                ds.actionCall(K4_ISET_PS_1);
                ds.waitCall(0.010);


                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqAvi1To50V);//need to give enough time for cap charge
                ds.waitCall(0.1);

                ds.actionCall(forceIsetCurrent);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfire5p5V);
                ds.actionCall(forceHfire5p5V);
                ds.waitCall(0.010);

                ds.parallelBegin("parallel_sqp_measurements");
                {

                    ds.sequentialBegin("measure_SQP1_AVI1");
                    {
                        ds.actionCall(sourceMeasureSqpAvi1);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP1_AVI2");
                    {
                        ds.actionCall(sourceMeasureSqpAvi2);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP2_AVI3");
                    {
                        ds.actionCall(sourceMeasureSqpAvi3);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP2_AVI4");
                    {
                        ds.actionCall(sourceMeasureSqpAvi4);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP3_AVI5");
                    {
                        ds.actionCall(sourceMeasureSqpAvi5);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP3_AVI6");
                    {
                        ds.actionCall(sourceMeasureSqpAvi6);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP4_AVI7");
                    {
                        ds.actionCall(sourceMeasureSqpAvi7);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQP4_AVI8");
                    {
                        ds.actionCall(sourceMeasureSqpAvi8);
                    }
                    ds.sequentialEnd();
                }
                ds.parallelEnd();

                // Safe powerdown sequence:
                // 1. Force ISET to 0A
                ds.actionCall(forceIsetTo0A);

                // 2. Power down input control pins ARM, LFIRE, HFIRE to 0V
                ds.actionCall(forceArm0V);
                ds.actionCall(forceLfire0V);
                ds.actionCall(forceHfire0V);

                // 3. Power down VDD and VDDQ supplies to 0V
                ds.actionCall(forceVddqAvi1To0V);
                ds.actionCall(forceVdd0V);
                ds.waitCall(0.010);

//                // 4. Turn off dynamic relays
//                ds.actionCall(K5_VSS_GND_0);
//                ds.actionCall(K4_ISET_PS_0);
//                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        measurement.execute();

        println("\n<------- KSQP Common Gain Test START ------->\n");

        IDcVIResults measurementResults = measurement.dcVI(
                "SQP1_AVI1 + SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + "
                        + "SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8")
                .preserveResults();

        String isetCurrentLabel =
                (int) Math.abs(isetForceCurrent * 1_000_000) + "uA";

        MultiSiteWaveDouble sqpAvi1Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP1_AVI1_" + isetCurrentLabel)
                .getWaveform("SQP1_AVI1")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi2Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP1_AVI2_" + isetCurrentLabel)
                .getWaveform("SQP1_AVI2")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi3Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP2_AVI3_" + isetCurrentLabel)
                .getWaveform("SQP2_AVI3")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi4Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP2_AVI4_" + isetCurrentLabel)
                .getWaveform("SQP2_AVI4")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi5Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP3_AVI5_" + isetCurrentLabel)
                .getWaveform("SQP3_AVI5")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi6Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP3_AVI6_" + isetCurrentLabel)
                .getWaveform("SQP3_AVI6")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi7Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP4_AVI7_" + isetCurrentLabel)
                .getWaveform("SQP4_AVI7")
                .getElement(0);

        MultiSiteWaveDouble sqpAvi8Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQP4_AVI8_" + isetCurrentLabel)
                .getWaveform("SQP4_AVI8")
                .getElement(0);

        for (int site : context.getActiveSites()) {

            double sqpAvi1Current = Math.abs(
                    sqpAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi2Current = Math.abs(
                    sqpAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi3Current = Math.abs(
                    sqpAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi4Current = Math.abs(
                    sqpAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi5Current = Math.abs(
                    sqpAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi6Current = Math.abs(
                    sqpAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi7Current = Math.abs(
                    sqpAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqpAvi8Current = Math.abs(
                    sqpAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqpAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqpAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqpAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqpAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double totalCurrentForSite =
                    sqpAvi1Current
                            + sqpAvi2Current
                            + sqpAvi3Current
                            + sqpAvi4Current
                            + sqpAvi5Current
                            + sqpAvi6Current
                            + sqpAvi7Current
                            + sqpAvi8Current;

            totalMeasuredCurrent.setElement(site, 0, totalCurrentForSite);

            println("SQP1_AVI1 average current at site " + site + ": "
                    + sqpAvi1Current + " A");
            println("SQP1_AVI2 average current at site " + site + ": "
                    + sqpAvi2Current + " A");
            println("SQP2_AVI3 average current at site " + site + ": "
                    + sqpAvi3Current + " A");
            println("SQP2_AVI4 average current at site " + site + ": "
                    + sqpAvi4Current + " A");
            println("SQP3_AVI5 average current at site " + site + ": "
                    + sqpAvi5Current + " A");
            println("SQP3_AVI6 average current at site " + site + ": "
                    + sqpAvi6Current + " A");
            println("SQP4_AVI7 average current at site " + site + ": "
                    + sqpAvi7Current + " A");
            println("SQP4_AVI8 average current at site " + site + ": "
                    + sqpAvi8Current + " A");
        }

        calculatedGain.setElement(
                0,
                totalMeasuredCurrent.getElement(0)
                        .divide(Math.abs(isetForceCurrent)));

        println("--------------------------------------");
        println("Total measured SQP current: " + totalMeasuredCurrent + " A");
        println("Forced ISET current: " + isetForceCurrent + " A");
        println("Calculated KSQP gain: " + calculatedGain);
        println("--------------------------------------");

        ptdDC.evaluate(calculatedGain, 0);
    }
}
