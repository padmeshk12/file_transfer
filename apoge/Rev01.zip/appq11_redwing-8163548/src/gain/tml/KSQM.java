package gain.tml;

import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * RON_VARYING_LOAD - By ///--MonishKumar--//
 *
 * This test method measures the ON resistance (RON) of the power switch
 * under three different current pulsing loads: 200mA, 500mA, and Full Load (FL).
 *
 * The calculations average the voltages on the 8 VIN pins relative to VOUT pins.
 */
public class KSQM extends TestMethod {

    public IMeasurement measurement;
    public IDeviceSetup deviceSetup;
    public IParametricTestDescriptor ptdDC;





    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        deviceSetup = ds;


        // ----------------------------------------------------------------
        // Instrument Actions and Measurement Setup Declarations
        // ----------------------------------------------------------------

        // Configure VDD supply (AVI/DcVI) connect/disconnect settings and actions
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
//        .setVforce(voltageForce)           // Force voltage (V)
        .setVrange(7.0)           // Voltage range (V)
        .setIrange(0.2);       // Current range (A)
//        .setIclamp(currentClamp);

        ISetupDcVI.IVforce vddForce5p5V = vdd.vforce("vdd_force_5p5V")
                .setForceValue(5.5)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForce5p5V = arm.vforce("arm_force_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce5p5V = lfire.vforce("lfire_force_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce5p5V = hfire.vforce("hfire_force_5p5V")
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);



        ISetupWaveformDc dcWaveformSQM = ds.addWaveformDc("PulseSQM").setDcValue(6).setSamples(200).setSampleRate(100e3);

        ISetupDcVI sqms1 = ds.addDcVI("SQM1_AVI1"); // Need to check state of SQM and VSSQ
        sqms1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqms1_Vpulse_Source_Meas =
                sqms1.sourceMeasureWaveform("sqms1_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(4.0).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

//        ISetupDcVI.IVforce sqpForce44V = sqps1.vforce("sqps_force_44V")
//                .setForceValue(44.0)
//                .setVrange(60.0)
//                .setIrange(0.05)
//                .setIclamp(0.05);
//        ISetupDcVI.IImeas sqps1Meas = sqps1.imeas("sqps_meas").setIrange(0.2);

        ISetupDcVI sqmg1 = ds.addDcVI("SQM1_AVI2 ");
        sqmg1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();
        ISetupDcVI.ISourceMeasureWaveform sqmg1_Vpulse_Source_Meas =
                sqmg1.sourceMeasureWaveform("sqmg1_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(4.0).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);


////        sqpg.level().setIrange(4.0).setIclamp(4.0);
//        sqpg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU1 = sqpg1.imeas("meas_HCU1")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VSSQ_G1");

        ISetupDcVI sqmg2 = ds.addDcVI("SQM2_AVI3 ");
        sqmg2.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();
        ISetupDcVI.ISourceMeasureWaveform sqmg2_Vpulse_Source_Meas =
                sqmg2.sourceMeasureWaveform("sqmg2_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(4.0).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);
////        sqpg.level().setIrange(4.0).setIclamp(4.0);
//        sqpg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU2 = sqpg2.imeas("meas_HCU2")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VSSQ_G2");
        ISetupDcVI sqmg3 = ds.addDcVI("SQM2_AVI4 ");
        sqmg3.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg3_Vpulse_Source_Meas =
                sqmg3.sourceMeasureWaveform("sqmg3_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(4.0).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);
////        sqpg.level().setIrange(4.0).setIclamp(4.0);
//        sqpg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU3 = sqpg3.imeas("meas_HCU3")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VSSQ_G3");
        ISetupDcVI sqmg4 = ds.addDcVI("SQM3_AVI5 ");
        sqmg4.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg4_Vpulse_Source_Meas =
                sqmg4.sourceMeasureWaveform("sqmg4_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(4.0).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

        ISetupDcVI sqmg5 = ds.addDcVI("SQM3_AVI6 ");
        sqmg5.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg5_Vpulse_Source_Meas =
                sqmg5.sourceMeasureWaveform("sqmg5_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(4.0).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

        ISetupDcVI sqmg6 = ds.addDcVI("SQM4_AVI7 ");
        sqmg6.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg6_Vpulse_Source_Meas =
                sqmg6.sourceMeasureWaveform("sqmg6_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(0.05).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);

        ISetupDcVI sqmg7 = ds.addDcVI("SQM4_AVI8 ");
        sqmg7.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqmg7_Vpulse_Source_Meas =
                sqmg7.sourceMeasureWaveform("sqmg7_Source_Measure").setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQM).setIrange(0.05).setIclamp(4.0).setSamples(200).setNeg("GND").setIrange(4.0);
//        ISetupDcVI sqpg = ds.addDcVI("SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4");
//        sqpg.setConfigOptionHighCurrent().setConnectModeStandard();
//        sqpg.setDisconnect(true);
//        ISetupAction sqpgDisconnect = sqpg.disconnect();
//
//        IMeasureWaveform sqpgMeasHCU = sqpg.measureWaveform("meas_HCU")
//                .setMeasTypeCurrent()
//                .setIrange(4.0).setSamples(256).setSampleRate(100000).setNeg("VSSQ_G1 ");

        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        ISetupAction isetCurrForce = iset.iforce("iset_force_1mA").setForceValue(0.001).setVrange(5.75)
                .setVclampHigh(5.5).setVclampLow(0.0);

        ISetupAction iset0mA = iset.iforce("iset_force_0mA").setForceValue(0.0).setVrange(5.75)
                .setVclampHigh(5.5).setVclampLow(0.0);

        // ----------------------------------------------------------------
        // Operating Sequence Execution (Dynamic Call Area)
        // ----------------------------------------------------------------

        ds.sequentialBegin("kqsm");
        {

            // Set background configurations
            ds.actionCall(vddForce5p5V);
            ds.actionCall(isetCurrForce);
            ds.actionCall(armForce5p5V);
            ds.actionCall(lfireForce5p5V);
            ds.actionCall(hfireForce5p5V);


            ds.parallelBegin();




                    ds.sequentialBegin("seq1");
                    {
                        ds.actionCall(sqms1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq2");
                    {
                        ds.actionCall(sqmg1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq3");
                    {
                        ds.actionCall(sqmg2_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq4");
                    {
                        ds.actionCall(sqmg3_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq5");
                    {
                        ds.actionCall(sqmg4_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq6");
                    {
                        ds.actionCall(sqmg5_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq7");
                    {
                        ds.actionCall(sqmg6_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq8");
                    {
                        ds.actionCall(sqmg7_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

            ds.parallelEnd();

            ds.actionCall(iset0mA);

        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic parameter updates needed
    }

    @Override
    public void execute() {

        // Run measurement
        measurement.execute();

        IDcVIResults measResults = measurement.dcVI("SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 + SQM4_AVI8").preserveResults();


        Map<String, MultiSiteDoubleArray> iMeasResults = measResults.imeas("").getCurrent();

        for (Map.Entry<String, MultiSiteDoubleArray> entry : iMeasResults.entrySet()) {
            println("Measured Signal : " + entry.getKey() +
                    " -> " + entry.getValue());
        }

//        IDcVIResults vinResults = measurement.dcVI("VIN1+VIN2+VIN3+VIN4_RS1+VIN4_RS2+VIN5_RS1+VIN5_RS2+VIN6").preserveResults();

//        releaseTester();

        boolean isOffline = context.testProgram().variables().getBoolean("SYS.OFFLINE").get();

//        if (!isOffline) {
            // Retrieve differential VIN waveforms (each VIN measures VIN - paired VOUT via setNeg)
            // VIN1_Wave_200mA gives VIN1 - VOUT6, VIN2_Wave_200mA gives VIN2 - VOUT5, etc.
            MultiSiteWaveDouble w200_sqms1 = measResults.sourceMeasureWaveform("sqms1_Source_Measure").getWaveform("SQM1_AVI1").getElement(0);
            MultiSiteWaveDouble w200_sqmg1 = measResults.sourceMeasureWaveform("sqmg1_Source_Measure").getWaveform("SQM1_AVI2").getElement(0);
            MultiSiteWaveDouble w200_sqmg2 = measResults.sourceMeasureWaveform("sqmg2_Source_Measure").getWaveform("SQM2_AVI3").getElement(0);
            MultiSiteWaveDouble w200_sqmg3 = measResults.sourceMeasureWaveform("sqmg3_Source_Measure").getWaveform("SQM2_AVI4").getElement(0);
            MultiSiteWaveDouble w200_sqmg4 = measResults.sourceMeasureWaveform("sqmg4_Source_Measure").getWaveform("SQM3_AVI5").getElement(0);
            MultiSiteWaveDouble w200_sqmg5 = measResults.sourceMeasureWaveform("sqmg5_Source_Measure").getWaveform("SQM3_AVI6").getElement(0);
            MultiSiteWaveDouble w200_sqmg6 = measResults.sourceMeasureWaveform("sqmg6_Source_Measure").getWaveform("SQM4_AVI7").getElement(0);
            MultiSiteWaveDouble w200_sqmg7 = measResults.sourceMeasureWaveform("sqmg7_Source_Measure").getWaveform("SQM4_AVI8").getElement(0);



            // Perform calculations across active sites

            MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);
            MultiSiteDouble gain = new MultiSiteDouble(0.0);


            for (int site : context.getActiveSites()) {

                double totalCurrentSite = (Math.abs(w200_sqms1.getValue(125).get(site) + w200_sqms1.getValue(130).get(site) + w200_sqms1.getValue(135).get(site) + w200_sqms1.getValue(140).get(site) + w200_sqms1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqmg1.getValue(125).get(site) + w200_sqmg1.getValue(130).get(site) + w200_sqmg1.getValue(135).get(site) + w200_sqmg1.getValue(140).get(site) + w200_sqmg1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqmg2.getValue(125).get(site) + w200_sqmg2.getValue(130).get(site) + w200_sqmg2.getValue(135).get(site) + w200_sqmg2.getValue(140).get(site) + w200_sqmg2.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg3.getValue(125).get(site) + w200_sqmg3.getValue(130).get(site) + w200_sqmg3.getValue(135).get(site) + w200_sqmg3.getValue(140).get(site) + w200_sqmg3.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg4.getValue(125).get(site) + w200_sqmg4.getValue(130).get(site) + w200_sqmg4.getValue(135).get(site) + w200_sqmg4.getValue(140).get(site) + w200_sqmg4.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg5.getValue(125).get(site) + w200_sqmg5.getValue(130).get(site) + w200_sqmg5.getValue(135).get(site) + w200_sqmg5.getValue(140).get(site) + w200_sqmg5.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg6.getValue(125).get(site) + w200_sqmg6.getValue(130).get(site) + w200_sqmg6.getValue(135).get(site) + w200_sqmg6.getValue(140).get(site) + w200_sqmg6.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqmg7.getValue(125).get(site) + w200_sqmg7.getValue(130).get(site) + w200_sqmg7.getValue(135).get(site) + w200_sqmg7.getValue(140).get(site) + w200_sqmg7.getValue(145).get(site))/5.0);
                totalCurrent.set(site, totalCurrentSite);

             // Print individual currents

                println("SQM1_AVI1 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqms1.getValue(125).get(site) + w200_sqms1.getValue(130).get(site) + w200_sqms1.getValue(135).get(site) + w200_sqms1.getValue(140).get(site) + w200_sqms1.getValue(145).get(site))/5.0) + " A");
                println("SQM1_AVI2 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg1.getValue(125).get(site) + w200_sqmg1.getValue(130).get(site) + w200_sqmg1.getValue(135).get(site) + w200_sqmg1.getValue(140).get(site) + w200_sqmg1.getValue(145).get(site))/5.0) + " A");
                println("SQM2_AVI3 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg2.getValue(125).get(site) + w200_sqmg2.getValue(130).get(site) + w200_sqmg2.getValue(135).get(site) + w200_sqmg2.getValue(140).get(site) + w200_sqmg2.getValue(145).get(site))/5.0) + " A");
                println("SQM2_AVI4 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg3.getValue(125).get(site) + w200_sqmg3.getValue(130).get(site) + w200_sqmg3.getValue(135).get(site) + w200_sqmg3.getValue(140).get(site) + w200_sqmg3.getValue(145).get(site))/5.0) + " A");
                println("SQM3_AVI5 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg4.getValue(125).get(site) + w200_sqmg4.getValue(130).get(site) + w200_sqmg4.getValue(135).get(site) + w200_sqmg4.getValue(140).get(site) + w200_sqmg4.getValue(145).get(site))/5.0) + " A");
                println("SQM3_AVI6 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg5.getValue(125).get(site) + w200_sqmg5.getValue(130).get(site) + w200_sqmg5.getValue(135).get(site) + w200_sqmg5.getValue(140).get(site) + w200_sqmg5.getValue(145).get(site))/5.0) + " A");
                println("SQM4_AVI7 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg6.getValue(125).get(site) + w200_sqmg6.getValue(130).get(site) + w200_sqmg6.getValue(135).get(site) + w200_sqmg6.getValue(140).get(site) + w200_sqmg6.getValue(145).get(site))/5.0) + " A");
                println("SQM4_AVI8 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqmg7.getValue(125).get(site) + w200_sqmg7.getValue(130).get(site) + w200_sqmg7.getValue(135).get(site) + w200_sqmg7.getValue(140).get(site) + w200_sqmg7.getValue(145).get(site))/5.0) + " A");

            }





            println("--------------------------------------");
          println("Total Measured Current = " + totalCurrent + " A");

          MultiSiteDouble isetCurrent = new MultiSiteDouble(0.001); // 1mA

          println("Forced ISET Current    = " + isetCurrent + " A");

          gain = totalCurrent.divide(isetCurrent);

          println("--------------------------------------");
          println("Calculated Gain KQSM   = " + gain);


          ptdDC.evaluate(gain);


    }
}

