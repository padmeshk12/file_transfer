package gain.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Common KSQM gain test for one ISET-current and KSQM-voltage pair.
 *
 * <p>Use multiple instances of this test in the test flow, with different
 * values for {@code isetForceCurrent} and {@code ksqmForceVoltage}.
 */
public class KsqmCommonGain extends TestMethod {

    private static final int[] AVERAGE_SAMPLE_INDICES = {70, 75, 80, 85, 90};

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    /** ISET current forced during this gain-test instance, in amperes. */
    public double isetForceCurrent;

    /** KSQM waveform voltage forced during this gain-test instance, in volts. */
    public double ksqmForceVoltage;

    /** Number of samples in the KSQM waveform. */
    public int waveformSamples = 100;

    /** KSQM waveform sample rate, in samples per second. */
    public double waveformSampleRate = 300e3;

    public MultiSiteDoubleArray totalMeasuredCurrent =
            new MultiSiteDoubleArray(1, 0.0);

    public MultiSiteDoubleArray calculatedGain =
            new MultiSiteDoubleArray(1, 0.0);

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        String isetCurrentLabel =
                (int) Math.abs(isetForceCurrent * 1_000_000) + "uA";

        String ksqmVoltageLabel =
                (int) Math.abs(ksqmForceVoltage) + "V";

        ISetupUtility VDDQ_C47uF = ds.addUtility("K10_VDDQ2_C47UF").setValue(1);
        ISetupUtility SQP_C47uF = ds.addUtility("K12_SQP4_C47UF").setValue(1);
        ISetupUtility SQM_C47uF = ds.addUtility("K8_SQM1_C47UF").setValue(1);

        // Configure VDD and its operating range.
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
                .setVrange(7.0)
                .setIrange(0.1);

        // Force VDD to 5.5 V.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.1)
                .setIclamp(0.1);

        // Force VDD to 0 V for powerdown.
        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.1)
                .setIclamp(0.1);

        // Configure ARM_PS for the gain test.
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        // Force ARM_PS to 5.5 V.
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Force ARM_PS to 0 V for powerdown.
        ISetupDcVI.IVforce forceArm0V = arm.vforce("force_arm_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Configure LFIRE_PS for the gain test.
        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);

        // Force LFIRE_PS to 5.5 V.
        ISetupDcVI.IVforce forceLfire5p5V = lfire.vforce("force_lfire_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Force LFIRE_PS to 0 V for powerdown.
        ISetupDcVI.IVforce forceLfire0V = lfire.vforce("force_lfire_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Configure HFIRE_PS for the gain test.
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);

        // Force HFIRE_PS to 5.5 V.
        ISetupDcVI.IVforce forceHfire5p5V = hfire.vforce("force_hfire_5p5V")
                .setForceValue(5.5)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);

        // Force HFIRE_PS to 0 V for powerdown.
        ISetupDcVI.IVforce forceHfire0V = hfire.vforce("force_hfire_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.04)
                .setIclamp(0.04);


     // Configure VDDQ1_AVI1 as the negative reference for SQP1_AVI1.
        ISetupDcVI vddqAvi1 = ds.addDcVI("VDDQ1_AVI1");
        vddqAvi1.setConnect(true).setDisconnect(true);

        // Force VDDQ1_AVI1 to 50 V.
        ISetupDcVI.IVforce forceVddqAvi1To50V =
                vddqAvi1.vforce("force_VDDQ1_AVI1_50V")
                        .setForceValue(12.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclamp(0.1);

        // Force VDDQ1_AVI1 to 0 V for powerdown (kept on 16V range to avoid range-switch clamping).
        ISetupDcVI.IVforce forceVddqAvi1To0V =
                vddqAvi1.vforce("force_VDDQ1_AVI1_0V")
                        .setForceValue(0.0)
                        .setVrange(16.0)
                        .setIrange(0.1)
                        .setIclamp(0.1);

        // Create the DC waveform for the configured KSQM voltage.
        ISetupWaveformDc ksqmWaveform = ds.addWaveformDc(
                "ksqm_waveform_" + ksqmVoltageLabel + "_" + isetCurrentLabel)
                .setDcValue(ksqmForceVoltage)
                .setSamples(waveformSamples)
                .setSampleRate(waveformSampleRate);

        // Configure SQM1_AVI1 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi1 = ds.addDcVI("SQM1_AVI1");
        sqmAvi1.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM1_AVI1.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi1 =
                sqmAvi1.sourceMeasureWaveform(
                        "source_measure_SQM1_AVI1_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM1_AVI2 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi2 = ds.addDcVI("SQM1_AVI2");
        sqmAvi2.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM1_AVI2.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi2 =
                sqmAvi2.sourceMeasureWaveform(
                        "source_measure_SQM1_AVI2_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM2_AVI3 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi3 = ds.addDcVI("SQM2_AVI3");
        sqmAvi3.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM2_AVI3.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi3 =
                sqmAvi3.sourceMeasureWaveform(
                        "source_measure_SQM2_AVI3_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM2_AVI4 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi4 = ds.addDcVI("SQM2_AVI4");
        sqmAvi4.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);


        // Force KSQM waveform voltage and measure current on SQM2_AVI4.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi4 =
                sqmAvi4.sourceMeasureWaveform(
                        "source_measure_SQM2_AVI4_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM3_AVI5 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi5 = ds.addDcVI("SQM3_AVI5");
        sqmAvi5.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM3_AVI5.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi5 =
                sqmAvi5.sourceMeasureWaveform(
                        "source_measure_SQM3_AVI5_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM3_AVI6 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi6 = ds.addDcVI("SQM3_AVI6");
        sqmAvi6.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM3_AVI6.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi6 =
                sqmAvi6.sourceMeasureWaveform(
                        "source_measure_SQM3_AVI6_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM4_AVI7 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi7 = ds.addDcVI("SQM4_AVI7");
        sqmAvi7.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM4_AVI7.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi7 =
                sqmAvi7.sourceMeasureWaveform(
                        "source_measure_SQM4_AVI7_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure SQM4_AVI8 for waveform voltage force and current measurement.
        ISetupDcVI sqmAvi8 = ds.addDcVI("SQM4_AVI8");
        sqmAvi8.setConnect(true).setConfigOptionHighCurrent()
                .setDisconnect(true);

        // Force KSQM waveform voltage and measure current on SQM4_AVI8.
        ISetupDcVI.ISourceMeasureWaveform sourceMeasureSqmAvi8 =
                sqmAvi8.sourceMeasureWaveform(
                        "source_measure_SQM4_AVI8_" + isetCurrentLabel)
                        .setForceTypeVoltage()
                        .setMeasTypeCurrent()
                        .setWaveform(ksqmWaveform)
                        .setIclamp(4.0)
                        .setSamples(waveformSamples)
                        .setNeg("GND")
                        .setIrange(4.0);

        // Configure dynamic relays: K5 (VSS to GND) and K4 (ISET to PS1600).
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_1 = K5_VSS_GND.setState("K5_VSS_GND_1").setValue(1).setSettlingTime(0.01);
        ISetupUtility.ISetState K5_VSS_GND_0 = K5_VSS_GND.setState("K5_VSS_GND_0").setValue(0).setSettlingTime(0.01);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_1 = K4_ISET_PS.setState("K4_ISET_PS_1").setValue(1).setSettlingTime(0.01);
        ISetupUtility.ISetState K4_ISET_PS_0 = K4_ISET_PS.setState("K4_ISET_PS_0").setValue(0).setSettlingTime(0.01);

        // Configure ISET for the gain test.
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        // Force the configured ISET current.
        ISetupAction forceIsetCurrent = iset.iforce(
                "force_iset_" + isetCurrentLabel)
                .setForceValue(isetForceCurrent)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Force ISET to 0 A after completing the measurement.
        ISetupAction forceIsetTo0A = iset.iforce("force_iset_0A")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);

        // Keep the operating sequence explicit and unchanged in structure.
        ds.parallelBegin("ksqm_gain_test");
        {
            ds.sequentialBegin("ksqm_gain_test");
            {
                // Turn on dynamic relays first
                ds.actionCall(K5_VSS_GND_1);
                ds.actionCall(K4_ISET_PS_1);
                ds.waitCall(0.010);

                ds.actionCall(forceVdd5p5V);
                ds.actionCall(forceVddqAvi1To50V);//need to give enough time for cap charge
                ds.waitCall(0.1);
                ds.actionCall(forceIsetCurrent);
                ds.actionCall(forceArm5p5V);
                ds.actionCall(forceLfire5p5V);
                ds.actionCall(forceHfire5p5V);
                ds.waitCall(0.010);

                ds.parallelBegin("parallel_sqm_measurements");
                {
                    ds.sequentialBegin("measure_SQM1_AVI1");
                    {
                        ds.actionCall(sourceMeasureSqmAvi1);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQM1_AVI2");
                    {
                        ds.actionCall(sourceMeasureSqmAvi2);
                    }
                    ds.sequentialEnd();

//                    ds.sequentialBegin("measure_SQM2_AVI3");
//                    {
//                        ds.actionCall(sourceMeasureSqmAvi3);
//                    }
//                    ds.sequentialEnd();

//                    ds.sequentialBegin("measure_SQM2_AVI4");
//                    {
//                        ds.actionCall(sourceMeasureSqmAvi4);
//                    }
//                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQM3_AVI5");
                    {
                        ds.actionCall(sourceMeasureSqmAvi5);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQM3_AVI6");
                    {
                        ds.actionCall(sourceMeasureSqmAvi6);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQM4_AVI7");
                    {
                        ds.actionCall(sourceMeasureSqmAvi7);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("measure_SQM4_AVI8");
                    {
                        ds.actionCall(sourceMeasureSqmAvi8);
                    }
                    ds.sequentialEnd();
                }
                ds.parallelEnd();

                // Safe powerdown sequence:
                // 1. Force ISET to 0A
                ds.actionCall(forceIsetTo0A);

                // 2. Power down input control pins ARM, LFIRE, HFIRE to 0V
                ds.actionCall(forceArm0V);
                ds.actionCall(forceLfire0V);
                ds.actionCall(forceHfire0V);

                // 3. Power down VDD and VDDQ supplies to 0V
                ds.actionCall(forceVddqAvi1To0V);
                ds.actionCall(forceVdd0V);
                ds.waitCall(0.010);

                // 4. Turn off dynamic relays
//                ds.actionCall(K5_VSS_GND_0);
//                ds.actionCall(K4_ISET_PS_0);
//                ds.waitCall(0.010);
            }
            ds.sequentialEnd();
        }
        ds.parallelEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic setup updates are required for this test.
    }

    @Override
    public void execute() {

        measurement.execute();

        println("\n<------- KSQM Common Gain Test START ------->\n");

        IDcVIResults measurementResults = measurement.dcVI(
                "SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + "
                        + "SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 + SQM4_AVI8")
                .preserveResults();

        String isetCurrentLabel =
                (int) Math.abs(isetForceCurrent * 1_000_000) + "uA";

        MultiSiteWaveDouble sqmAvi1Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQM1_AVI1_" + isetCurrentLabel)
                .getWaveform("SQM1_AVI1")
                .getElement(0);

        MultiSiteWaveDouble sqmAvi2Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQM1_AVI2_" + isetCurrentLabel)
                .getWaveform("SQM1_AVI2")
                .getElement(0);

//        MultiSiteWaveDouble sqmAvi3Waveform = measurementResults
//                .sourceMeasureWaveform("source_measure_SQM2_AVI3_" + isetCurrentLabel)
//                .getWaveform("SQM2_AVI3")
//                .getElement(0);
//
//        MultiSiteWaveDouble sqmAvi4Waveform = measurementResults
//                .sourceMeasureWaveform("source_measure_SQM2_AVI4_" + isetCurrentLabel)
//                .getWaveform("SQM2_AVI4")
//                .getElement(0);

        MultiSiteWaveDouble sqmAvi5Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQM3_AVI5_" + isetCurrentLabel)
                .getWaveform("SQM3_AVI5")
                .getElement(0);

        MultiSiteWaveDouble sqmAvi6Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQM3_AVI6_" + isetCurrentLabel)
                .getWaveform("SQM3_AVI6")
                .getElement(0);

        MultiSiteWaveDouble sqmAvi7Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQM4_AVI7_" + isetCurrentLabel)
                .getWaveform("SQM4_AVI7")
                .getElement(0);

        MultiSiteWaveDouble sqmAvi8Waveform = measurementResults
                .sourceMeasureWaveform("source_measure_SQM4_AVI8_" + isetCurrentLabel)
                .getWaveform("SQM4_AVI8")
                .getElement(0);

        for (int site : context.getActiveSites()) {

            double sqmAvi1Current = Math.abs(
                    sqmAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqmAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqmAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqmAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqmAvi1Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqmAvi2Current = Math.abs(
                    sqmAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqmAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqmAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqmAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqmAvi2Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

//            double sqmAvi3Current = Math.abs(
//                    sqmAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
//                            + sqmAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
//                            + sqmAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
//                            + sqmAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
//                            + sqmAvi3Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
//                    / AVERAGE_SAMPLE_INDICES.length;
//
//            double sqmAvi4Current = Math.abs(
//                    sqmAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
//                            + sqmAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
//                            + sqmAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
//                            + sqmAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
//                            + sqmAvi4Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
//                    / AVERAGE_SAMPLE_INDICES.length;

            double sqmAvi5Current = Math.abs(
                    sqmAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqmAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqmAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqmAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqmAvi5Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqmAvi6Current = Math.abs(
                    sqmAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqmAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqmAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqmAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqmAvi6Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqmAvi7Current = Math.abs(
                    sqmAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqmAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqmAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqmAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqmAvi7Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double sqmAvi8Current = Math.abs(
                    sqmAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[0]).get(site)
                            + sqmAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[1]).get(site)
                            + sqmAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[2]).get(site)
                            + sqmAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[3]).get(site)
                            + sqmAvi8Waveform.getValue(AVERAGE_SAMPLE_INDICES[4]).get(site))
                    / AVERAGE_SAMPLE_INDICES.length;

            double totalCurrentForSite =
                    sqmAvi1Current
                            + sqmAvi2Current
//                            + sqmAvi3Current
//                            + sqmAvi4Current
                            + sqmAvi5Current
                            + sqmAvi6Current
                            + sqmAvi7Current
                            + sqmAvi8Current;

            totalMeasuredCurrent.setElement(site, 0, totalCurrentForSite);

            println("SQM1_AVI1 average current at site " + site + ": "
                    + sqmAvi1Current + " A");
            println("SQM1_AVI2 average current at site " + site + ": "
                    + sqmAvi2Current + " A");
//            println("SQM2_AVI3 average current at site " + site + ": "
//                    + sqmAvi3Current + " A");
//            println("SQM2_AVI4 average current at site " + site + ": "
//                    + sqmAvi4Current + " A");
            println("SQM3_AVI5 average current at site " + site + ": "
                    + sqmAvi5Current + " A");
            println("SQM3_AVI6 average current at site " + site + ": "
                    + sqmAvi6Current + " A");
            println("SQM4_AVI7 average current at site " + site + ": "
                    + sqmAvi7Current + " A");
            println("SQM4_AVI8 average current at site " + site + ": "
                    + sqmAvi8Current + " A");
        }

        calculatedGain.setElement(
                0,
                totalMeasuredCurrent.getElement(0)
                        .divide(Math.abs(isetForceCurrent)));

        println("--------------------------------------");
        println("Total measured SQM current: " + totalMeasuredCurrent + " A");
        println("Forced ISET current: " + isetForceCurrent + " A");
        println("Calculated KSQM gain: " + calculatedGain);
        println("--------------------------------------");

        ptdDC.evaluate(calculatedGain, 0);
    }
}
