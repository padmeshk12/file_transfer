package gain.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.measurement.IMeasurement;

/**
 * Utility test method to de-energize (open) all relays on the DUT board.
 *
 * <p>Ensures that all utility relays (K1 through K14) are set to 0 (open)
 * with a settling time after running tests in the test flow.
 */
public class RelayOpen extends TestMethod {

    public IMeasurement measurement;

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        // Actively discharge VDDQGroup before opening relays
        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce forceVddq0V = vddq.vforce("force_vddq_open_0V")
                .setForceValue(0.0)
                .setVrange(16.0)
                .setIrange(0.1)
                .setIclamp(0.1);
        ISetupDcVI.IDisconnect disConnectVddq = vddq.disconnect("disconnect_vddq");

        // Actively discharge VDD_DPS (DPS128)
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.1);
        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_open_0V")
                .setForceValue(0.0)
                .setIrange(0.1)
                .setIclamp(0.1);
        ISetupDcVI.IDisconnect disConnectVdd = vdd.disconnect("disconnect_vdd");

        // De-energize all relays on the REDWING DUT board to state 0 (open)
        ISetupUtility k1 = ds.addUtility("K1_ISET_R24K");
        ISetupUtility.ISetState k1_0 = k1.setState("k1_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k2 = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState k2_0 = k2.setState("k2_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k3 = ds.addUtility("K3_ISET_R2P4K");
        ISetupUtility.ISetState k3_0 = k3.setState("k3_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k4 = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState k4_0 = k4.setState("k4_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k5 = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState k5_0 = k5.setState("k5_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k6 = ds.addUtility("K6_VSS_PS");
        ISetupUtility.ISetState k6_0 = k6.setState("k6_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k7 = ds.addUtility("K7_SQM1_PS");
        ISetupUtility.ISetState k7_0 = k7.setState("k7_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k8 = ds.addUtility("K8_SQM1_C47UF");
        ISetupUtility.ISetState k8_0 = k8.setState("k8_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k9 = ds.addUtility("K9_VDD_PS");
        ISetupUtility.ISetState k9_0 = k9.setState("k9_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k10 = ds.addUtility("K10_VDDQ2_C47UF");
        ISetupUtility.ISetState k10_0 = k10.setState("k10_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k11 = ds.addUtility("K11_SQP4_GND");
        ISetupUtility.ISetState k11_0 = k11.setState("k11_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k12 = ds.addUtility("K12_SQP4_C47UF");
        ISetupUtility.ISetState k12_0 = k12.setState("k12_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k13 = ds.addUtility("K13_SQP1_PS");
        ISetupUtility.ISetState k13_0 = k13.setState("k13_0").setValue(0).setSettlingTime(0.01);
        ISetupUtility k14 = ds.addUtility("K14_TD_DPS");
        ISetupUtility.ISetState k14_0 = k14.setState("k14_0").setValue(0).setSettlingTime(0.01);

        ds.sequentialBegin("relay_open_seq");
        {
            // 1. Force 0V to bleed off 47uF capacitor on VDDQ and VDD before opening relays
            ds.actionCall(forceVddq0V);
            ds.actionCall(forceVdd0V);
            ds.waitCall(0.1);

            // 2. Open all relays while held at 0V
            ds.actionCall(k1_0);
            ds.actionCall(k2_0);
            ds.actionCall(k3_0);
            ds.actionCall(k4_0);
            ds.actionCall(k5_0);
            ds.actionCall(k6_0);
            ds.actionCall(k7_0);
            ds.actionCall(k8_0);
            ds.actionCall(k9_0);
            ds.actionCall(k10_0);
            ds.actionCall(k11_0);
            ds.actionCall(k12_0);
            ds.actionCall(k13_0);
            ds.actionCall(k14_0);
            ds.waitCall(0.020);

            // 3. Disconnect supplies
            ds.actionCall(disConnectVddq);
            ds.actionCall(disConnectVdd);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic updates required.
    }

    @Override
    public void execute() {
        measurement.execute();
        println("\n<------- All Relays Opened (K1 - K14 = 0) ------->\n");
    }
}
