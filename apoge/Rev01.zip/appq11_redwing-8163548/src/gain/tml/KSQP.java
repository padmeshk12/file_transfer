package gain.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * KQSP Gain - By ///--Rajeev reddy--//
 *
 * This test method Calculates the current gain by measuring the current out of SQP
 *
 */
public class KSQP extends TestMethod {

    public IMeasurement measurement;
    public IDeviceSetup deviceSetup;


    /** Parametric test descriptors for datalogging */
    public IParametricTestDescriptor ptdDC;

    @Override
    public void setup() {

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        // ----------------------------------------------------------------
        // Instrument Actions and Measurement Setup Declarations
        // ----------------------------------------------------------------

        // Configure VDD supply (AVI/DcVI) connect/disconnect settings and actions
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0) .setIrange(0.025);

        ISetupDcVI.IVforce vddForce5p5V = vdd.vforce("vdd_force_5p5V").setForceValue(5.5)
                .setIrange(0.025).setIclamp(0.025);


        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce armForce5p5V = arm.vforce("arm_force_5p5V").setForceValue(5.5)
                .setVrange(6.0).setIrange(0.001).setIclamp(0.001);


        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce lfireForce5p5V = lfire.vforce("lfire_force_5p5V").setForceValue(5.5)
                .setVrange(6.0).setIrange(0.001).setIclamp(0.001);


        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce hfireForce5p5V = hfire.vforce("hfire_force_5p5V").setForceValue(5.5)
                .setVrange(6.0).setIrange(0.001).setIclamp(0.001);



        ISetupDcVI vddqs = ds.addDcVI("VDDQ1_AVI1");
        vddqs.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce50V = vddqs.vforce("vddqs_force_50V").setForceValue(50.0)
                .setVrange(80.0).setIrange(0.05).setIclamp(0.05);


        ISetupDcVI vddqg1 = ds.addDcVI("VDDQ1_AVI2").setConfigOptionHighCurrent();
        vddqg1.setConnect(true).setDisconnect(true);


        ISetupDcVI vddqg2 = ds.addDcVI("VDDQ2_AVI3").setConfigOptionHighCurrent();
        vddqg2.setConnect(true).setDisconnect(true);


        ISetupDcVI vddqg3 = ds.addDcVI("VDDQ2_AVI4").setConfigOptionHighCurrent(); // Need to check the state of instrument
        vddqg3.setConnect(true).setDisconnect(true);


        ISetupDcVI vddqg4 = ds.addDcVI("VDDQ2_AVI5").setConfigOptionHighCurrent();
        vddqg4.setConnect(true).setDisconnect(true);


        ISetupDcVI vddqg5 = ds.addDcVI("VDDQ2_AVI6").setConfigOptionHighCurrent();
        vddqg5.setConnect(true).setDisconnect(true);


        ISetupDcVI vddqg6 = ds.addDcVI("VDDQ1_AVI7").setConfigOptionHighCurrent();
        vddqg6.setConnect(true).setDisconnect(true);


        ISetupDcVI vddqg7 = ds.addDcVI("VDDQ1_AVI8").setConfigOptionHighCurrent();
        vddqg7.setConnect(true).setDisconnect(true);


        ISetupWaveformDc dcWaveformSQPS1 = ds.addWaveformDc("PulseSQPS1").setDcValue(-6)
                .setSamples(200).setSampleRate(100e3);

        ISetupDcVI sqps1 = ds.addDcVI("SQP1_AVI1");                                     // Need to check state of SQM and VSSQ
        sqps1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqps1_Vpulse_Source_Meas = sqps1
                .sourceMeasureWaveform("sqps1_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ1_AVI1").setIrange(4.0);


        ISetupDcVI sqpg1 = ds.addDcVI("SQP1_AVI2");
        sqpg1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg1_Vpulse_Source_Meas = sqpg1
                .sourceMeasureWaveform("sqpg1_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ1_AVI2").setIrange(4.0);


        ISetupDcVI sqpg2 = ds.addDcVI("SQP2_AVI3");
        sqpg2.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg2_Vpulse_Source_Meas = sqpg2
                .sourceMeasureWaveform("sqpg2_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ2_AVI3").setIrange(4.0);


        ISetupDcVI sqpg3 = ds.addDcVI("SQP2_AVI4");
        sqpg3.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg3_Vpulse_Source_Meas = sqpg3
                .sourceMeasureWaveform("sqpg3_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ2_AVI4").setIrange(4.0);


        ISetupDcVI sqpg4 = ds.addDcVI("SQP3_AVI5");
        sqpg4.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg4_Vpulse_Source_Meas = sqpg4
                .sourceMeasureWaveform("sqpg4_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ2_AVI5").setIrange(4.0);


        ISetupDcVI sqpg5 = ds.addDcVI("SQP3_AVI6");
        sqpg5.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg5_Vpulse_Source_Meas = sqpg5
                .sourceMeasureWaveform("sqpg5_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ2_AVI6").setIrange(4.0);


        ISetupDcVI sqpg6 = ds.addDcVI("SQP4_AVI7");
        sqpg6.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg6_Vpulse_Source_Meas = sqpg6
                .sourceMeasureWaveform("sqpg6_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ1_AVI7").setIrange(4.0);


        ISetupDcVI sqpg7 = ds.addDcVI("SQP4_AVI8");
        sqpg7.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg7_Vpulse_Source_Meas = sqpg7
                .sourceMeasureWaveform("sqpg7_Source_Measure").setForceTypeVoltage()
                .setMeasTypeCurrent().setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200)
                .setNeg("VDDQ1_AVI8").setIrange(4.0);


        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        ISetupAction isetCurrForce = iset.iforce("iset_force_1mA").setForceValue(0.001).setVrange(5.75)
                .setVclampHigh(5.5).setVclampLow(0.0);

        ISetupAction iset0mA = iset.iforce("iset_force_0mA").setForceValue(0.0).setVrange(5.75)
                .setVclampHigh(5.5).setVclampLow(0.0);


        // ----------------------------------------------------------------
        // Operating Sequence Execution (Dynamic Call Area)
        // ----------------------------------------------------------------

        ds.sequentialBegin("kqsp");
        {

            // Set background configurations
            ds.actionCall(vddForce5p5V);
            ds.actionCall(vddqForce50V);
            ds.actionCall(isetCurrForce);
            ds.actionCall(armForce5p5V);
            ds.actionCall(lfireForce5p5V);
            ds.actionCall(hfireForce5p5V);


            ds.parallelBegin();{

                    ds.sequentialBegin("seq1");
                    {
                        ds.actionCall(sqps1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq2");
                    {
                        ds.actionCall(sqpg1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq3");
                    {
                        ds.actionCall(sqpg2_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq4");
                    {
                        ds.actionCall(sqpg3_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq5");
                    {
                        ds.actionCall(sqpg4_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq6");
                    {
                        ds.actionCall(sqpg5_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq7");
                    {
                        ds.actionCall(sqpg6_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq8");
                    {
                        ds.actionCall(sqpg7_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
            }

            ds.parallelEnd();

            ds.actionCall(iset0mA);

        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No dynamic parameter updates needed
    }


    @Override
    public void execute() {

        // Run measurement
        measurement.execute();

        IDcVIResults measResults = measurement.dcVI("SQP1_AVI1 + SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8").preserveResults();

        boolean isOffline = context.testProgram().variables().getBoolean("SYS.OFFLINE").get();

//        if (!isOffline) {

            MultiSiteWaveDouble w200_sqps1 = measResults.sourceMeasureWaveform("sqps1_Source_Measure").getWaveform("SQP1_AVI1").getElement(0);
            MultiSiteWaveDouble w200_sqpg1 = measResults.sourceMeasureWaveform("sqpg1_Source_Measure").getWaveform("SQP1_AVI2").getElement(0);
            MultiSiteWaveDouble w200_sqpg2 = measResults.sourceMeasureWaveform("sqpg2_Source_Measure").getWaveform("SQP2_AVI3").getElement(0);
            MultiSiteWaveDouble w200_sqpg3 = measResults.sourceMeasureWaveform("sqpg3_Source_Measure").getWaveform("SQP2_AVI4").getElement(0);
            MultiSiteWaveDouble w200_sqpg4 = measResults.sourceMeasureWaveform("sqpg4_Source_Measure").getWaveform("SQP3_AVI5").getElement(0);
            MultiSiteWaveDouble w200_sqpg5 = measResults.sourceMeasureWaveform("sqpg5_Source_Measure").getWaveform("SQP3_AVI6").getElement(0);
            MultiSiteWaveDouble w200_sqpg6 = measResults.sourceMeasureWaveform("sqpg6_Source_Measure").getWaveform("SQP4_AVI7").getElement(0);
            MultiSiteWaveDouble w200_sqpg7 = measResults.sourceMeasureWaveform("sqpg7_Source_Measure").getWaveform("SQP4_AVI8").getElement(0);


            // Perform calculations across active sites

            MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);
            MultiSiteDouble gain = new MultiSiteDouble(0.0);

            for (int site : context.getActiveSites()) {

                double totalCurrentSite = (Math.abs(w200_sqps1.getValue(125).get(site) + w200_sqps1.getValue(130).get(site) + w200_sqps1.getValue(135).get(site) + w200_sqps1.getValue(140).get(site) + w200_sqps1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqpg1.getValue(125).get(site) + w200_sqpg1.getValue(130).get(site) + w200_sqpg1.getValue(135).get(site) + w200_sqpg1.getValue(140).get(site) + w200_sqpg1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqpg2.getValue(125).get(site) + w200_sqpg2.getValue(130).get(site) + w200_sqpg2.getValue(135).get(site) + w200_sqpg2.getValue(140).get(site) + w200_sqpg2.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg3.getValue(125).get(site) + w200_sqpg3.getValue(130).get(site) + w200_sqpg3.getValue(135).get(site) + w200_sqpg3.getValue(140).get(site) + w200_sqpg3.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg4.getValue(125).get(site) + w200_sqpg4.getValue(130).get(site) + w200_sqpg4.getValue(135).get(site) + w200_sqpg4.getValue(140).get(site) + w200_sqpg4.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg5.getValue(125).get(site) + w200_sqpg5.getValue(130).get(site) + w200_sqpg5.getValue(135).get(site) + w200_sqpg5.getValue(140).get(site) + w200_sqpg5.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg6.getValue(125).get(site) + w200_sqpg6.getValue(130).get(site) + w200_sqpg6.getValue(135).get(site) + w200_sqpg6.getValue(140).get(site) + w200_sqpg6.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg7.getValue(125).get(site) + w200_sqpg7.getValue(130).get(site) + w200_sqpg7.getValue(135).get(site) + w200_sqpg7.getValue(140).get(site) + w200_sqpg7.getValue(145).get(site))/5.0);

                totalCurrent.set(site, totalCurrentSite);

             // Print individual currents

                println("SQP1_AVI1 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqps1.getValue(125).get(site) + w200_sqps1.getValue(130).get(site) + w200_sqps1.getValue(135).get(site) + w200_sqps1.getValue(140).get(site) + w200_sqps1.getValue(145).get(site))/5.0) + " A");
                println("SQP1_AVI2 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg1.getValue(125).get(site) + w200_sqpg1.getValue(130).get(site) + w200_sqpg1.getValue(135).get(site) + w200_sqpg1.getValue(140).get(site) + w200_sqpg1.getValue(145).get(site))/5.0) + " A");
                println("SQP2_AVI3 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg2.getValue(125).get(site) + w200_sqpg2.getValue(130).get(site) + w200_sqpg2.getValue(135).get(site) + w200_sqpg2.getValue(140).get(site) + w200_sqpg2.getValue(145).get(site))/5.0) + " A");
                println("SQP2_AVI4 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg3.getValue(125).get(site) + w200_sqpg3.getValue(130).get(site) + w200_sqpg3.getValue(135).get(site) + w200_sqpg3.getValue(140).get(site) + w200_sqpg3.getValue(145).get(site))/5.0) + " A");
                println("SQP3_AVI5 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg4.getValue(125).get(site) + w200_sqpg4.getValue(130).get(site) + w200_sqpg4.getValue(135).get(site) + w200_sqpg4.getValue(140).get(site) + w200_sqpg4.getValue(145).get(site))/5.0) + " A");
                println("SQP3_AVI6 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg5.getValue(125).get(site) + w200_sqpg5.getValue(130).get(site) + w200_sqpg5.getValue(135).get(site) + w200_sqpg5.getValue(140).get(site) + w200_sqpg5.getValue(145).get(site))/5.0) + " A");
                println("SQP4_AVI7 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg6.getValue(125).get(site) + w200_sqpg6.getValue(130).get(site) + w200_sqpg6.getValue(135).get(site) + w200_sqpg6.getValue(140).get(site) + w200_sqpg6.getValue(145).get(site))/5.0) + " A");
                println("SQP4_AVI8 Absolute Average Current = " + "at site :" + site + " is :" + (Math.abs(w200_sqpg7.getValue(125).get(site) + w200_sqpg7.getValue(130).get(site) + w200_sqpg7.getValue(135).get(site) + w200_sqpg7.getValue(140).get(site) + w200_sqpg7.getValue(145).get(site))/5.0) + " A");

            }

          println("--------------------------------------");
          println("Total Measured Current = " + totalCurrent + " A");

          MultiSiteDouble isetCurrent = new MultiSiteDouble(0.001); // 1mA

          println("Forced ISET Current    = " + isetCurrent + " A");

          gain = totalCurrent.divide(isetCurrent);

          println("--------------------------------------");
          println("Calculated Gain KQSP   = " + gain);

          ptdDC.evaluate(gain);

//    }
    }
}

