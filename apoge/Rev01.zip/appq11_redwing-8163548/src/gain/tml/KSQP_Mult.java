package gain.tml;

import java.util.ArrayList;
import java.util.List;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupAction;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupWaveformDc;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * RON_VARYING_LOAD - By ///--MonishKumar--//
 *
 * This test method measures the ON resistance (RON) of the power switch
 * under three different current pulsing loads: 200mA, 500mA, and Full Load (FL).
 *
 * The calculations average the voltages on the 8 VIN pins relative to VOUT pins.
 */
public class KSQP_Mult extends TestMethod {

    public IMeasurement measurement;
    public IDeviceSetup deviceSetup;
    public IParametricTestDescriptor ptdDC;
    public Double lowLimit=0.0;
    public Double highLimit=0.0;

//    public IParametricTestDescriptor ptdDC2;
//    public IParametricTestDescriptor ptdDC3;
//    public IParametricTestDescriptor ptdDC4;

    public List<Double> isetValues = new ArrayList<>();
    public List<Double> sqpValues = new ArrayList<>();

//    public double[] isetValues = { 100e-6, 200e-6, 600e-6, 1e-3 };
//    public double[] sqpValues = { -2, -2, -4, -6 };

    public MultiSiteDoubleArray totalCurrent = new MultiSiteDoubleArray(1,0.0);
    public MultiSiteDoubleArray gain = new MultiSiteDoubleArray(1,0.0);

    @Override
    public void setup() {



        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        deviceSetup = ds;


        // ----------------------------------------------------------------
        // Instrument Actions and Measurement Setup Declarations
        // ----------------------------------------------------------------

        for (int i = 0; i < isetValues.size(); i++) {

        // Configure VDD supply (AVI/DcVI) connect/disconnect settings and actions
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
//        .setVforce(voltageForce)           // Force voltage (V)
        .setVrange(7.0)           // Voltage range (V)
        .setIrange(0.2);       // Current range (A)
//        .setIclamp(currentClamp);

        ISetupDcVI.IVforce vddForce5p5V = vdd.vforce("VDD_force_5p5V_"+ i)
                .setForceValue(5.5)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForce5p5V = arm.vforce("arm_force_5p5V_"+ i)
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce5p5V = lfire.vforce("lfire_force_5p5V_"+i)
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce5p5V = hfire.vforce("hfire_force_5p5V_"+i)
                .setForceValue(5.5)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        ISetupDcVI vddqs = ds.addDcVI("VDDQ1_AVI1");
        vddqs.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce50V = vddqs.vforce("vddqs_force_50V_"+i)
                .setForceValue(50.0)
                .setVrange(60.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI VDDqg1 = ds.addDcVI("VDDQ1_AVI2 ").setConfigOptionHighCurrent();
        VDDqg1.setConnect(true).setDisconnect(true);
        ISetupDcVI VDDqg2 = ds.addDcVI("VDDQ2_AVI3 ").setConfigOptionHighCurrent();
        VDDqg2.setConnect(true).setDisconnect(true);
        ISetupDcVI VDDqg3 = ds.addDcVI("VDDQ2_AVI4 ").setConfigOptionHighCurrent(); // Need to check the state of instrument
        VDDqg3.setConnect(true).setDisconnect(true);
        ISetupDcVI VDDqg4 = ds.addDcVI("VDDQ2_AVI5 ").setConfigOptionHighCurrent();
        VDDqg4.setConnect(true).setDisconnect(true);
        ISetupDcVI VDDqg5 = ds.addDcVI("VDDQ2_AVI6 ").setConfigOptionHighCurrent();
        VDDqg5.setConnect(true).setDisconnect(true);
        ISetupDcVI VDDqg6 = ds.addDcVI("VDDQ1_AVI7 ").setConfigOptionHighCurrent(); // Need to check the state of instrument
        VDDqg6.setConnect(true).setDisconnect(true);
        ISetupDcVI VDDqg7 = ds.addDcVI("VDDQ1_AVI8 ").setConfigOptionHighCurrent(); // Need to check the state of instrument
        VDDqg7.setConnect(true).setDisconnect(true);
//        VDDqg.level().setIrange(4.0).setIclamp(4.0);

        ISetupWaveformDc dcWaveformSQPS1 = ds.addWaveformDc("PulseSQPS1"+"_N" + (int)Math.abs(sqpValues.get(i)) + "V_" + i).setDcValue(sqpValues.get(i)).setSamples(200).setSampleRate(100e3);

        ISetupDcVI sqps1 = ds.addDcVI("SQP1_AVI1"); // Need to check state of SQM and VDDQ
        sqps1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqps1_Vpulse_Source_Meas =
                sqps1.sourceMeasureWaveform("sqps1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ1_AVI1").setIrange(4.0);

//        ISetupDcVI.IVforce sqpForce44V = sqps1.vforce("sqps_force_44V")
//                .setForceValue(44.0)
//                .setVrange(60.0)
//                .setIrange(0.05)
//                .setIclamp(0.05);
//        ISetupDcVI.IImeas sqps1Meas = sqps1.imeas("sqps_meas").setIrange(0.2);

        ISetupDcVI sqpg1 = ds.addDcVI("SQP1_AVI2 ");
        sqpg1.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();
        ISetupDcVI.ISourceMeasureWaveform sqpg1_Vpulse_Source_Meas =
                sqpg1.sourceMeasureWaveform("sqpg1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ1_AVI2").setIrange(4.0);


////        sqpg.level().setIrange(4.0).setIclamp(4.0);
//        sqpg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU1 = sqpg1.imeas("meas_HCU1")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VDDQ1_AVI2");

        ISetupDcVI sqpg2 = ds.addDcVI("SQP2_AVI3 ");
        sqpg2.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();
        ISetupDcVI.ISourceMeasureWaveform sqpg2_Vpulse_Source_Meas =
                sqpg2.sourceMeasureWaveform("sqpg2_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ2_AVI3").setIrange(4.0);
////        sqpg.level().setIrange(4.0).setIclamp(4.0);
//        sqpg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU2 = sqpg2.imeas("meas_HCU2")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VDDQ2_AVI3");
        ISetupDcVI sqpg3 = ds.addDcVI("SQP2_AVI4 ");
        sqpg3.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg3_Vpulse_Source_Meas =
                sqpg3.sourceMeasureWaveform("sqpg3_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ2_AVI4").setIrange(4.0);
////        sqpg.level().setIrange(4.0).setIclamp(4.0);
//        sqpg.meas("meas_HCU").current().setEnabled(true).setRange(4.0);
//        ISetupDcVI.IImeas iMeas_HCU3 = sqpg3.imeas("meas_HCU3")
////                .setWaitTime(500.0e-6)           // 500 µs wait
////                .setAveragingTime(128.0e-6)      // 128 samples
//                .setIrange(4.0)                // 50 mA range
//                .setNeg("VDDQ2_AVI4");
        ISetupDcVI sqpg4 = ds.addDcVI("SQP3_AVI5 ");
        sqpg4.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg4_Vpulse_Source_Meas =
                sqpg4.sourceMeasureWaveform("sqpg4_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ2_AVI5").setIrange(4.0);

        ISetupDcVI sqpg5 = ds.addDcVI("SQP3_AVI6 ");
        sqpg5.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg5_Vpulse_Source_Meas =
                sqpg5.sourceMeasureWaveform("sqpg5_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ2_AVI6").setIrange(4.0);

        ISetupDcVI sqpg6 = ds.addDcVI("SQP4_AVI7 ");
        sqpg6.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg6_Vpulse_Source_Meas =
                sqpg6.sourceMeasureWaveform("sqpg6_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ1_AVI7").setIrange(4.0);

        ISetupDcVI sqpg7 = ds.addDcVI("SQP4_AVI8 ");
        sqpg7.setConnect(true).setDisconnect(true).setConfigOptionHighCurrent();

        ISetupDcVI.ISourceMeasureWaveform sqpg7_Vpulse_Source_Meas =
                sqpg7.sourceMeasureWaveform("sqpg7_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).setForceTypeVoltage().setMeasTypeCurrent()
                .setWaveform(dcWaveformSQPS1).setIclamp(4.0).setSamples(200).setNeg("VDDQ1_AVI8").setIrange(4.0);
//        ISetupDcVI sqpg = ds.addDcVI("SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4");
//        sqpg.setConfigOptionHighCurrent().setConnectModeStandard();
//        sqpg.setDisconnect(true);
//        ISetupAction sqpgDisconnect = sqpg.disconnect();
//
//        IMeasureWaveform sqpgMeasHCU = sqpg.measureWaveform("meas_HCU")
//                .setMeasTypeCurrent()
//                .setIrange(4.0).setSamples(256).setSampleRate(100000).setNeg("VDDQ1_AVI2 ");

        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        ISetupAction isetCurrForce = iset.iforce("iset_force_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA")
                .setForceValue(isetValues.get(i))
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);
        ISetupAction iset0mA = iset.iforce("iset_force_0mA")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setVclampHigh(5.5)
                .setVclampLow(0.0);


        // ----------------------------------------------------------------
        // Operating Sequence Execution (Dynamic Call Area)
        // ----------------------------------------------------------------
        ds.parallelBegin("kqsp_seq_"+i);{
        ds.sequentialBegin("kqsp_seq_"+i);
        {

            // Set background configurations
            ds.actionCall(vddForce5p5V);
            ds.actionCall(vddqForce50V);
            ds.actionCall(isetCurrForce);
            ds.actionCall(armForce5p5V);
            ds.actionCall(lfireForce5p5V);
            ds.actionCall(hfireForce5p5V);




            ds.parallelBegin();




                    ds.sequentialBegin("seq1");
                    {
                        ds.actionCall(sqps1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq2");
                    {
                        ds.actionCall(sqpg1_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq3");
                    {
                        ds.actionCall(sqpg2_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

                    ds.sequentialBegin("seq4");
                    {
                        ds.actionCall(sqpg3_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq5");
                    {
                        ds.actionCall(sqpg4_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq6");
                    {
                        ds.actionCall(sqpg5_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq7");
                    {
                        ds.actionCall(sqpg6_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();
                    ds.sequentialBegin("seq8");
                    {
                        ds.actionCall(sqpg7_Vpulse_Source_Meas);
                    }
                    ds.sequentialEnd();

            ds.parallelEnd();

            ds.actionCall(iset0mA);

        }
        ds.sequentialEnd();

        }
        ds.parallelEnd();}

        measurement.setSetups(ds);

    }

    @Override
    public void update() {
        // No dynamic parameter updates needed
    }


    @Override
    public void execute() {

        // Run measurement
        measurement.execute();

        IDcVIResults measResults = measurement.dcVI("SQP1_AVI1 + SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8").preserveResults();


        boolean isOffline = context.testProgram().variables().getBoolean("SYS.OFFLINE").get();
//        println("The size of iset values is "+isetValues.size());
//
////        if (!isOffline) {
            // Retrieve differential VIN waveforms (each VIN measures VIN - paired VOUT via setNeg)
            // VIN1_Wave_200mA gives VIN1 - VOUT6, VIN2_Wave_200mA gives VIN2 - VOUT5, etc."sqpg4_Source_Measure_"+i
        for (int i = 0; i < isetValues.size(); i++) {

            MultiSiteWaveDouble w200_sqps1 = measResults.sourceMeasureWaveform("sqps1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP1_AVI1").getElement(0);
            MultiSiteWaveDouble w200_sqpg1 = measResults.sourceMeasureWaveform("sqpg1_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP1_AVI2").getElement(0);
            MultiSiteWaveDouble w200_sqpg2 = measResults.sourceMeasureWaveform("sqpg2_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP2_AVI3").getElement(0);
            MultiSiteWaveDouble w200_sqpg3 = measResults.sourceMeasureWaveform("sqpg3_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP2_AVI4").getElement(0);
            MultiSiteWaveDouble w200_sqpg4 = measResults.sourceMeasureWaveform("sqpg4_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP3_AVI5").getElement(0);
            MultiSiteWaveDouble w200_sqpg5 = measResults.sourceMeasureWaveform("sqpg5_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP3_AVI6").getElement(0);
            MultiSiteWaveDouble w200_sqpg6 = measResults.sourceMeasureWaveform("sqpg6_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP4_AVI7").getElement(0);
            MultiSiteWaveDouble w200_sqpg7 = measResults.sourceMeasureWaveform("sqpg7_Source_Measure_"+ (int)Math.abs(isetValues.get(i)*1000000) + "uA_"+i).getWaveform("SQP4_AVI8").getElement(0);



            // Perform calculations across active sites




            for (int site : context.getActiveSites()) {

                double totalCurrentSite = (Math.abs(w200_sqps1.getValue(125).get(site) + w200_sqps1.getValue(130).get(site) + w200_sqps1.getValue(135).get(site) + w200_sqps1.getValue(140).get(site) + w200_sqps1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqpg1.getValue(125).get(site) + w200_sqpg1.getValue(130).get(site) + w200_sqpg1.getValue(135).get(site) + w200_sqpg1.getValue(140).get(site) + w200_sqpg1.getValue(145).get(site))/5.0)

                             + (Math.abs(w200_sqpg2.getValue(125).get(site) + w200_sqpg2.getValue(130).get(site) + w200_sqpg2.getValue(135).get(site) + w200_sqpg2.getValue(140).get(site) + w200_sqpg2.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg3.getValue(125).get(site) + w200_sqpg3.getValue(130).get(site) + w200_sqpg3.getValue(135).get(site) + w200_sqpg3.getValue(140).get(site) + w200_sqpg3.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg4.getValue(125).get(site) + w200_sqpg4.getValue(130).get(site) + w200_sqpg4.getValue(135).get(site) + w200_sqpg4.getValue(140).get(site) + w200_sqpg4.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg5.getValue(125).get(site) + w200_sqpg5.getValue(130).get(site) + w200_sqpg5.getValue(135).get(site) + w200_sqpg5.getValue(140).get(site) + w200_sqpg5.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg6.getValue(125).get(site) + w200_sqpg6.getValue(130).get(site) + w200_sqpg6.getValue(135).get(site) + w200_sqpg6.getValue(140).get(site) + w200_sqpg6.getValue(145).get(site))/5.0)
                             + (Math.abs(w200_sqpg7.getValue(125).get(site) + w200_sqpg7.getValue(130).get(site) + w200_sqpg7.getValue(135).get(site) + w200_sqpg7.getValue(140).get(site) + w200_sqpg7.getValue(145).get(site))/5.0);
                totalCurrent.setElement(site,i, totalCurrentSite);

             // Print individual currents

                println("SQP1_AVI1 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqps1.getValue(125).get(site) + w200_sqps1.getValue(130).get(site) + w200_sqps1.getValue(135).get(site) + w200_sqps1.getValue(140).get(site) + w200_sqps1.getValue(145).get(site))/5.0) + " A");
                println("SQP1_AVI2 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg1.getValue(125).get(site) + w200_sqpg1.getValue(130).get(site) + w200_sqpg1.getValue(135).get(site) + w200_sqpg1.getValue(140).get(site) + w200_sqpg1.getValue(145).get(site))/5.0) + " A");
                println("SQP2_AVI3 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg2.getValue(125).get(site) + w200_sqpg2.getValue(130).get(site) + w200_sqpg2.getValue(135).get(site) + w200_sqpg2.getValue(140).get(site) + w200_sqpg2.getValue(145).get(site))/5.0) + " A");
                println("SQP2_AVI4 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg3.getValue(125).get(site) + w200_sqpg3.getValue(130).get(site) + w200_sqpg3.getValue(135).get(site) + w200_sqpg3.getValue(140).get(site) + w200_sqpg3.getValue(145).get(site))/5.0) + " A");
                println("SQP3_AVI5 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg4.getValue(125).get(site) + w200_sqpg4.getValue(130).get(site) + w200_sqpg4.getValue(135).get(site) + w200_sqpg4.getValue(140).get(site) + w200_sqpg4.getValue(145).get(site))/5.0) + " A");
                println("SQP3_AVI6 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg5.getValue(125).get(site) + w200_sqpg5.getValue(130).get(site) + w200_sqpg5.getValue(135).get(site) + w200_sqpg5.getValue(140).get(site) + w200_sqpg5.getValue(145).get(site))/5.0) + " A");
                println("SQP4_AVI7 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg6.getValue(125).get(site) + w200_sqpg6.getValue(130).get(site) + w200_sqpg6.getValue(135).get(site) + w200_sqpg6.getValue(140).get(site) + w200_sqpg6.getValue(145).get(site))/5.0) + " A");
                println("SQP4_AVI8 Absolute Average Current  " + "at site :" + site + " and at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA"+" is :" + (Math.abs(w200_sqpg7.getValue(125).get(site) + w200_sqpg7.getValue(130).get(site) + w200_sqpg7.getValue(135).get(site) + w200_sqpg7.getValue(140).get(site) + w200_sqpg7.getValue(145).get(site))/5.0) + " A");

            }





            println("--------------------------------------");
          println("Total Measured Current = "+ "at iset current "+ (int)Math.abs(isetValues.get(i)*1000000) + "uA is :"+ totalCurrent + " A");

//          MultiSiteDouble isetCurrent = new MultiSiteDouble(0.001); // 1mA

          println("Forced ISET Current    = " + isetValues.get(i)+ " A");

          gain.setElement(i,(totalCurrent.getElement(i)).divide(isetValues.get(i)));

          println("--------------------------------------");
          println("Calculated Gain KQSP   = " + gain);






//    }

        }
          ptdDC.evaluate(gain,0);
//        ptdDC2.evaluate(gain,1);
//        ptdDC3.evaluate(gain,2);
//        ptdDC4.evaluate(gain,3);

    }
}


