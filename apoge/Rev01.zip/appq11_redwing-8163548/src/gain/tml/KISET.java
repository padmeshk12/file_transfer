package gain.tml;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : KISET Gain Test
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * 1. Close relays K4 (ISET to PS1600) and K5 (VSS to GND) with 20ms debounce settling time.
 * 2. Force VDDQ to 12 V on VDDQGroup.
 * 3. Sweep VDD and ARM across VDDValues, measure ISET voltage, calculate
 *    ISET/VDD gain, and evaluate results against test limits.
 * 4. Safe power-down: ramp ARM, VDD, and VDDQ to 0 V before opening relays.
 */
public class KISET extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdDC;

    public List<Double> VDDValues = new ArrayList<>();
    public double vddqVoltage = 12.0;

    @Override
    public void setup() {
        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        // ---------------------------------------------------------
        // Relay Configuration: K4 (ISET to PS1600) and K5 (VSS to GND)
        // ---------------------------------------------------------
        ISetupUtility isetRelay = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState k4_on = isetRelay.setState("k4_on").setValue(1).setSettlingTime(0.02);
        ISetupUtility.ISetState k4_off = isetRelay.setState("k4_off").setValue(0).setSettlingTime(0.01);

        ISetupUtility vssRelay = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState k5_on = vssRelay.setState("k5_on").setValue(1).setSettlingTime(0.02);
        ISetupUtility.ISetState k5_off = vssRelay.setState("k5_off").setValue(0).setSettlingTime(0.01);

        // Explicitly isolate/disconnect unused relays (resistors on ISET must remain open)
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        // Configure VDDQ supply (VDDQGroup: 8 ganged AVI channels)
        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce forceVddq12V = vddq.vforce("force_vddq_12V")
                .setForceValue(vddqVoltage)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        ISetupDcVI.IVforce forceVddq0V = vddq.vforce("force_vddq_0V")
                .setForceValue(0.0)
                .setVrange(16.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        // Configure VDD supply (DPS128)
        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.05);

        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.05)
                .setIclamp(0.05);

        // Configure ARM control pin
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce forceArm0V = arm.vforce("force_arm_0V")
                .setForceValue(0.0)
                .setVrange(6.0)
                .setIrange(0.001)
                .setIclamp(0.001);

        // Configure ISET measuring channel in High-Impedance mode
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);

        // Dynamic execution sequence
        ds.sequentialBegin("kiset_execution_sequence");
        {
            // 1. Close relays K4 and K5 with 20ms mechanical debounce settling time
            ds.actionCall(k4_on);
            ds.actionCall(k5_on);
            ds.waitCall(0.020);

            // 2. Power up VDDQ to 12V
            ds.actionCall(forceVddq12V);
            ds.waitCall(0.010);

            // 3. Perform measurements for each VDD condition
            for (int index = 0; index < VDDValues.size(); index++) {
                double vddVoltage = VDDValues.get(index);
                String voltageLabel = String.valueOf(vddVoltage).replace(".", "p") + "V";

                ISetupDcVI.IVforce forceVdd = vdd.vforce("force_vdd_" + voltageLabel)
                        .setForceValue(vddVoltage)
                        .setIrange(0.05)
                        .setIclamp(0.05);

                ISetupDcVI.IVforce forceArm = arm.vforce("force_arm_" + voltageLabel)
                        .setForceValue(vddVoltage)
                        .setVrange(6.0)
                        .setIrange(0.001)
                        .setIclamp(0.001);

                ISetupDcVI.IVmeas measureIsetVoltage = iset.vmeas("measure_iset_" + voltageLabel)
                        .setVrange(6.0);

                ds.actionCall(forceVdd);
                ds.actionCall(forceArm);
                ds.waitCall(0.020);
                ds.actionCall(measureIsetVoltage);
            }

            // 4. Safe power-down sequence:
            // a. Drop input control pin ARM and VDD supply to 0V
            ds.actionCall(forceArm0V);
            ds.actionCall(forceVdd0V);

            // b. Drop VDDQ supply to 0V (on the same 16V range to avoid range-switch clamp)
            ds.actionCall(forceVddq0V);
            ds.waitCall(0.020);

            // c. Release relays while rails are at 0V
            ds.actionCall(k4_off);
            ds.actionCall(k5_off);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        measurement.execute();

        IDcVIResults isetResults = measurement.dcVI("ISET_PS").preserveResults();
        Map<String, MultiSiteDoubleArray> isetVoltageResults = isetResults.vmeas("").getVoltage();

        MultiSiteDouble gainSum = new MultiSiteDouble(0.0);

        int testNumber = ptdDC.getTestNumber();
        int testNumberFromTestTable = testNumber;

        println("\n<------- KISET Gain Test START ------->\n");

        for (int index = 0; index < VDDValues.size(); index++) {
            double vddVoltage = VDDValues.get(index);

            MultiSiteDouble isetVoltage = isetVoltageResults.get("ISET_PS").getElement(index);
            MultiSiteDouble gainAtVdd = new MultiSiteDouble(0.0);

            for (int site : context.getActiveSites()) {
                double gainValue = isetVoltage.get(site) / vddVoltage;
                gainAtVdd.set(site, gainValue);

                println("Site " + site
                        + " - VDD: " + vddVoltage + " V"
                        + " - VDDQ: " + vddqVoltage + " V"
                        + " - ISET: " + isetVoltage.get(site) + " V"
                        + " - Gain: " + gainValue);
            }

            gainSum = gainSum.add(gainAtVdd);

            ptdDC.setTestText("GAIN_KISET__VDD=" + vddVoltage + "V_ARM=" + vddVoltage + "V_VDDQ=" + (int) vddqVoltage + "V")
                    .setTestNumber(testNumber);
            ptdDC.evaluate(gainAtVdd);

            println("Gain at VDD = " + vddVoltage + " V: " + gainAtVdd );
            testNumber += 10;
        }

        MultiSiteDouble averageGain = gainSum.divide(VDDValues.size());

        ptdDC.setTestText("GAIN_KISET_AVG__VDD=3Vto5.5V_ARM=3Vto5.5V_VDDQ=" + (int) vddqVoltage + "V")
                .setTestNumber(testNumber);
        ptdDC.evaluate(averageGain);

        println("\nAverage Gain: " + averageGain );

        ptdDC.setTestText("GAIN_KISET__VDD=3V_ARM=3V_VDDQ=12V")
                .setTestNumber(testNumberFromTestTable);

        println("\n<------- KISET Gain Test END ------->\n");
    }
}
