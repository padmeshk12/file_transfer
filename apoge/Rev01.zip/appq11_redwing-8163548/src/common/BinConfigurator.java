package common;

import xoc.dta.TestMethod;
import xoc.dta.binning.SoftBin;

public class BinConfigurator extends TestMethod {

    @Override
    public void execute() {
        // Replace 5 with the actual Software Bin ID from your test table
        int binId = 5;

        try {
            SoftBin softBin = context.binning().binTable().getSoftBin(binId);




//            // Set the stop behavior to STOP
//            softBin.setStopBehavior(StopBehavior.STOP);
//
//            // Optional: Ensure it is not suppressible by global overrides
//            softBin.setStopSuppressible(false);

            println("Bin " + binId + " configured to STOP execution.");
        } catch (Exception e) {
            println("Error configuring bin " + binId + ": " + e.getMessage());
        }
    }

}


