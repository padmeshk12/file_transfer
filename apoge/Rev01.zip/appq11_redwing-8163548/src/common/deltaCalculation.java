package common;

import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class deltaCalculation extends TestMethod {


    public IParametricTestDescriptor ptdDC;

    @Override
    public void setup() {
        // TODO Auto-generated method stub


    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

        int testNumber = ptdDC.getTestNumber();

        MultiSiteDouble IQ_VDD_SD_PreStress = context.testProgram().variables().getDouble("IQ_VDD_SD_PreStress");
        MultiSiteDouble IQ_VDD_SD_PostStress = context.testProgram().variables().getDouble("IQ_VDD_SD_PostStress");

        MultiSiteDouble delta_IQ_VDD_SD = IQ_VDD_SD_PostStress.subtract(IQ_VDD_SD_PreStress);

        ptdDC.setTestText("DELTA_IQ_VDD_SD")
                .setTestNumber(testNumber);

        testNumber+=10;

        ptdDC.evaluate(delta_IQ_VDD_SD);

        MultiSiteDouble IQ_VDDQ_SD_PreStress = context.testProgram().variables().getDouble("IQ_VDDQ_SD_PreStress");
        MultiSiteDouble IQ_VDDQ_SD_PostStress = context.testProgram().variables().getDouble("IQ_VDDQ_SD_PostStress");

        MultiSiteDouble delta_IQ_VDDQ_SD = IQ_VDDQ_SD_PostStress.subtract(IQ_VDDQ_SD_PreStress);

        ptdDC.setTestText("DELTA_IQ_VDDQ_SD")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IQ_VDDQ_SD);

        testNumber+=10;

        MultiSiteDouble IQ_VDD_PreStressIset100uA = context.testProgram().variables().getDouble("IQ_VDD_PreStressIset100uA");
        MultiSiteDouble IQ_VDD_PostStressIset100uA = context.testProgram().variables().getDouble("IQ_VDD_PostStressIset100uA");

        MultiSiteDouble delta_IQ_VDD_ISET100uA = IQ_VDD_PostStressIset100uA.subtract(IQ_VDD_PreStressIset100uA);

        ptdDC.setTestText("DELTA_IQ_VDD_ISET100uA")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IQ_VDD_ISET100uA);

        testNumber+=10;

        MultiSiteDouble IQ_VDD_PreStressIset1mA = context.testProgram().variables().getDouble("IQ_VDD_PreStressIset1mA");
        MultiSiteDouble IQ_VDD_PostStressIset1mA = context.testProgram().variables().getDouble("IQ_VDD_PostStressIset1mA");

        MultiSiteDouble delta_IQ_VDD_ISET1mA = IQ_VDD_PostStressIset1mA.subtract(IQ_VDD_PreStressIset1mA);

        ptdDC.setTestText("DELTA_IQ_VDD_ISET1mA")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IQ_VDD_ISET1mA);

        testNumber+=10;

        MultiSiteDouble IQ_VDDQ_PreStressIset100uA = context.testProgram().variables().getDouble("IQ_VDDQ_PreStressIset100uA");
        MultiSiteDouble IQ_VDDQ_PostStressIset100uA = context.testProgram().variables().getDouble("IQ_VDDQ_PostStressIset100uA");

        MultiSiteDouble delta_IQ_VDDQ_ISET100uA = IQ_VDDQ_PostStressIset100uA.subtract(IQ_VDDQ_PreStressIset100uA);

        ptdDC.setTestText("DELTA_IQ_VDDQ_ISET100uA")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IQ_VDDQ_ISET100uA);

        testNumber+=10;

        MultiSiteDouble IQ_VDDQ_PreStressIset1mA = context.testProgram().variables().getDouble("IQ_VDDQ_PreStressIset1mA");
        MultiSiteDouble IQ_VDDQ_PostStressIset1mA = context.testProgram().variables().getDouble("IQ_VDDQ_PostStressIset1mA");

        MultiSiteDouble delta_IQ_VDDQ_ISET1mA = IQ_VDDQ_PostStressIset1mA.subtract(IQ_VDDQ_PreStressIset1mA);

        ptdDC.setTestText("DELTA_IQ_VDDQ_ISET1mA")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IQ_VDDQ_ISET1mA);

        testNumber+=10;

        MultiSiteDouble IL_SQM_PreStress = context.testProgram().variables().getDouble("IL_SQM_PreStress");
        MultiSiteDouble IL_SQM_PostStress = context.testProgram().variables().getDouble("IL_SQM_PostStress");

        MultiSiteDouble delta_IL_SQM = IL_SQM_PostStress.subtract(IL_SQM_PreStress);

        ptdDC.setTestText("DELTA_IL_SQM")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IL_SQM);

        testNumber+=10;

        MultiSiteDouble IL_SQP_PreStress = context.testProgram().variables().getDouble("IL_SQP_PreStress");
        MultiSiteDouble IL_SQP_PostStress = context.testProgram().variables().getDouble("IL_SQP_PostStress");

        MultiSiteDouble delta_IL_SQP = IL_SQP_PostStress.subtract(IL_SQP_PreStress);

        ptdDC.setTestText("DELTA_IL_SQP")
                .setTestNumber(testNumber);

        ptdDC.evaluate(delta_IL_SQP);

        testNumber+=10;

    }

}
