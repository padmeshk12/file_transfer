package common;

import xoc.dta.TestMethod;
import xoc.dta.alarm.AlarmType;
import xoc.dta.alarm.IAlarms;
import xoc.dta.measurement.IMeasurement;

public class disableAlarm extends TestMethod {

    public IMeasurement measurement;

    @Override
    public void setup() {
        // TODO Auto-generated method stub




            IAlarms alarms = context.alarms();

            for (AlarmType type : AlarmType.values()) {
                try {
                    alarms.configuration(type)
                          .setForceFail(false)        // Do not force test failure
                          .setBinningEnabled(false);  // Do not assign alarm fail bin
                } catch (Exception e) {
                    // Some mandatory/hardware alarms may not allow certain modifications
                }
            }
        }




    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

    }

}
