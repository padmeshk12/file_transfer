package tsSettlingTime.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupDigInOut;
import xoc.dsa.ISetupPattern;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWavetable.DriveAction;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.resultaccess.datatypes.MultiSiteTmuSamples;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : ISET Settling Time (Test Plan Section 6.8)
 * Author     : Seelam Rajeev Reddy / Monish
 *
 * Test Procedure (Test Plan 6.8):
 * 1. Power up device with VDD and VDDQ in normal range: VDD = 3.3V, VDDQ = 12V.
 * 2. Set ARM, LFIRE, and HFIRE low (0V).
 * 3. Apply 4k-ohm (0.1%) resistor between ISET and VSS (Relays K5, K4, K2 = 1).
 * 4. Toggle ARM high (5.5V).
 * 5. Wait 1 ms.
 * 6. Measure the voltage on ISET and datalog as VISET_Stable (Test ID 23000, ptdDC).
 * 7. Toggle ARM low (0V) and wait 1 ms.
 * 8. Toggle ARM high (5.5V) and measure the time until the voltage on ISET settles
 *    to +/-1% of VISET_Stable. Datalog the time as the ISET settling time (Test ID 23010, ptdTime).
 *
 * Structure:
 * - Measurement 1: Steps 1 - 6 (Measures VISET_Stable).
 * - Measurement 2: Steps 7 - 8 (Dynamically sets TMU threshold to SETTLING_THRESHOLD_RATIO of VISET_Stable and measures settling time via TMU).
 */
public class tsSettling_dual_tmu extends TestMethod {

    private static final int TMU_SAMPLES = 1;
    private static final int TMU_EXPECTED_EVENT_RATE = 1000;
    private static final double SETTLING_THRESHOLD_RATIO = 0.95; // Within 5% of final value per Datasheet condition for 100 us max limit

    public IMeasurement measurement1;
    public IMeasurement measurement2;

    public IParametricTestDescriptor ptdDC;
    public IParametricTestDescriptor ptdTime;

    @Override
    public void setup() {
        // =========================================================================
        // Measurement 1: Measure VISET_Stable (Test Plan Steps 1 - 6)
        // =========================================================================
        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(false);
        vdd.level().setVrange(7.0).setIrange(0.025);

        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V").setForceValue(5.5).setIrange(0.025).setIclamp(0.025);

        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(false);

        ISetupDcVI.IVforce forceVddq12V = vddq.vforce("force_vddq_12V").setForceValue(12.0).setVrange(30.0).setIrange(0.05).setIclamp(0.05);

        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(false);

        ISetupDcVI.IVforce forceLfireHfireTo0V = lfireHfire.vforce("force_lfire_hfire_0V").setForceValue(0.0).setVrange(6.0).setIrange(0.001).setIclamp(0.001);

        // Relays for Measurement 1 (ds)
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_turnon = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_turnon = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_utility_0 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_utility_1 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_1").setValue(1).setSettlingTime(0.02);

        // ARM_PS setup: force 0V initially, then step to 5.5V
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce forceArm0V = arm.vforce("force_arm_0V").setForceValue(0.0).setVrange(5.75).setIrange(0.025).setIclamp(0.025);
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V").setForceValue(5.5).setVrange(5.75).setIrange(0.025).setIclamp(0.025);

        // ISET_PS setup: High-Z connect, measure stable DC voltage across 4k resistor
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);
        ISetupDcVI.IVmeas measureIsetStableVoltage = iset.vmeas("measure_iset_stable_voltage").setVrange(5.75);

        ds.sequentialBegin("measure_iset_stable_voltage_seq");
        {
            // Step 3: Apply 4k-ohm resistor between ISET and VSS (Relays on)
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.actionCall(K2_ISET_R4K_utility_1);
            ds.waitCall(0.020);

            // Step 1: Power up device with VDD = 5.5V, VDDQ = 12V
            ds.actionCall(forceVdd5p5V);
            ds.actionCall(forceVddq12V);

            // Step 2: Set ARM, LFIRE and HFIRE low
            ds.actionCall(forceLfireHfireTo0V);
            ds.actionCall(forceArm0V);
            ds.waitCall(0.010);

            // Step 4 & 5: Toggle ARM high (5.5V) and wait 1 ms
            ds.actionCall(forceArm5p5V);
            ds.waitCall(0.001);

            // Step 6: Measure the voltage on ISET and datalog as VISET_Stable
            ds.actionCall(measureIsetStableVoltage);

            // Step 7: Toggle ARM low and wait 1 ms
            ds.actionCall(forceArm0V);
            ds.waitCall(0.001);
        }
        ds.sequentialEnd();

        // =========================================================================
        // Measurement 2: Measure Settling Time to within 1% of VISET_Stable (Test Plan Steps 7 - 8)
        // =========================================================================
        IDeviceSetup ds1 = DeviceSetupFactory.createInstance();
        ds1.importSpec("common.pinGroups");

        // Maintain power supplies actively for Measurement 2 and disconnect at shutdown
        ISetupDcVI vdd1 = ds1.addDcVI("VDD_DPS");
        vdd1.setConnect(true).setDisconnect(true);
        vdd1.level().setVrange(7.0).setIrange(0.025).setVforce(5.5).setIclamp(0.025);

        ISetupDcVI vddq1 = ds1.addDcVI("VDDQGroup");
        vddq1.setConnect(true).setDisconnect(true);
        vddq1.level().setVrange(30.0).setIrange(0.05).setVforce(12.0).setIclamp(0.05);

        ISetupDcVI lfireHfire1 = ds1.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire1.setConnect(true).setDisconnect(true);
        lfireHfire1.level().setVrange(6.0).setIrange(0.001).setVforce(0.0).setIclamp(0.001);

        // Relays for Measurement 2 (ds1): keep closed statically during test, open at shutdown
        ISetupUtility K5_VSS_GND_turnon_ds1 = ds1.addUtility("K5_VSS_GND");
        K5_VSS_GND_turnon_ds1.setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_utility_0_ds1 = K5_VSS_GND_turnon_ds1.setState("K5_VSS_GND_utility_0_ds1").setValue(0).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_turnon_ds1 = ds1.addUtility("K4_ISET_PS");
        K4_ISET_PS_turnon_ds1.setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_utility_0_ds1 = K4_ISET_PS_turnon_ds1.setState("K4_ISET_PS_utility_0_ds1").setValue(0).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_turnon_ds1 = ds1.addUtility("K2_ISET_R4K");
        K2_ISET_R4K_turnon_ds1.setValue(1);
        ISetupUtility.ISetState K2_ISET_R4K_utility_0_ds1 = K2_ISET_R4K_turnon_ds1.setState("K2_ISET_R4K_utility_0_ds1").setValue(0).setSettlingTime(0.02);

        // Digital setup for ARM_PS (driven by PE digital driver: 0V -> 5.5V)
        ISetupDigInOut armDigInOut = ds1.addDigInOut("ARM_PS");
        armDigInOut.setConnect(true).setDisconnect(true);
        armDigInOut.level("arm_level").setVil(0.0).setVih(5.5).setVth(2.5);
        armDigInOut.timing("arm_timing").setPeriod(5e-6).setD1(0.0);
        armDigInOut.addWavetable(1)
                .addStateCharDescription('0', DriveAction.F00)
                .addStateCharDescription('1', DriveAction.F10);

        ISetupDigInOut.ITmuMeasure measureArmRiseTime = armDigInOut.tmuMeasure("measure_arm_rise_time")
                .setSlopeSelectRise().setSamples(TMU_SAMPLES).setInitialDiscard(0).setExpectedEventRate(TMU_EXPECTED_EVENT_RATE);

        // Digital setup for ISET_PS (PE comparator monitoring rising edge settling)
        ISetupDigInOut isetDigInOut = ds1.addDigInOut("ISET_PS");
        isetDigInOut.setConnect(true).setDisconnect(true);
        isetDigInOut.level("iset_level").setVth(0.818); // Updated dynamically before execute()
        isetDigInOut.timing("iset_timing").setPeriod(5e-6).setD1(0.0);
        isetDigInOut.addWavetable(1)
                .addStateCharDescription('N', DriveAction.N);

        ISetupDigInOut.ITmuMeasure measureIsetRiseTime = isetDigInOut.tmuMeasure("measure_iset_rise_time")
                .setSlopeSelectRise().setSamples(TMU_SAMPLES).setInitialDiscard(0).setExpectedEventRate(TMU_EXPECTED_EVENT_RATE);

        // Create in-memory pattern on ARM_PS (Vectors 0 to 9 hold low, Vector 10 transitions high to 5.5V)
        ISetupPattern pattern = ds1.createPattern("tsSettling_pat", 1, "ARM_PS");

        // 10 cycles (50 us) with ARM = 0 to establish solid 0V before the transition
        for (int i = 0; i < 10; i++) {
            pattern.addVector("0");
        }

        // Vector index 10: ARM transitions high to 5.5V (1)
        pattern.addVector("1");

        // Vectors 11 to 60: 50 cycles (250 us hold high while ISET settles)
        for (int i = 0; i < 50; i++) {
            pattern.addVector("1");
        }

        ds1.sequentialBegin("measure_iset_settling_time_pattern");
        {
            // Step 8: Arm BOTH TMUs in parallel (Approved Git architecture from commit 458233b)
            ds1.parallelBegin("arm_both_tmus");
            {
                ds1.sequentialBegin();
                {
                    ds1.actionCall(measureArmRiseTime);
                }
                ds1.sequentialEnd();

                ds1.sequentialBegin();
                {
                    ds1.actionCall(measureIsetRiseTime);
                }
                ds1.sequentialEnd();
            }
            ds1.parallelEnd();

            // Execute pattern: drives ARM low, transitions ARM high at Vector 10, holds high
            ds1.patternCall(pattern);
            ds1.waitCall(0.002);

            // Safe shutdown & disconnect relays AFTER the measurement is complete
            ds1.actionCall(K5_VSS_GND_utility_0_ds1);
            ds1.actionCall(K4_ISET_PS_utility_0_ds1);
            ds1.actionCall(K2_ISET_R4K_utility_0_ds1);
            ds1.waitCall(0.010);
        }
        ds1.sequentialEnd();

        measurement1.setSetups(ds);
        measurement2.setSetups(ds1);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        println("\n<------- ISET Settling Time Test START ------->\n");

        // =========================================================================
        // Step 1 - 6: Measure VISET_Stable (Test Plan Steps 1 to 6)
        // =========================================================================
        println("<--- Step 1 - 6: Measure VISET_Stable --->");
        measurement1.execute();

        IDcVIResults dcResults = measurement1.dcVI("ISET_PS").preserveResults();
        MultiSiteDoubleArray stableIsetVoltageBySite = dcResults.vmeas("measure_iset_stable_voltage").getVoltage("ISET_PS");

        MultiSiteDouble isetStableVoltage = new MultiSiteDouble(0.0);
        for (int site : context.getActiveSites()) {
            double v = stableIsetVoltageBySite.getElement(site, 0);
            isetStableVoltage.set(site, v);
            println("Site " + site + " | VISET_Stable (vmeas): " + v + " V");
        }

        // Datalog VISET_Stable (Test ID 23000)
        ptdDC.evaluate(isetStableVoltage);

        // =========================================================================
        // Step 7 - 8: Measure Settling Time via Dual TMU
        // =========================================================================
        println("\n<--- Step 7 - 8: Measure Settling Time via TMU --->");

        // Dynamically set TMU threshold on ISET_PS for all active sites
        for (int site : context.getActiveSites()) {
            double vStable = isetStableVoltage.get(site);
            double isetThresholdVoltage = vStable * SETTLING_THRESHOLD_RATIO;
            measurement2.digInOut("ISET_PS").level("iset_level").setVth(site, isetThresholdVoltage);
            println("Site " + site + " | TMU Settling Threshold (" + (int)(SETTLING_THRESHOLD_RATIO * 100) + "%): " + String.format("%.4f", isetThresholdVoltage) + " V");
        }

        measurement2.execute();

        MultiSiteTmuSamples[] isetTimeStampResults = measurement2.digInOut("ISET_PS").preserveActionResults()
                .tmuMeasure("measure_iset_rise_time").getTimeStamps("ISET_PS");

        MultiSiteTmuSamples[] armTimeStampResults = measurement2.digInOut("ARM_PS").preserveActionResults()
                .tmuMeasure("measure_arm_rise_time").getTimeStamps("ARM_PS");

        println("ISET TMU result count: " + isetTimeStampResults.length);
        println("ARM  TMU result count: " + armTimeStampResults.length);

        MultiSiteDouble isetSettlingTime = new MultiSiteDouble(9999.0);

        for (int site : context.getActiveSites()) {
            boolean hasIset = false;
            boolean hasArm = false;
            double isetRiseTime = 0.0;
            double armRiseTime = 0.0;
            int isetSampleCount = 0;
            int armSampleCount = 0;

            try {
                if (isetTimeStampResults != null && isetTimeStampResults.length > 0) {
                    double[] isetSamples = isetTimeStampResults[0].getArray().get(site);
                    if (isetSamples != null && isetSamples.length > 0) {
                        isetSampleCount = isetSamples.length;
                        isetRiseTime = isetSamples[0];
                        if (!Double.isNaN(isetRiseTime) && isetRiseTime > 0.0) {
                            hasIset = true;
                        }
                    }
                }
            } catch (Exception e) {
                println("Site " + site + " | ISET TMU read notice: " + e.getMessage());
                hasIset = false;
            }

            try {
                if (armTimeStampResults != null && armTimeStampResults.length > 0) {
                    double[] armSamples = armTimeStampResults[0].getArray().get(site);
                    if (armSamples != null && armSamples.length > 0) {
                        armSampleCount = armSamples.length;
                        armRiseTime = armSamples[0];
                        if (!Double.isNaN(armRiseTime) && armRiseTime > 0.0) {
                            hasArm = true;
                        }
                    }
                }
            } catch (Exception e) {
                println("Site " + site + " | ARM TMU read notice: " + e.getMessage());
                hasArm = false;
            }

            println("Site " + site + " | TMU Samples: ARM=" + armSampleCount + ", ISET=" + isetSampleCount);
            if (hasArm) {
                println("Site " + site + " | ARM Rise Timestamp       : " + String.format("%.3f", armRiseTime * 1e6) + " us");
            } else {
                println("Site " + site + " | ARM Rise Timestamp       : NOT CAPTURED (0 samples)");
            }
            if (hasIset) {
                println("Site " + site + " | ISET Rise Timestamp      : " + String.format("%.3f", isetRiseTime * 1e6) + " us");
            } else {
                println("Site " + site + " | ISET Rise Timestamp      : NOT CAPTURED (0 samples)");
            }

            if (hasIset && hasArm) {
                double diffSettlingTime = isetRiseTime - armRiseTime;
                println("Site " + site + " | Settling Time (tISET - tARM): " + String.format("%.3f", diffSettlingTime * 1e6) + " us");

                if (diffSettlingTime > 0.0 && diffSettlingTime <= 100e-6) {
                    isetSettlingTime.set(site, diffSettlingTime);
                } else {
                    println("Site " + site + " | Settling Time out of limits (>100 us or <=0 us): " + String.format("%.3f", diffSettlingTime * 1e6) + " us. Setting 9999 as FAIL.");
                    isetSettlingTime.set(site, 9999.0);
                }
            } else {
                System.err.println("ERROR: Site " + site + " | Both timestamps not captured (hasIset=" + hasIset + ", hasArm=" + hasArm + ")! Setting 9999 as FAIL.");
                println("ERROR: Site " + site + " | Both timestamps not captured (hasIset=" + hasIset + ", hasArm=" + hasArm + ")! Setting 9999 as FAIL.");
                isetSettlingTime.set(site, 9999.0);
            }
        }

        // Datalog Settling Time (Test ID 23010)
        ptdTime.evaluate(isetSettlingTime);

        println("\n<------- ISET Settling Time Test END ------->\n");
    }
}
