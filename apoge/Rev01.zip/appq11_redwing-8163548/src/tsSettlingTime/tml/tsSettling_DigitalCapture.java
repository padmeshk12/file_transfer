package tsSettlingTime.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupDigInOut;
import xoc.dsa.ISetupPattern;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWavetable.DriveAction;
import xoc.dsa.ISetupWavetable.ReceiveAction;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.resultaccess.IDigInOutCaptureResults;
import xoc.dta.resultaccess.datatypes.BitSequence;
import xoc.dta.resultaccess.datatypes.MultiSiteBitSequence;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : ISET Settling Time - Digital Capture / Fail-to-Pass Search
 *
 * Method Description:
 * Instead of TMU timestamping, this method uses high-speed Digital Capture:
 * 1. Measurement 1 measures stable DC voltage across 4k resistor (VISET_Stable).
 * 2. In Measurement 2, ISET comparator threshold (Vth) is dynamically programmed
 *    to SETTLING_THRESHOLD_RATIO (95% or 99%) of VISET_Stable.
 * 3. Pattern drives ARM low for 20 cycles, then flips ARM high at Vector 20.
 * 4. From Vector 20 onwards, ISET is sampled on every clock cycle with capture action 'C'.
 *    - While VISET < Vth: samples '0' (Fail)
 *    - When VISET >= Vth: samples '1' (Pass)
 * 5. Digital capture retrieves the exact bit stream (0000...0001111...).
 *    The first '1' index gives the exact Fail-to-Pass transition time:
 *    t_settling = passIndex * CAPTURE_PERIOD.
 */
public class tsSettling_DigitalCapture extends TestMethod {

    // Resolution of each cycle (250 ns = 0.25 us)
    public static final double CAPTURE_PERIOD = 250e-9;
    public static final int HOLD_LOW_CYCLES = 20;       // 5 us low before step
    public static final int CAPTURE_CYCLES = 120;       // 30 us capture window after step
    public static final double SETTLING_THRESHOLD_RATIO = 0.95; // 95% settling (or 0.99 for 99%)

    public IMeasurement measurement1;
    public IMeasurement measurement2;

    public IParametricTestDescriptor ptdDC;
    public IParametricTestDescriptor ptdTime;

    @Override
    public void setup() {
        // =========================================================================
        // Measurement 1: Measure VISET_Stable (Test Plan Steps 1 - 6)
        // =========================================================================
        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(false);
        vdd.level().setVrange(7.0).setIrange(0.025);

        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V").setForceValue(5.5).setIrange(0.025).setIclamp(0.025);

        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(false);

        ISetupDcVI.IVforce forceVddq12V = vddq.vforce("force_vddq_12V").setForceValue(12.0).setVrange(30.0).setIrange(0.05).setIclamp(0.05);

        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(false);

        ISetupDcVI.IVforce forceLfireHfireTo0V = lfireHfire.vforce("force_lfire_hfire_0V").setForceValue(0.0).setVrange(6.0).setIrange(0.001).setIclamp(0.001);

        // Relays for Measurement 1
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_turnon = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_turnon = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_utility_0 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_utility_1 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_1").setValue(1).setSettlingTime(0.02);

        // ARM_PS setup: force 0V initially, then step to 5.5V
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce forceArm0V = arm.vforce("force_arm_0V").setForceValue(0.0).setVrange(5.75).setIrange(0.025).setIclamp(0.025);
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V").setForceValue(5.5).setVrange(5.75).setIrange(0.025).setIclamp(0.025);

        // ISET_PS setup: High-Z connect, measure stable DC voltage across 4k resistor
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);
        ISetupDcVI.IVmeas measureIsetStableVoltage = iset.vmeas("measure_iset_stable_voltage").setVrange(5.75);

        ds.sequentialBegin("measure_iset_stable_voltage_seq");
        {
            // Step 3: Apply 4k-ohm resistor between ISET and VSS (Relays on)
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.actionCall(K2_ISET_R4K_utility_1);
            ds.waitCall(0.020);

            // Step 1: Power up device with VDD = 5.5V, VDDQ = 12V
            ds.actionCall(forceVdd5p5V);
            ds.actionCall(forceVddq12V);

            // Step 2: Set ARM, LFIRE and HFIRE low
            ds.actionCall(forceLfireHfireTo0V);
            ds.actionCall(forceArm0V);
            ds.waitCall(0.010);

            // Step 4 & 5: Toggle ARM high (5.5V) and wait 1 ms
            ds.actionCall(forceArm5p5V);
            ds.waitCall(0.001);

            // Step 6: Measure the voltage on ISET and datalog as VISET_Stable
            ds.actionCall(measureIsetStableVoltage);

            // Step 7: Toggle ARM low and wait 1 ms
            ds.actionCall(forceArm0V);
            ds.waitCall(0.001);
        }
        ds.sequentialEnd();

        // =========================================================================
        // Measurement 2: Measure Settling Time via Digital Capture
        // =========================================================================
        IDeviceSetup ds1 = DeviceSetupFactory.createInstance();
        ds1.importSpec("common.pinGroups");

        // Maintain power supplies actively for Measurement 2
        ISetupDcVI vdd1 = ds1.addDcVI("VDD_DPS");
        vdd1.setConnect(true).setDisconnect(true);
        vdd1.level().setVrange(7.0).setIrange(0.025).setVforce(5.5).setIclamp(0.025);

        ISetupDcVI vddq1 = ds1.addDcVI("VDDQGroup");
        vddq1.setConnect(true).setDisconnect(true);
        vddq1.level().setVrange(30.0).setIrange(0.05).setVforce(12.0).setIclamp(0.05);

        ISetupDcVI lfireHfire1 = ds1.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire1.setConnect(true).setDisconnect(true);
        lfireHfire1.level().setVrange(6.0).setIrange(0.001).setVforce(0.0).setIclamp(0.001);

        // Relays for Measurement 2 (ds1)
        ISetupUtility K5_VSS_GND_turnon_ds1 = ds1.addUtility("K5_VSS_GND");
        K5_VSS_GND_turnon_ds1.setValue(1);
        ISetupUtility.ISetState K5_VSS_GND_utility_0_ds1 = K5_VSS_GND_turnon_ds1.setState("K5_VSS_GND_utility_0_ds1").setValue(0).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_turnon_ds1 = ds1.addUtility("K4_ISET_PS");
        K4_ISET_PS_turnon_ds1.setValue(1);
        ISetupUtility.ISetState K4_ISET_PS_utility_0_ds1 = K4_ISET_PS_turnon_ds1.setState("K4_ISET_PS_utility_0_ds1").setValue(0).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_turnon_ds1 = ds1.addUtility("K2_ISET_R4K");
        K2_ISET_R4K_turnon_ds1.setValue(1);
        ISetupUtility.ISetState K2_ISET_R4K_utility_0_ds1 = K2_ISET_R4K_turnon_ds1.setState("K2_ISET_R4K_utility_0_ds1").setValue(0).setSettlingTime(0.02);

        // Digital setup for ARM_PS (fast PE driver: 0V -> 5.5V)
        ISetupDigInOut armDigInOut = ds1.addDigInOut("ARM_PS");
        armDigInOut.setConnect(true).setDisconnect(true);
        armDigInOut.level("arm_level").setVil(0.0).setVih(5.5).setVth(2.5);
        armDigInOut.timing("arm_timing").setPeriod(CAPTURE_PERIOD).setD1(0.0);
        armDigInOut.addWavetable(1)
                .addStateCharDescription('0', DriveAction.F00)
                .addStateCharDescription('1', DriveAction.F10);

        // Digital setup for ISET_PS (PE comparator capture)
        ISetupDigInOut isetDigInOut = ds1.addDigInOut("ISET_PS");
        isetDigInOut.setConnect(true).setDisconnect(true);
        isetDigInOut.level("iset_level").setVth(0.818); // Dynamic threshold updated in execute()
        isetDigInOut.timing("iset_timing")
                .setPeriod(CAPTURE_PERIOD)
                .setD1(0.0)
                .setR1(CAPTURE_PERIOD / 2.0); // Sample midway through each cycle

        isetDigInOut.addWavetable(1)
                .addStateCharDescription('X', DriveAction.FNZ, ReceiveAction.X)
                .addStateCharDescription('C', DriveAction.FNZ, ReceiveAction.C);

        // Enable Digital Capture mode on ISET_PS
        isetDigInOut.result().capture().setEnabled(true);

        // Create Pattern with both ARM_PS and ISET_PS
        ISetupPattern pattern = ds1.createPattern("tsSettling_cap_pat", 1, "ARM_PS + ISET_PS");

        // Step 1: Hold ARM low (0) and ignore ISET (X) for 20 cycles (5 us)
        for (int i = 0; i < HOLD_LOW_CYCLES; i++) {
            pattern.addVector("0X");
        }

        // Step 2: Vector index 20: ARM flips to 1 (5.5V), ISET starts capturing (C)
        pattern.addVector("1C");

        // Step 3: Vectors 21 to 140: Hold ARM high (1), capture ISET every cycle (C)
        for (int i = 0; i < CAPTURE_CYCLES - 1; i++) {
            pattern.addVector("1C");
        }

        ds1.sequentialBegin("measure_iset_settling_capture_seq");
        {
            // Execute pattern burst
            ds1.patternCall(pattern);
            ds1.waitCall(0.002);

            // Shutdown relays
            ds1.actionCall(K5_VSS_GND_utility_0_ds1);
            ds1.actionCall(K4_ISET_PS_utility_0_ds1);
            ds1.actionCall(K2_ISET_R4K_utility_0_ds1);
            ds1.waitCall(0.010);
        }
        ds1.sequentialEnd();

        measurement1.setSetups(ds);
        measurement2.setSetups(ds1);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        println("\n<------- ISET Settling Time (Digital Capture) START ------->\n");

        // Step 1 - 6: Measure VISET_Stable
        println("<--- Step 1 - 6: Measure VISET_Stable --->");
        measurement1.execute();

        IDcVIResults dcResults = measurement1.dcVI("ISET_PS").preserveResults();
        MultiSiteDoubleArray stableIsetVoltageBySite = dcResults.vmeas("measure_iset_stable_voltage").getVoltage("ISET_PS");

        MultiSiteDouble isetStableVoltage = new MultiSiteDouble(0.0);
        for (int site : context.getActiveSites()) {
            double v = stableIsetVoltageBySite.getElement(site, 0);
            isetStableVoltage.set(site, v);
            println("Site " + site + " | VISET_Stable (vmeas): " + v + " V");
        }

        ptdDC.evaluate(isetStableVoltage);

        // Step 7 - 8: Digital Capture & Fail-to-Pass Analysis
        println("\n<--- Step 7 - 8: Digital Capture & Fail-to-Pass Search --->");

        for (int site : context.getActiveSites()) {
            double vStable = isetStableVoltage.get(site);
            double isetThresholdVoltage = vStable * SETTLING_THRESHOLD_RATIO;
            measurement2.digInOut("ISET_PS").level("iset_level").setVth(site, isetThresholdVoltage);
            println("Site " + site + " | Dynamic Vth (" + (int)(SETTLING_THRESHOLD_RATIO * 100) + "%): " + String.format("%.4f", isetThresholdVoltage) + " V");
        }

        // Execute single pattern burst
        measurement2.execute();

        IDigInOutCaptureResults digCapture = measurement2.digInOut("ISET_PS").preserveCaptureResults();
        MultiSiteBitSequence bitsOfAllSites = digCapture.getSerialBitsAsBitSequence("ISET_PS");

        MultiSiteDouble isetSettlingTime = new MultiSiteDouble(9999.0);

        for (int site : context.getActiveSites()) {
            BitSequence bitSeq = bitsOfAllSites.get(site);
            if (bitSeq == null || bitSeq.length() == 0) {
                System.err.println("ERROR: Site " + site + " | No bits captured! Setting 9999 as FAIL.");
                println("ERROR: Site " + site + " | No bits captured! Setting 9999 as FAIL.");
                isetSettlingTime.set(site, 9999.0);
                continue;
            }

            int bitCount = bitSeq.length();
            println("Site " + site + " | Total Captured Cycles: " + bitCount);
            println("Site " + site + " | Captured Bitstream   : " + bitSeq.toString());

            // Find the exact Fail-to-Pass transition: first index where bit is '1' (Pass)
            int firstPassIndex = bitSeq.nextSetBit(0);

            if (firstPassIndex >= 0) {
                // Time from ARM high transition (cycle 0) to threshold crossing
                double settlingTimeSeconds = firstPassIndex * CAPTURE_PERIOD;
                println("Site " + site + " | Fail-to-Pass Sample Index: " + firstPassIndex);
                println("Site " + site + " | Resolution per sample    : " + String.format("%.3f", CAPTURE_PERIOD * 1e6) + " us");
                println("Site " + site + " | Measured Settling Time  : " + String.format("%.3f", settlingTimeSeconds * 1e6) + " us");

                if (settlingTimeSeconds > 0.0 && settlingTimeSeconds <= 100e-6) {
                    isetSettlingTime.set(site, settlingTimeSeconds);
                } else {
                    println("Site " + site + " | Settling Time out of limits (>100 us or <=0 us): " + String.format("%.3f", settlingTimeSeconds * 1e6) + " us. Setting 9999 as FAIL.");
                    isetSettlingTime.set(site, 9999.0);
                }
            } else {
                System.err.println("ERROR: Site " + site + " | Signal did NOT reach " + (int)(SETTLING_THRESHOLD_RATIO * 100) + "% threshold within " + String.format("%.1f", bitCount * CAPTURE_PERIOD * 1e6) + " us window! Setting 9999 as FAIL.");
                println("ERROR: Site " + site + " | Signal did NOT reach " + (int)(SETTLING_THRESHOLD_RATIO * 100) + "% threshold within " + String.format("%.1f", bitCount * CAPTURE_PERIOD * 1e6) + " us window! Setting 9999 as FAIL.");
                isetSettlingTime.set(site, 9999.0);
            }
        }

        // Datalog Settling Time (Test ID 23010)
        ptdTime.evaluate(isetSettlingTime);

        println("\n<------- ISET Settling Time (Digital Capture) END ------->\n");
    }
}
