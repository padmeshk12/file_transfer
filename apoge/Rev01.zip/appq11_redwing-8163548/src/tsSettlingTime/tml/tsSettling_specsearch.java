package tsSettlingTime.tml;

import com.advantest.itee.tmapi.ac.SpecSearch;
import com.advantest.itee.tmapi.ac.SpecSearch.SearchMethodOption;
import com.advantest.itee.tmapi.ac.SpecSearch.SpecSearchGroup;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupDigInOut;
import xoc.dsa.ISetupPattern;
import xoc.dsa.ISetupUtility;
import xoc.dsa.ISetupWavetable.DriveAction;
import xoc.dsa.ISetupWavetable.ReceiveAction;
import xoc.dsa.SetupVariableType;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.datatypes.MultiSiteString;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : ISET Settling Time - SpecSearch Method
 *
 * Method Description:
 * This method implements the classic SpecSearch (Fail-to-Pass transition search):
 * 1. Measurement 1 measures stable DC voltage across 4k resistor (VISET_Stable).
 * 2. In Measurement 2:
 *    - ARM_PS transitions from 0V to 5.5V at Vector 1 (t = 0 of cycle).
 *    - ISET_PS comparator threshold (Voh) is set to 95% of VISET_Stable.
 *    - ISET_PS strobe delay (r1) is bound to a timing variable "t_iset_strobe".
 * 3. SpecSearch (LIN_BIN / BINARY) sweeps "t_iset_strobe" from 0 us to 30 us:
 *    - While strobe < settling time: ISET < Voh -> Vector 1 FAILS.
 *    - When strobe >= settling time: ISET >= Voh -> Vector 1 PASSES.
 * 4. SpecSearch identifies the exact FAIL_TO_PASS boundary and outputs the settling time.
 */
public class tsSettling_specsearch extends TestMethod {

    public static final double SETTLING_THRESHOLD_RATIO = 0.95; // 95% settling (or 0.99 for 99%)
    public static final double CYCLE_PERIOD_SECONDS = 25e-6;    // 25 us per cycle (< 31.25 us hardware max limit)
    public static final double SEARCH_START_SECONDS = 0.0;       // Search start: 0 us
    public static final double SEARCH_STOP_SECONDS = 24e-6;      // Search stop: 24 us (inside 25 us cycle)
    public static final double SEARCH_STEP_WIDTH = 1e-6;         // Coarse linear step: 1 us
    public static final double SEARCH_RESOLUTION = 50e-9;        // Fine binary resolution: 50 ns

    public IMeasurement measurement1;
    public IMeasurement measurement2;

    public IParametricTestDescriptor ptdDC;
    public IParametricTestDescriptor ptdTime;

    @Override
    public void setup() {
        // =========================================================================
        // Measurement 1: Measure VISET_Stable (Test Plan Steps 1 - 6)
        // =========================================================================
        IDeviceSetup ds = DeviceSetupFactory.createInstance();
        ds.importSpec("common.pinGroups");

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(false);
        vdd.level().setVrange(7.0).setIrange(0.025);

        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V").setForceValue(5.5).setIrange(0.025).setIclamp(0.025);

        ISetupDcVI vddq = ds.addDcVI("VDDQGroup");
        vddq.setConnect(true).setDisconnect(false);

        ISetupDcVI.IVforce forceVddq12V = vddq.vforce("force_vddq_12V").setForceValue(12.0).setVrange(30.0).setIrange(0.05).setIclamp(0.05);

        ISetupDcVI lfireHfire = ds.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire.setConnect(true).setDisconnect(false);

        ISetupDcVI.IVforce forceLfireHfireTo0V = lfireHfire.vforce("force_lfire_hfire_0V").setForceValue(0.0).setVrange(6.0).setIrange(0.001).setIclamp(0.001);

        // Relays for Measurement 1
        ISetupUtility K5_VSS_GND_turnon = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND_turnon.setState("K5_VSS_GND_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS_turnon = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS_turnon.setState("K4_ISET_PS_utility_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K2_ISET_R4K_turnon = ds.addUtility("K2_ISET_R4K");
        ISetupUtility.ISetState K2_ISET_R4K_utility_0 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K2_ISET_R4K_utility_1 = K2_ISET_R4K_turnon.setState("K2_ISET_R4K_utility_1").setValue(1).setSettlingTime(0.02);

        // ARM_PS setup: force 0V initially, then step to 5.5V
        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce forceArm0V = arm.vforce("force_arm_0V").setForceValue(0.0).setVrange(5.75).setIrange(0.025).setIclamp(0.025);
        ISetupDcVI.IVforce forceArm5p5V = arm.vforce("force_arm_5p5V").setForceValue(5.5).setVrange(5.75).setIrange(0.025).setIclamp(0.025);

        // ISET_PS setup: High-Z connect, measure stable DC voltage across 4k resistor
        ISetupDcVI iset = ds.addDcVI("ISET_PS");
        iset.setConnectModeHighImpedance().setDisconnect(true);
        ISetupDcVI.IVmeas measureIsetStableVoltage = iset.vmeas("measure_iset_stable_voltage").setVrange(5.75);

        ds.sequentialBegin("measure_iset_stable_voltage_seq");
        {
            // Step 3: Apply 4k-ohm resistor between ISET and VSS (Relays on)
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.actionCall(K2_ISET_R4K_utility_1);
            ds.waitCall(0.020);

            // Step 1: Power up device with VDD = 5.5V, VDDQ = 12V
            ds.actionCall(forceVdd5p5V);
            ds.actionCall(forceVddq12V);

            // Step 2: Set ARM, LFIRE and HFIRE low
            ds.actionCall(forceLfireHfireTo0V);
            ds.actionCall(forceArm0V);
            ds.waitCall(0.010);

            // Step 4 & 5: Toggle ARM high (5.5V) and wait 1 ms
            ds.actionCall(forceArm5p5V);
            ds.waitCall(0.001);

            // Step 6: Measure the voltage on ISET and datalog as VISET_Stable
            ds.actionCall(measureIsetStableVoltage);

            // Step 7: Toggle ARM low and wait 1 ms
            ds.actionCall(forceArm0V);
            ds.waitCall(0.001);
        }
        ds.sequentialEnd();

        // =========================================================================
        // Measurement 2: SpecSearch for Settling Time (Fail-to-Pass Transition)
        // =========================================================================
        IDeviceSetup ds1 = DeviceSetupFactory.createInstance();
        ds1.importSpec("common.pinGroups");

        // Maintain power supplies actively for Measurement 2
        ISetupDcVI vdd1 = ds1.addDcVI("VDD_DPS");
        vdd1.setConnect(true).setDisconnect(true);
        vdd1.level().setVrange(7.0).setIrange(0.025).setVforce(5.5).setIclamp(0.025);

        ISetupDcVI vddq1 = ds1.addDcVI("VDDQGroup");
        vddq1.setConnect(true).setDisconnect(true);
        vddq1.level().setVrange(30.0).setIrange(0.05).setVforce(12.0).setIclamp(0.05);

        ISetupDcVI lfireHfire1 = ds1.addDcVI("LFIRE_PS + HFIRE_PS");
        lfireHfire1.setConnect(true).setDisconnect(true);
        lfireHfire1.level().setVrange(6.0).setIrange(0.001).setVforce(0.0).setIclamp(0.001);

        // Relays for Measurement 2 (ds1): held closed throughout all search iterations
        ISetupUtility K5_VSS_GND_turnon_ds1 = ds1.addUtility("K5_VSS_GND");
        K5_VSS_GND_turnon_ds1.setValue(1);

        ISetupUtility K4_ISET_PS_turnon_ds1 = ds1.addUtility("K4_ISET_PS");
        K4_ISET_PS_turnon_ds1.setValue(1);

        ISetupUtility K2_ISET_R4K_turnon_ds1 = ds1.addUtility("K2_ISET_R4K");
        K2_ISET_R4K_turnon_ds1.setValue(1);

        // Declare timing spec variable "t_iset_strobe" to be swept by SpecSearch
        ds1.addVariableDeclaration(SetupVariableType.Time, "t_iset_strobe");
        ds1.setVariableDefinition("t_iset_strobe", "0.0 s");

        // Digital setup for ARM_PS (fast PE driver: 0V -> 5.5V)
        ISetupDigInOut armDigInOut = ds1.addDigInOut("ARM_PS");
        armDigInOut.setConnect(true).setDisconnect(true);
        armDigInOut.level("arm_level").setVil(0.0).setVih(5.5).setVth(2.5);
        armDigInOut.timing("arm_timing").setPeriod(CYCLE_PERIOD_SECONDS).setD1(0.0);
        armDigInOut.addWavetable(1)
                .addStateCharDescription('0', DriveAction.F00)
                .addStateCharDescription('1', DriveAction.F10);

        // Digital setup for ISET_PS (PE comparator comparing against Voh)
        ISetupDigInOut isetDigInOut = ds1.addDigInOut("ISET_PS");
        isetDigInOut.setConnect(true).setDisconnect(true);
        isetDigInOut.level("iset_level").setVol(0.0).setVoh(0.818);
        isetDigInOut.timing("iset_timing").setPeriod(CYCLE_PERIOD_SECONDS).setD1(0.0).setR1("t_iset_strobe");
        isetDigInOut.addWavetable(1)
                .addStateCharDescription('X', DriveAction.FNZ, ReceiveAction.X)
                .addStateCharDescription('H', DriveAction.FNZ, ReceiveAction.H);

        // Pattern for SpecSearch:
        // Vectors 0 & 1: ARM = 0, ISET = X (2 x 25 us = 50 us hold low)
        // Vector 2: ARM = 1, ISET = H (ARM transitions high at t=0, ISET strobed at t_iset_strobe)
        // Vector 3: ARM = 1, ISET = X (25 us hold high)
        ISetupPattern pattern = ds1.createPattern("tsSettling_search_pat", 1, "ARM_PS + ISET_PS");
        pattern.addVector("0X");
        pattern.addVector("0X");
        pattern.addVector("1H");
        pattern.addVector("1X");

        ds1.sequentialBegin("measure_iset_specsearch_seq");
        {
            ds1.patternCall(pattern);
            ds1.waitCall(0.001);
        }
        ds1.sequentialEnd();

        measurement1.setSetups(ds);
        measurement2.setSetups(ds1);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        println("\n<------- ISET Settling Time (SpecSearch) START ------->\n");

        // Step 1 - 6: Measure VISET_Stable
        println("<--- Step 1 - 6: Measure VISET_Stable --->");
        measurement1.execute();

        IDcVIResults dcResults = measurement1.dcVI("ISET_PS").preserveResults();
        MultiSiteDoubleArray stableIsetVoltageBySite = dcResults.vmeas("measure_iset_stable_voltage").getVoltage("ISET_PS");

        MultiSiteDouble isetStableVoltage = new MultiSiteDouble(0.0);
        for (int site : context.getActiveSites()) {
            double v = stableIsetVoltageBySite.getElement(site, 0);
            isetStableVoltage.set(site, v);
            println("Site " + site + " | VISET_Stable (vmeas): " + v + " V");
        }

        ptdDC.evaluate(isetStableVoltage);

        // Step 7 - 8: SpecSearch for Fail-to-Pass Transition
        println("\n<--- Step 7 - 8: SpecSearch for Fail-to-Pass Transition --->");

        for (int site : context.getActiveSites()) {
            double vStable = isetStableVoltage.get(site);
            double isetThresholdVoltage = vStable * SETTLING_THRESHOLD_RATIO;
            measurement2.digInOut("ISET_PS").level("iset_level").setVol(site, 0.0);
            measurement2.digInOut("ISET_PS").level("iset_level").setVoh(site, isetThresholdVoltage);
            println("Site " + site + " | Dynamic Voh (" + (int)(SETTLING_THRESHOLD_RATIO * 100) + "%): " + String.format("%.4f", isetThresholdVoltage) + " V");
        }

        MultiSiteDouble isetSettlingTime = new MultiSiteDouble(9999.0);

        try {
            // Configure SpecSearch task
            SpecSearch mySearchTask = new SpecSearch(measurement2, context);
            mySearchTask.setSearchMethod(SearchMethodOption.LIN_BIN);

            SpecSearchGroup searchGroup = mySearchTask.addGroup("IsetSettlingGroup");
            searchGroup.setResultSignals("ISET_PS")
                       .setSpecVariable("t_iset_strobe")
                       .setStart(SEARCH_START_SECONDS)
                       .setStop(SEARCH_STOP_SECONDS)
                       .setStepWidth(SEARCH_STEP_WIDTH)
                       .setResolution(SEARCH_RESOLUTION);

            println("Executing SpecSearch: Start=" + (SEARCH_START_SECONDS * 1e6) + " us, Stop=" + (SEARCH_STOP_SECONDS * 1e6) + " us, Step=" + (SEARCH_STEP_WIDTH * 1e6) + " us, Res=" + (SEARCH_RESOLUTION * 1e9) + " ns");

            mySearchTask.execute();

            MultiSiteDouble passValues = searchGroup.getPassValues();
            MultiSiteString resultTypes = searchGroup.getResultType();

            for (int site : context.getActiveSites()) {
                double tSettling = passValues.get(site);
                String transitionType = resultTypes != null ? resultTypes.get(site) : "UNKNOWN";

                println("Site " + site + " | Transition Type: " + transitionType);
                println("Site " + site + " | Measured Settling Time: " + String.format("%.3f", tSettling * 1e6) + " us");

                if (tSettling > 0.0 && tSettling <= 100e-6) {
                    isetSettlingTime.set(site, tSettling);
                } else {
                    println("Site " + site + " | Settling Time out of limits (>100 us or <=0 us): " + String.format("%.3f", tSettling * 1e6) + " us. Setting 9999 as FAIL.");
                    isetSettlingTime.set(site, 9999.0);
                }
            }
        } catch (Exception e) {
            System.err.println("SpecSearch exception: " + e.getMessage());
            println("SpecSearch notice/fallback: " + e.getMessage());
            e.printStackTrace();

            // Programmatic binary search fallback if SpecSearch task encounters environment restriction
            println("Running Programmatic Binary Search fallback...");
            isetSettlingTime = executeProgrammaticBinarySearch();
        }

        // Datalog Settling Time (Test ID 23010)
        ptdTime.evaluate(isetSettlingTime);

        println("\n<------- ISET Settling Time (SpecSearch) END ------->\n");
    }

    /**
     * Programmatic binary search fallback:
     * Directly sweeps r1 strobe delay on ISET_PS between 0 us and 30 us with binary search.
     */
    private MultiSiteDouble executeProgrammaticBinarySearch() {
        MultiSiteDouble resultSettlingTime = new MultiSiteDouble(9999.0);

        for (int site : context.getActiveSites()) {
            double low = SEARCH_START_SECONDS;
            double high = SEARCH_STOP_SECONDS;
            double bestPass = 9999.0;

            // 10 binary search iterations down to ~29 ns resolution (30 us / 2^10)
            int iterations = 10;
            for (int i = 0; i < iterations; i++) {
                double mid = (low + high) / 2.0;
                measurement2.digInOut("ISET_PS").timing("iset_timing").setR1(site, mid);
                measurement2.execute();

                boolean pass = measurement2.hasPassed(site);
                println("  [Search Iter " + (i + 1) + "] Strobe=" + String.format("%.3f", mid * 1e6) + " us -> " + (pass ? "PASS" : "FAIL"));

                if (pass) {
                    bestPass = mid;
                    high = mid; // Search earlier for transition boundary
                } else {
                    low = mid;  // Search later
                }
            }

            if (bestPass > 0.0 && bestPass <= 100e-6) {
                println("Site " + site + " | Programmatic Search Settling Time: " + String.format("%.3f", bestPass * 1e6) + " us");
                resultSettlingTime.set(site, bestPass);
            } else {
                println("Site " + site + " | Programmatic Search FAIL (Did not pass within window).");
                resultSettlingTime.set(site, 9999.0);
            }
        }

        return resultSettlingTime;
    }
}
