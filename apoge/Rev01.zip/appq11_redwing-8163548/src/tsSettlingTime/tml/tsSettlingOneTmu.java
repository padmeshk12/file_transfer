package tsSettlingTime.tml;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupDigInOut;
import xoc.dsa.ISetupWavetable.DriveAction;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.ITmuMeasureResults;
import xoc.dta.resultaccess.datatypes.MultiSiteTmuSamples;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

public class tsSettlingOneTmu extends TestMethod {

    public IMeasurement measurement;
    public IParametricTestDescriptor ptdTime;

    @Override
    public void setup() {
        // TODO Auto-generated method stub

        IDeviceSetup ds = DeviceSetupFactory.createInstance();

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level()
//        .setVforce(voltageForce)           // Force voltage (V)
        .setVrange(7.0)           // Voltage range (V)
        .setIrange(0.025);       // Current range (A)
//        .setIclamp(currentClamp);

        ISetupDcVI.IVforce vddForce3p3V = vdd.vforce("VDD_force_3p3V")
                .setForceValue(3.3)
                .setIrange(0.025)
                .setIclamp(0.025);

        ISetupDcVI vddq = ds.addDcVI("VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 +VDDQ1_AVI8");
        vddq.setConnect(true).setDisconnect(true);

        ISetupDcVI.IVforce vddqForce12V = vddq.vforce("vddq_force_12V").setForceValue(12.0)
                .setVrange(30.0).setIrange(0.05).setIclamp(0.05);

        ISetupDcVI arm = ds.addDcVI("ARM_PS");
        arm.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce armForce0V = arm.vforce("arm_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI.IVforce armForce5p5V = arm.vforce("arm_force_5p5V")
                .setForceValue(5.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);

        ISetupDcVI lfire = ds.addDcVI("LFIRE_PS");
        lfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce lfireForce0V = lfire.vforce("lfire_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDcVI hfire = ds.addDcVI("HFIRE_PS");
        hfire.setConnect(true).setDisconnect(true);
        ISetupDcVI.IVforce hfireForce0V = hfire.vforce("hfire_force_0V")
                .setForceValue(0.0)
                .setVrange(5.75)
                .setIrange(0.001)
                .setIclamp(0.001);
        ISetupDigInOut iset = ds.addDigInOut("ISET_PS");
        iset.setConnect(true).setDisconnect(true);

        iset.addWavetable(1).addStateCharDescription('N', DriveAction.N);
        iset.timing().setPeriod(0.00001).setD1(0.0);
        iset.level().setVol(0.0).setVoh(0.825);

//        ISetupDigInOut.ILevel level = iset.level("levelSet_1").setVi1(0.0).setVih(3.3).setVo1(0.0).setVoh(0.825);


        ISetupDigInOut.ITmuMeasure isetSettlingTime = iset.tmuMeasure("tsSettlingTime").setSlopeSelectRise().setSamples(1).setInitialDiscard(0).setExpectedEventRate(5000);

        ISetupDigInOut.IIforce isetForceCurr = iset.iforce("isetForceCurr1mA")
                .setForceValue(0.001)
                .setVclampHigh(1.0)
                .setVclampLow(0);


            ds.sequentialBegin("seq1");
            {
            ds.actionCall(vddForce3p3V);
            ds.actionCall(vddqForce12V);
            ds.actionCall(armForce0V);
            ds.actionCall(lfireForce0V);
            ds.actionCall(hfireForce0V);
            ds.actionCall(isetForceCurr);
            ds.parallelBegin();{
                ds.sequentialBegin();{
                    ds.actionCall(armForce5p5V);
                }
                ds.sequentialEnd();
                ds.sequentialBegin();{
                    ds.actionCall(isetSettlingTime);
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            }
            ds.sequentialEnd();


            measurement.setSetups(ds);




    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute() {
        // TODO Auto-generated method stub

        measurement.execute();

        ITmuMeasureResults tmurslts = measurement.digInOut("ISET_PS").preserveActionResults()
                .tmuMeasure("tsSettlingTime");

        MultiSiteTmuSamples[] tmurslt = tmurslts.getTimeStamps("ISET_PS");

        System.out.println("The length of tmu results action is " + tmurslt.length);

        MultiSiteTmuSamples sigTimeStamp = tmurslts.getTimeStamps("ISET_PS")[0];
        MultiSiteDouble riseTime = sigTimeStamp.median();

        System.out.println("The rise time is  " + riseTime);

        ptdTime.evaluate(riseTime);

    }

    }


