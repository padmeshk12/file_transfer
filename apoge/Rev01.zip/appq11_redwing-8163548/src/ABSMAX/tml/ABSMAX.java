package ABSMAX.tml;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.IDeviceSetup.DSAGenerationMode;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupUtility;
import xoc.dta.TestMethod;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteDoubleArray;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * Test Name  : ABSMAX
 * Author     : Seelam Rajeev Reddy
 *
 * Test Procedure:
 * Apply 55 V individually to VDDQ, SQP, and SQM while holding all remaining
 * high-power and I/O signals at 0 V. Measure the total current for each
 * high-power group. Then apply 5.5 V individually to each I/O signal and VDD
 * while all other signals remain at 0 V.
 */
public class ABSMAX extends TestMethod {

    public IMeasurement measurement;

    public String SQPGroup =
            "SQP1_AVI1 + SQP1_AVI2 + SQP2_AVI3 + SQP2_AVI4 + "
                    + "SQP3_AVI5 + SQP3_AVI6 + SQP4_AVI7 + SQP4_AVI8";

    public String SQMGroup =
            "SQM1_AVI1 + SQM1_AVI2 + SQM2_AVI3 + SQM2_AVI4 + "
                    + "SQM3_AVI5 + SQM3_AVI6 + SQM4_AVI7 + SQM4_AVI8";

    public String VDDQGroup =
            "VDDQ1_AVI1 + VDDQ1_AVI2 + VDDQ2_AVI3 + VDDQ2_AVI4 + "
                    + "VDDQ2_AVI5 + VDDQ2_AVI6 + VDDQ1_AVI7 + VDDQ1_AVI8";

    public IParametricTestDescriptor ptdDCHighP;
    public IParametricTestDescriptor ptdDCIO;

    @Override
    public void setup() {
        IDeviceSetup ds = DeviceSetupFactory.createNamedInstance(
                "ABSMAX",
                DSAGenerationMode.GENERATE_IN_FILE);

        String allHighPowerGroups = SQPGroup + "+" + SQMGroup + "+" + VDDQGroup;
        String allIoSignals = "ARM_PS + HFIRE_PS + LFIRE_PS + ISET_PS + TD_PS + TEST_PS";

        ISetupDcVI vdd = ds.addDcVI("VDD_DPS");
        vdd.setConnect(true).setDisconnect(true);
        vdd.level().setVrange(7.0).setIrange(0.025).setVforce(0.0).setIclamp(0.025);

        // Force 5.5 V on the VDD supply.
        ISetupDcVI.IVforce forceVdd5p5V = vdd.vforce("force_vdd_5p5V")
                .setForceValue(5.5)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Force 0 V on the VDD supply.
        ISetupDcVI.IVforce forceVdd0V = vdd.vforce("force_vdd_0V")
                .setForceValue(0.0)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Measure VDD supply current.
        ISetupDcVI.IImeas measureVddCurrent = vdd.imeas("measure_vdd_current")
                .setIrange(0.025)
                .setRestoreIrange(true);

        ISetupDcVI highPowerSignals = ds.addDcVI(allHighPowerGroups);
        highPowerSignals.setConnect(true).setDisconnect(true);

        // Force 0 V on selected high-power signals.
        ISetupDcVI.IVforce forceHighPower0V = highPowerSignals.vforce("force_high_power_0V")
                .setForceValue(0.0)
                .setVrange(16.0)
                .setIrange(0.1)
                .setIclamp(0.1);

        // Force 12 V on the selected high-power signal group (safe <= 12V for current silicon).
        ISetupDcVI.IVforce forceHighPower55V = highPowerSignals.vforce("force_high_power_55V")
                .setForceValue(12.0)
                .setVrange(16.0)
                .setIrange(0.1)
                .setIclamp(0.1);

        // Measure current on the selected high-power signal group.
        ISetupDcVI.IImeas measureHighPowerCurrent = highPowerSignals.imeas("measure_high_power_current")
                .setIrange(0.1);

        // Configure dynamic relay states
        ISetupUtility K5_VSS_GND = ds.addUtility("K5_VSS_GND");
        ISetupUtility.ISetState K5_VSS_GND_utility_0 = K5_VSS_GND.setState("K5_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K5_VSS_GND_utility_1 = K5_VSS_GND.setState("K5_1").setValue(1).setSettlingTime(0.02);

        ISetupUtility K4_ISET_PS = ds.addUtility("K4_ISET_PS");
        ISetupUtility.ISetState K4_ISET_PS_utility_0 = K4_ISET_PS.setState("K4_0").setValue(0).setSettlingTime(0.02);
        ISetupUtility.ISetState K4_ISET_PS_utility_1 = K4_ISET_PS.setState("K4_1").setValue(1).setSettlingTime(0.02);

        // Explicitly isolate/disconnect unused relays energized by prior tests
        ds.addUtility("K1_ISET_R24K").setValue(0);
        ds.addUtility("K2_ISET_R4K").setValue(0);
        ds.addUtility("K3_ISET_R2P4K").setValue(0);
        ds.addUtility("K6_VSS_PS").setValue(0);
        ds.addUtility("K7_SQM1_PS").setValue(0);
        ds.addUtility("K8_SQM1_C47UF").setValue(0);
        ds.addUtility("K9_VDD_PS").setValue(0);
        ds.addUtility("K10_VDDQ2_C47UF").setValue(0);
        ds.addUtility("K11_SQP4_GND").setValue(0);
        ds.addUtility("K12_SQP4_C47UF").setValue(0);
        ds.addUtility("K13_SQP1_PS").setValue(0);
        ds.addUtility("K14_TD_DPS").setValue(0);

        ISetupDcVI ioSignals = ds.addDcVI(allIoSignals);
        ioSignals.setConnect(true).setDisconnect(true);

        // Force 5.5 V on the selected I/O signal.
        ISetupDcVI.IVforce forceIo5p5V = ioSignals.vforce("force_io_5p5V")
                .setForceValue(5.5)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Force 0 V on selected I/O signals.
        ISetupDcVI.IVforce forceIo0V = ioSignals.vforce("force_io_0V")
                .setForceValue(0.0)
                .setIrange(0.025)
                .setIclamp(0.025);

        // Measure current on the selected I/O signal.
        ISetupDcVI.IImeas measureIoCurrent = ioSignals.imeas("measure_io_current")
                .setIrange(0.025);

        ds.sequentialBegin("ABSMAX");
        {
            // Dynamic relay control: connect VSS to GND, connect ISET to PS
            ds.actionCall(K5_VSS_GND_utility_1);
            ds.actionCall(K4_ISET_PS_utility_1);
            ds.waitCall(0.020);

            ds.parallelBegin("measure_vddq_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(SQPGroup + "+" + SQMGroup));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V");
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_55V", Arrays.asList(VDDQGroup));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_high_power_current", Arrays.asList(VDDQGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_sqp_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(SQMGroup));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V");
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_55V", Arrays.asList(SQPGroup + "+" + VDDQGroup));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_high_power_current", Arrays.asList(SQPGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_sqm_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(SQPGroup));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V");
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_55V", Arrays.asList(SQMGroup + "+" + VDDQGroup));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_high_power_current", Arrays.asList(SQMGroup));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_arm_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_5p5V", Arrays.asList("ARM_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_io_current", Arrays.asList("ARM_PS"));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V",
                            Arrays.asList("HFIRE_PS + LFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_lfire_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_5p5V", Arrays.asList("LFIRE_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_io_current", Arrays.asList("LFIRE_PS"));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V",
                            Arrays.asList("ARM_PS + HFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_hfire_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_5p5V", Arrays.asList("HFIRE_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_io_current", Arrays.asList("HFIRE_PS"));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V",
                            Arrays.asList("ARM_PS + LFIRE_PS + ISET_PS + TD_PS + TEST_PS"));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_iset_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_vdd_0V");
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_5p5V", Arrays.asList("ISET_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_io_current", Arrays.asList("ISET_PS"));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V",
                            Arrays.asList("ARM_PS + LFIRE_PS + HFIRE_PS + TD_PS + TEST_PS"));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_td_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_vdd_0V");
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_5p5V", Arrays.asList("TD_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_io_current", Arrays.asList("TD_PS"));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V",
                            Arrays.asList("ARM_PS + LFIRE_PS + HFIRE_PS + ISET_PS + TEST_PS"));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_test_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_5p5V", Arrays.asList("TEST_PS"));
                    ds.waitCall(0.020);
                    ds.actionCall("measure_io_current", Arrays.asList("TEST_PS"));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V",
                            Arrays.asList("ARM_PS + LFIRE_PS + HFIRE_PS + ISET_PS + TD_PS"));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            ds.parallelBegin("measure_vdd_absmax_current");
            {
                ds.sequentialBegin();
                {
                    ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_vdd_5p5V");
                    ds.waitCall(0.020);
                    ds.actionCall("measure_vdd_current");
                }
                ds.sequentialEnd();

                ds.sequentialBegin();
                {
                    ds.actionCall("force_io_0V", Arrays.asList(allIoSignals));
                }
                ds.sequentialEnd();
            }
            ds.parallelEnd();

            // Safe shutdown: return supplies and IOs to 0V before opening relays
            ds.actionCall("force_vdd_0V");
            ds.actionCall("force_high_power_0V", Arrays.asList(allHighPowerGroups));
            ds.actionCall("force_io_0V", Arrays.asList(allIoSignals));
            ds.waitCall(0.10);

            // Safe shutdown: turn off dynamic relays
            ds.actionCall(K5_VSS_GND_utility_0);
            ds.actionCall(K4_ISET_PS_utility_0);
            ds.waitCall(0.010);
        }
        ds.sequentialEnd();

        measurement.setSetups(ds);
    }

    @Override
    public void update() {
        // No runtime parameter updates are required.
    }

    @Override
    public void execute() {
        measurement.execute();

        Map<String, MultiSiteDoubleArray> vddqCurrentResults =
                measurement.dcVI(VDDQGroup).preserveResults().imeas("").getCurrent();

        Map<String, MultiSiteDoubleArray> sqpCurrentResults =
                measurement.dcVI(SQPGroup).preserveResults().imeas("").getCurrent();

        Map<String, MultiSiteDoubleArray> sqmCurrentResults =
                measurement.dcVI(SQMGroup).preserveResults().imeas("").getCurrent();

        Map<String, MultiSiteDoubleArray> ioAndVddCurrentResults =
                measurement.dcVI("ARM_PS + LFIRE_PS + HFIRE_PS + ISET_PS + TD_PS + TEST_PS + VDD_DPS")
                        .preserveResults()
                        .imeas("")
                        .getCurrent();

        println("\n<------- ABSMAX Test START ------->\n");

        MultiSiteDouble totalVddqCurrent =
                calculateAndPrintTotalCurrent("VDDQ", vddqCurrentResults);

        MultiSiteDouble totalSqpCurrent =
                calculateAndPrintTotalCurrent("SQP", sqpCurrentResults);

        MultiSiteDouble totalSqmCurrent =
                calculateAndPrintTotalCurrent("SQM", sqmCurrentResults);

        println("\nVDDQ Total Current: " + totalVddqCurrent + " A");
        println("SQP Total Current : " + totalSqpCurrent + " A");
        println("SQM Total Current : " + totalSqmCurrent + " A\n");

        int highPowerTestNumber = ptdDCHighP.getTestNumber();
        int ioTestNumber = ptdDCIO.getTestNumber();
        int testNumber = highPowerTestNumber;

        ptdDCHighP.setTestText("ABSMAX_VDDQ__VDDQ=55V_VDD=0V").setTestNumber(testNumber);
        ptdDCHighP.evaluate(totalVddqCurrent);
        testNumber += 10;

        ptdDCHighP.setTestText("ABSMAX_SQP__SQP=55V_VDD=0V_VDDQ=0V").setTestNumber(testNumber);
        ptdDCHighP.evaluate(totalSqpCurrent);
        testNumber += 10;

        ptdDCHighP.setTestText("ABSMAX_SQM__SQM=55V_VDD=0V_VDDQ=0V").setTestNumber(testNumber);
        ptdDCHighP.evaluate(totalSqmCurrent);
        testNumber += 10;

        String[] ioAndVddSignals = {"ARM_PS", "LFIRE_PS","HFIRE_PS","ISET_PS","TD_PS","TEST_PS","VDD_DPS" };

        for (String signalName : ioAndVddSignals) {
            MultiSiteDoubleArray signalCurrentResults = ioAndVddCurrentResults.get(signalName);

            MultiSiteDouble signalCurrent = signalCurrentResults.getElement(0);

            if(signalName.equals("VDD_DPS")) {
            ptdDCIO.setTestText("ABSMAX_VDD__VDD=5.5V_VDDQ=0V").setTestNumber(testNumber);
            ptdDCIO.evaluate(signalCurrent);
            }
            else {
                ptdDCIO.setTestText("ABSMAX_" + signalName + "__" + signalName + "=5.5V_VDD=0V_VDDQ=0V").setTestNumber(testNumber);
                ptdDCIO.evaluate(signalCurrent);

            }

            println(signalName + " Current: " + signalCurrent + " A");

            testNumber += 10;
        }

        ptdDCHighP.setTestText("ABSMAX_VDDQ__VDDQ=55V_VDD=0V").setTestNumber(highPowerTestNumber);
        ptdDCIO.setTestText("ABSMAX_IO__5.5V_0V_0V").setTestNumber(ioTestNumber);

        println("\n<------- ABSMAX Test END ------->\n");
    }

    /**
     * Prints individual signal currents and returns their total current per site.
     */
    private MultiSiteDouble calculateAndPrintTotalCurrent(
            String groupName,
            Map<String, MultiSiteDoubleArray> currentResults) {

        MultiSiteDouble totalCurrent = new MultiSiteDouble(0.0);

        println("---------- " + groupName + " Current Results ----------");

        for (int site : context.getActiveSites()) {
            double totalCurrentPerSite = 0.0;

            println("Site " + site + ":");

            for (Entry<String, MultiSiteDoubleArray> entry : currentResults.entrySet()) {
                String signalName = entry.getKey();
                double signalCurrent = entry.getValue().getElement(0).get(site);

                println("  " + signalName + " Current: " + signalCurrent + " A");
                totalCurrentPerSite += signalCurrent;
            }

            totalCurrent.set(site, totalCurrentPerSite);
            println("  " + groupName + " Total Current: " + totalCurrentPerSite + " A");
        }

        return totalCurrent;
    }
}
