Requirements:
     Python version - 3.8 or above
     Required modules
        pandas
        matplotlib

    User can either manually install these using pip install (eg:pip install pandas)
    or run the following command (while user is in the WaferMap directory)
    pip install -r requirements.txt

    Which will install all the required modules

Executing the script:
    Using Command prompt ->
            python python_file_path(main.py) -s ".sum file path" -d ".dsum.csv file path" -w ".wsum.csv file path"
        
    Using configuration in pycharm ->
        - Edit configuration
             Choose main.py file as the script in script path
             In the parameters section, add
            sum file path prefixed by -s separated by single space
            dsum csv file path prefixed by -d separated by single space
            wsum csv file path prefixed by -w separated by single space

            example:
                -s datalog_smartscale.sum -d datalog_smartscale.stdf.dsum.csv -w datalog_smartscale.stdf.wsum.csv
