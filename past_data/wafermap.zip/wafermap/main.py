import pandas as pd
import matplotlib.pyplot as plt
from xml.dom.minidom import Document



# Assign file paths

sum_file = "datalog_smartscale00.anoralabs.com_ibm93k_WP_25C_8IQY44001.04A0_20250327125647.sum"
dsum_file = "datalog_smartscale00.anoralabs.com_ibm93k_WP_25C_8IQY44001.04A0_20250327125647.stdf.dsum.csv"
wsum_file = "datalog_smartscale00.anoralabs.com_ibm93k_WP_25C_8IQY44001.04A0_20250327125647.stdf.wsum.csv"


def read_sum_file():
    """Extract ProductId and LotId from the .sum file."""
    with open(sum_file, "r") as f:
        lines = f.readlines()
        for line in lines:
            if "Product ID" in line:
                product = line.split(":")[-1].strip()
            if "Lot:" in line:
                lot = line.split(":")[-1].strip()
    return product, lot

product_id, lot_id = read_sum_file()
creation_date = (sum_file.split("_")[-1].strip(".sum")).ljust(16, '0')

txt_output = f"wafer_map_{lot_id}_{creation_date}.txt"
png_output = f"wafer_map_{lot_id}_{creation_date}.png"
xml_output = f"wafer_map_{lot_id}_{creation_date}.xml"
def map_hw_bin(hw_bin):
    """Map HW Bin values using a dictionary."""
    hw_bin_map = {"1": "001", "2": "001", "3": "002", "4": "002"}
    return hw_bin_map.get(str(hw_bin), "000")  # Default to "000" (Red)

def generate_hw_bin_grid():
    """Generate a text-based grid from the CSV file and save it to a txt file."""
    df = pd.read_csv(dsum_file)

    df[['X', 'Y']] = df['Device ID'].str.extract(r'W(\d+),(\d+)').astype(int)

    df['HW_Bin_Code'] = df['HW Bin'].apply(map_hw_bin)

    fail_count = (df["HW_Bin_Code"] == "000").sum()
    pass_count = (df["HW_Bin_Code"] == "001").sum()
    partial_pass_count = (df["HW_Bin_Code"] == "002").sum()
    grid = {}
    for column, row in df.iterrows():
        x, y, code = row['X'], row['Y'], row['HW_Bin_Code']
        grid[(x, y)] = code

    max_x = df['X'].max()
    max_y = df['Y'].max()

    grid_list = [
        [grid.get((x, y), "255") for x in range(1, max_x + 1)]
        for y in range(max_y, 0, -1)
    ]

    # **Save list to a text file**
    with open(txt_output, "w") as f:
        for row in grid_list:
            f.write(" ".join(row) + "\n")
    return fail_count, pass_count, partial_pass_count, grid_list

def create_wafer_map():
    """Create an image from the text file grid with a circular outline and cell borders."""
    with open(txt_output, "r") as f:
        lines = f.readlines()

    grid = [line.strip().split() for line in lines]

    # color map
    cmap = {"000": "#dc143c", "001": "#77dd77", "002": "#ffef00", "255": "white"}
    color_array = [[cmap.get(cell, "white") for cell in row] for row in grid]

    # Plot creation
    fig, ax = plt.subplots(figsize=(8,8))
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_frame_on(False)

    num_rows = len(grid)
    num_cols = len(grid[0])

    # To make each die rectangular
    cell_width = 0.7
    cell_height = 0.8


    wafer_radius = max(num_rows * cell_height, num_cols * cell_width) / 2
    center_x = num_cols * cell_width / 2
    center_y = num_rows * cell_height / 2

    for y in range(num_rows):
        for x in range(num_cols):
            color = color_array[y][x]
            inner_rect = plt.Rectangle(
                (x * cell_width, y * cell_height), cell_width, cell_height,
                facecolor=color,
                edgecolor='black' if color != 'white' else 'none',
                linewidth=1
            )
            ax.add_patch(inner_rect)

    # The circular outline
    wafer_circle = plt.Circle((center_x, center_y), wafer_radius * 1.14, color='black', fill=False, linewidth=2)
    ax.add_patch(wafer_circle)
    wafer_circle = plt.Circle((center_x, center_y), wafer_radius * 1.12, color='black', fill=False, linewidth=1)
    ax.add_patch(wafer_circle)

    # Axis limits to prevent cutting
    ax.set_xlim(-cell_width , num_cols * cell_width + cell_width)
    ax.set_ylim(-cell_height, num_rows * cell_height + cell_height)
    ax.set_aspect('equal')
    ax.invert_yaxis()  # To Match wafer coordinate system

    plt.savefig(png_output, bbox_inches='tight', pad_inches=0.3, dpi=300)

def create_xml():
    """Generate the XML file based on extracted data."""
    wsum_df = pd.read_csv(wsum_file)
    wafer_id = wsum_df["Wafer ID"].iloc[0]
    fail_count, pass_count, partial_pass_count, grid_list = generate_hw_bin_grid()
    create_wafer_map()

    # Create XML Document
    doc = Document()

    # Create <Map> as root
    root = doc.createElement("Map")
    root.setAttribute("xmlns:semi", "https://www.semi.org")
    root.setAttribute("WaferId", wafer_id)
    root.setAttribute("FormatRevision", "G85-1101")
    doc.appendChild(root)

    # Create <Device>
    device = doc.createElement("Device")
    device.setAttribute("ProductId", "BOREALIS_03JM894_IBM")
    device.setAttribute("LotId", lot_id)
    device.setAttribute("Orientation", "0")
    device.setAttribute("Row", "8")
    device.setAttribute("Columns", "10")
    device.setAttribute("StepSizeX", "25300")
    device.setAttribute("StepSizeY", "32100")
    device.setAttribute("MapType", "Array")
    device.setAttribute("BinType", "Decimal")
    device.setAttribute("NullBin", "255")
    device.setAttribute("CreateDate", creation_date)
    root.appendChild(device)

    # Create <Bin> elements
    for bin_code, count, quality, desc in [
        ("001", pass_count, "Pass", "Pass"),
        ("002", partial_pass_count, "Pass", "Partial Die"),
        ("000", fail_count, "Fail", "non-pickable site"),
    ]:
        bin_element = doc.createElement("Bin")
        bin_element.setAttribute("BinCode", bin_code)
        bin_element.setAttribute("BinCount", str(count))
        bin_element.setAttribute("BinQuality", quality)
        bin_element.setAttribute("BinDescription", desc)
        device.appendChild(bin_element)

    # Create <SupplierData>
    supplier_data = doc.createElement("SupplierData")
    supplier_data.setAttribute("ProductCode", "87")
    supplier_data.setAttribute("ToolType", "WFT")
    supplier_data.setAttribute("ToolTesterID", "30310")
    supplier_data.setAttribute("LogisticsToolId", "A4QA")
    supplier_data.setAttribute("ToolTCPIPNodeName", "a4Qa")
    supplier_data.setAttribute("RecipeName", "RVSI")
    supplier_data.setAttribute("CompositeRuleName1", "PATCSMFG")
    device.appendChild(supplier_data)

    # Create <Data>
    data = doc.createElement("Data")
    data.setAttribute("MapName", "MFG-PICK")
    data.setAttribute("MapVersion", "1")
    device.appendChild(data)

    # Add rows to <Data>
    for row_data in grid_list:
        row_element = doc.createElement("Row")
        cdata = doc.createCDATASection(" ".join(row_data))
        row_element.appendChild(cdata)
        data.appendChild(row_element)

    # Convert to formatted XML string
    xml_str = doc.toprettyxml(indent="  ")

    # Save to a file
    with open(xml_output, "w", encoding="utf-8") as f:
        f.write(xml_str)

    print(f"XML file generated: {xml_output}")


create_xml()



