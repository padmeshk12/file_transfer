export TESTER='VX4'
export PYTHONPATH='/projects/ti/prjdata/script/adv93k_py3/:/projects/ti/prjdata/script/adv93k_py3/TpSupport'
python3 /projects/ti/prjdata/script/adv93k_py3/TpSupport/fsInitData.py F751923B1.eva enums.evo MAIN_FLOW fsInitData_NOV28
