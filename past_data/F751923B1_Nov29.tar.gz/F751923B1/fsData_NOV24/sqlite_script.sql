
SELECT DISTINCT
    t2s.Test,
    pt.Pin,
    CASE
        WHEN pE.Edges > 1 THEN
            ROUND(1000.0 * (pE.Edges*1.0) / t.Period, 3)
        ELSE -- pE.Edges == 1 THEN
            ROUND(1000.0 / t.Period / (pt.ToggleDelta*1.0), 3)
    END AS Mbps,
    thp.PatAlias,
    pfn.PatFn,
    pt.PatFnPath,
    thp.PatSeq,
    z.PatGrp,
    z.WFTref,
    z.WFT,
    t.Category,
    t.Period,
    pt.ToggleDelta,
    pt.ToggleChars,
    pE.Edges
FROM Test2Seq AS t2s
    INNER JOIN Test2Cat AS t2c      ON t2c.Test      = t2s.Test
    INNER JOIN Threads_Pats AS thp  ON thp.PatSeq    = t2s.PatSeq
    INNER JOIN Zippers AS z         ON z.PatSeq      = thp.PatSeq
    INNER JOIN Pats_Filename AS pfn ON pfn.PatGrp    = z .PatGrp
                                   AND pfn.PatAlias  = thp.PatAlias
    INNER JOIN PatWFTrefs AS patwft ON patwft.WFTref = z.WFTref
                                   AND patwft.PatFn  = pfn.PatFn
    INNER JOIN Timing AS t          ON t.Category    = t2c.Category 
                                   AND t.WFT         = z.WFT
    INNER JOIN PinToggles AS pt     ON pt.PatFn      = pfn.PatFn
    INNER JOIN PinEdges AS pE       ON pE.WFT        = z.WFT
                                   AND pE.Pin        = pt.Pin
WHERE
    t.Period < 40 AND Mbps > 100;
