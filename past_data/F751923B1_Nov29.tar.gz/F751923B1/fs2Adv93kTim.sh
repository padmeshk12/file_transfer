export TESTER='VX4'
export PYTHONPATH='/projects/ti/prjdata/script/adv93k_py3/:/projects/ti/prjdata/script/adv93k_py3/TpSupport'
python3 /projects/ti/prjdata/script/adv93k_py3/TpSupport/fs2Adv93kTim.py -design F751923B1 -xls fsInitData_NOV28_wft.xls -eva F751923B1.eva -outdir fs2Adv93kTim_NOV28 -legacy fusion -test2spec fsInitData_NOV28_tim.xls -digital_mask DCSpecsMask  
