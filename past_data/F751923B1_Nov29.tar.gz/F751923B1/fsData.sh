python3 /projects/ti/prjdata/script/adv93k_py3/TpSupport/fsData.py -init F751923B1.eva_enums.evo_.init.evoTrans -tim fsInitData_NOV28_tim.xls -wft fsInitData_NOV28_wft.xls -out fsData_NOV28 Evos/*
