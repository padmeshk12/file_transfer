/* -------------------------------------------------------------------------
*
*MODULE     : private.c
*CREATED    : Sep-2025
*Author     : Arya Aji
*/

// system includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>

//module includes
#include "ph_tools.h"
#include "ph_log.h"
#include "ph_mhcom.h"
#include "ph_conf.h"
#include "ph_estate.h"
#include "ph_hfunc.h"
#include "private.h"
#include "ph_keys.h"
#include "gpib_conf.h"
#include "ph_hfunc_private.h"


#ifdef USE_DMALLOC
  #include "dmalloc.h"
#endif

#define MAX_HANDLER_ANSWER_LENGTH 5000
#define MAX_SITE_LENGTH 1
#define MAX_STRIP_ID_LENGTH 128

static char handlerSiteName[MAX_SITE_LENGTH][64] = {""};


static int localDelay_us(long microseconds){
    long seconds;
    struct timeval delay;

    if (microseconds >= 1000000L){
        seconds = microseconds / 1000000L;
        microseconds = microseconds % 1000000L;
    }
    else{
        seconds = 0;
    }

    
    delay.tv_sec = seconds;
    delay.tv_usec = microseconds;

    if (select(0, NULL, NULL, NULL, &delay) == -1 && errno == EINTR)
        return 0;
    else
        return 1;
    
}

// sending commands to place next device and waits
static phFuncError_t pollParts(phFuncId_t handlerID){
    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Entering into pollParts.....");
    phFuncError_t retVal = PHFUNC_ERR_OK;
    char handlerAnswer[MAX_HANDLER_ANSWER_LENGTH] = {'0'};
    char* localAnswer = 0;
    int flag = 0, count = 0;

    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "going to send place_next_device.....");
    

    //sending first command for place_next_device
    while(flag == 0){
        // starting place devices
        PhFuncTaCheck(phFuncTaSend(handlerID, "PLACE_NEXT_DEVICE%s", handlerID->p.eol));
        PhFuncTaCheck(phFuncTaReceive(handlerID, 1, "%s", handlerAnswer));

        if(strncmp(handlerAnswer, "PLACED", 6) == 0){
            count++;
            phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "device %d placed", count);
            continue;
        }
        else if(strncmp(handlerAnswer, "END_OF_SITE", 11) == 0){
            // all the sites are filled no sites available in the slot
            phLogFuncMessage(handlerID->)
        }
    }
    if(strncmp(handlerAnswer, "PLACED", 6) == 0){
        phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "One device placed in on the site.......");
        return PHFUNC_ERR_LOT_DONE;
    }

    PhFuncTaCheck(phFuncTaSend(handlerID, "press_down%s", handlerID->p.eol));
    PhFuncTaCheck(phFuncTaReceive(handlerID, 1, "%s", handlerAnswer));

    if(strncmp(handlerAnswer, "press_down completed", 20) == 0){
        phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Press down completed.......");
        return PHFUNC_ERR_DEVICE_START;
    }

    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Exiting from pollParts.......");
    return retVal;
}



// wait for parts to get the device
static phFuncError_t waitForParts(phFuncId_t handlerID){
    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Entering waitForParts.....");
    int i = 0;
    while (1)
    {
        if(i==5)
            return PHFUNC_ERR_WAITING;
        ++i;
        PhFuncTaCheck(pollParts(handlerID));
        if(!handlerID->p.oredDevicePending)
            localDelay_us(handlerID->p.pollingInterval);
        else
            break;

    }
    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Exit from waitForPart");
    
    return PHFUNC_ERR_OK;
    
}



static setupBinCode(phFuncId_t handlerID, long binNumber, char* thisBin){


    phFuncError_t retVal = PHFUNC_ERR_OK;
    if (handlerID->binIds){
        if (binNumber < 0 || binNumber >= handlerID->noOfBins){
            phLogFuncMessage(handlerID->myLogger, PHLOG_TYPE_ERROR,
            "invalid binning data. could not bin to bin index %ld \n"
        "maximum number of bins %d set by configuration %s",
        binNumber, handlerID->noOfBins, PHKEY_BI_HBIDS);
        return PHFUNC_ERR_BINNING;
        }
        
        int i_ret = strtol(handlerID->binIds[binNumber], (char **)NULL, 10);
        sprintf(thisBin, "%d", i_ret);
    }

    else{
        phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "using default bin map, handler bin id is %d", binNumber);
        sprintf(thisBin, "%ld", binNumber);
    }
    return retVal;

    // phFuncError_t retVal = PHFUNC_ERR_OK;
    // if (handlerID->binIds){
    //     if (binNumber < 0 || binNumber >= handlerID->noOfSites){
    //     phLogFuncMessage(handlerID->myLogger, PHLOG_TYPE_ERROR,
    //     "invalid binning data, could not bin to bin index %ld\n"
    //     "max number of bins %d set by configuration %s",
    //     binNumber, handlerId->noOfBins, PHKEY_BI_HBIDS);
    //     return PHFUNC_ERR_BINNING;
    // }
    // int i_ret = strtol(handlerID->binIds[binNumber], (char **)NULL, 10);
    // sprintf(thisBin, "%d", i_ret);
    // }

    // else{
    //     phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "using default bin map, handler bin id is %d", binNumber);
    //     sprintf(thisBin, "%ld", binNumber)
    // }
    // return retVal

}


static phFuncError_t binAndReprobe(
    phFuncId_t handlerID, // driver plug-in id
    phEstateSiteUsage_t *oldPopulation, // current site population
    long *perSiteReprobe, // True if a device needs reprobe
    long *perSiteBinMap // valid binning data for each site where the site above reprobe flag is not set
    ){

        phFuncError_t retVal = PHFUNC_ERR_OK;
        char thisBin[64] = "";
        char tmpHandlerAnswer[128] = "";
        char testResult[MAX_HANDLER_ANSWER_LENGTH] = "";
        int sendBinning = 0, i=0;
        strcpy(testResult, "RETURN_DEVICE ");
        switch (handlerID->model)
        {
        case PHFUNC_MOD_Athena:
            for(i=0; i<handlerID->noOfSites; ++i){
                if (handlerID->activeSites[i] && (oldPopulation[i] == PHESTATE_SITE_POPULATED ||
                oldPopulation[i] == PHESTATE_SITE_POPDEACT)){
                    retVal = setupBinCode(handlerID, perSiteBinMap[i], thisBin);
                    if (retVal==PHFUNC_ERR_OK){
                        strcat(testResult, thisBin)
                        sendBinning = 1;
                    }
                    else{
                        phLogFuncMessage(handlerID->myLogger, PHLOG_TYPE_ERROR, "unable to send binning at site");
                        sendBinning = 0;
                    }
                }
            }
            break;
        
        default:
            break;
        }




        // int site =-1;
        // int i, populatedCount = 0;
        
        // // finding one populated site from the estate

        // for (i=0; i <handlerID->noOfSites; ++i){
        //     if(!handlerID->activeSites[i])
        //         continue;
        //     if(oldPopulation[i] == PHESTATE_SITE_POPULATED || 
        //         oldPopulation[i] == PHESTATE_SITE_POPDEACT ){
        //             site = i;
        //             populatedCount++;
        //             if (populatedCount > 1)
        //                 break;
        //         }
        // }

    // unable to identify any populated sites

    if(populatedCount != 1 || site <0){
        phLogFuncMessage(handlerID->myLogger, PHLOG_TYPE_ERROR, "expected one site but none identified");
        return PHFUNC_ERR_BINNING;
    }

    // mapping tester bin and handler bin
    setupBinCode(handlerID, perSiteBinMap[site], thisBin);

    handlerID->p.isNewStripOptional = 0;

    if(sendBinning)

}


#ifdef INIT_IMPLEMENTED
/*

Handler Driver initialization logic

*/

phFuncError_t privateInit(phFuncId_t handlerID){
    phFuncError_t retVal = PHFUNC_ERR_OK;
    int i = 0;
    // abort in case of unsuccessful retry
    if (phFuncTaAskAbort(handlerID))
        return PHFUNC_ERR_ABORTED;
    handlerID->p.sites = handlerID->noOfSites;
    for (i=0; i< handlerID->p.sites; i++){
        handlerID->p.siteUsed[i] = handlerID->activeSites[i];
        handlerID->p.devicePending[i] = 0;
    }
    
    handlerID->p.strictPolling = 1; //act as server
    handlerID->p.pollingInterval = 2000000L;
    handlerID->p.oredDevicePending = 0;
    handlerID->p.status = 0L;
    handlerID->p.paused = 0;
    handlerID->p.deviceGot;
    strcpy(handlerID->p.eol, "\r\n");

    /*
    */

    sleep(1);

    return retVal;
}
#endif


// #ifdef RECONFIGURE_IMPLEMENTED

// phFuncError_t privateReconfigure(phFuncId_t handlerID){
//     phFuncError_t retVal = PHFUNC_ERR_OK;
//     // abort in case of failure
//     if (phFuncTaAskAbort(handlerID))
//         return PHFUNC_ERR_ABORTED;
    
//         phFuncTaStart(handlerID);
//         PhFuncTaCheck(doReconfigure(handlerID));
//         phFuncTaStop(handlerID);
//     return retVal;
// }
// #endif

#ifdef GETSTART_IMPLEMENTED

phFuncError_t privateGetStart(phFuncId_t handlerID){
    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Entering into GETSTART");
    phEstateSiteUsage_t population[PHESTATE_MAX_SITES];

    if (phFuncTaAskAbort(handlerID))
        return PHFUNC_ERR_ABORTED;
    if(handlerID->p.deviceGot){
        phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "device has got new part");
        return PHFUNC_ERR_OK;
    }

    phFuncTaStart(handlerID);

    phFuncTaMarkStep(handlerID);

    waitForParts(handlerID);


    // checks atleat one part required, asking for the current status and return with waiting
    if (!handlerID->p.oredDevicePending){
        // during next call everything upto here should be repeated
        phFuncTaRemoveToMark(handlerID);
        return PHFUNC_ERR_WAITING;
    }

    phFuncTaStop(handlerID);

    // received devices for testing, changing equ state

    int i = 0;
    handlerID->p.oredDevicePending = 0;


    for (i = 0; i < handlerID->noOfSites; i++){

        // checks site active or not
        if (handlerID->activeSites[i] == 1){

            // checks if there is a device placed if yes then site state will be changed to populated else changes to empty site
            if(handlerID->p.devicePending[i]){
                handlerID->p.devicePending[i] = 0;
                population[i] = PHESTATE_SITE_POPULATED;

            }
            else
                population[i] = PHESTATE_SITE_EMPTY;
        }
        else{
            // site active but we got a device on inactive site
            if (handlerID->p.devicePending[i])
                phLogFuncMessage(handlerID->myLogger, PHLOG_TYPE_ERROR, "received device for inactive site \"%s\"......", handlerID->siteIds[i]);
            population[i] = PHESTATE_SITE_DEACTIVATED;
        }
    }

    handlerID->p.deviceGot = 1;
    phEstateASetSiteInfo(handlerID->myEstate, population, handlerID->noOfSites);
    phLogFuncMessage(handlerID->myLogger, LOG_DEBUG, "Exiting from GETSTART........");
    

    return PHFUNC_ERR_OK;

}
#endif


#ifdef BINDEVICE_IMPLEMENTED
/*
Tested device binning logic implementation

*/

phFuncError_t privateBinDevice(
    phFuncId_t handlerID, 
    long *perSiteBinMap) {
    phEstateSiteUsage_t *oldPopulation;
    int entries;
    phEstateSiteUsage_t population[PHESTATE_MAX_SITES];
    int i;

    //aborting: on unsuccessful retry
    if (phFuncTaAskAbort(handlerID)){
        return PHFUNC_ERR_ABORTED;
    }
    
    // get current site population
    phEstateAGetSiteInfo(handlerID->myEstate, &oldPopulation, &entries);

    phFuncTaStart(handlerID);

    PhFuncTaCheck(binAndReprobe(handlerID, oldPopulation, NULL, perSiteBinMap));
    phFuncTaStop(handlerID);


    // modify the site population, upto here everything should be working well, else some errors must be raised

    for (i=0; i < handlerID->noOfSites; i++){
        if (handlerID->activeSites[i] && (oldPopulation[i] == PHESTATE_SITE_POPULATED || oldPopulationp[i] == PHESTATE_SITE_POPDEACT))
            population[i] = oldPopulation[i] == PHESTATE_SITE_POPULATED ? PHESTATE_SITE_EMPTY : PHESTATE_SITE_DEACTIVATED;
        else
            population[i] = oldPopulation;
    }

    handlerID->p.deviceGot = 0;

    // change site population
    phEstateASetSiteInfo(handlerID->myEstate,  population, handlerID->noOfSites);
    return PHFUNC_ERR_OK;

}
