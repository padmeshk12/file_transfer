"""
Module: main.py
Date: 09-10-2025
Author: Arya Aji
"""


# This is a customised TCP server + websocket client
# Made specifically for the v93k tester
# Do not made any changes in here
# This will accept messages from the tester/tcp client and send it to the Athena handler
# Here it will take care of the lift_up, no need to send lift up command from the tester.
# If the command from the tester is return_device then it will send a lift_up command to handler
# then only send the return device command with bin number to handler



import socket
from websockets.sync.client import connect
allow_connection_creation = {'status': True}


def athena_tcp_server():
    """
    this is method will accept messages from the tester and send them to handler

    :return:
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as soc:
        soc.bind(('localhost', 9000))
        soc.listen(1)
        print("server is listening on port 9000")
        conn, addr = soc.accept()
        print("connection is established")

        if allow_connection_creation:

            with connect("ws://localhost:8000/ws") as client:
                allow_connection_creation['status'] = False

                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    print(f"Received: {data.decode()}")
                    data = data.decode()
                    return_device_check = data.split()
                    if return_device_check[0] == "RETURN_DEVICE":
                        client.send("LIFT_UP")
                        response = client.recv(1024)
                        print(response)
                    client.send(data)
                    response = client.recv()
                    conn.send(response.encode())
                    print(response)

if __name__ == '__main__':
    athena_tcp_server()