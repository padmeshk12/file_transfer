"""
Module: main.py
Date: 09-10-2025
Author: Arya Aji
"""


# this is a simple simulator which act as the Athena handler
# in the absence of the actual handler this will act as the websocket server
# also it will respond back to the tester


import uvicorn
from astroid.bases import manager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from typing import List

from starlette import status

app = FastAPI()

handler_status = {"PLACE_NEXT_DEVICE": False, "press_down": False, "lift_up": False, "return_device": False}


class ConnectionManager:
    """connection manager class for websocket communication"""

    ALLOW_MULTI_CONNECTION = False

    def __init__(self):
        self.active_connections: List[WebSocket] = []


    async def connect(self, websocket: WebSocket):
        """connect"""
        if not ConnectionManager.ALLOW_MULTI_CONNECTION and self.active_connections:
            await websocket.close(code=status.WS_1000_NORMAL_CLOSURE, reason="Multiple connection is restricted")
            raise RuntimeError("Multiple connection is restricted")
        else:
            await websocket.accept()
            self.active_connections.append(websocket)

    async def disconnect(self, websocket: WebSocket):
        """disconnect"""
        await websocket.close()
        self.active_connections.remove(websocket)

    async def remove_connection(self, websocket: WebSocket):
        self.active_connections.remove(websocket)



manager =  ConnectionManager()

@app.websocket('/ws')
async def websocket_endpoint(websocket: WebSocket):
    web_manager = manager
    await web_manager.connect(websocket)

    try:
        while True:
            data = await websocket.receive_text()

            data = data.split()[0]

            if data == "PLACE_NEXT_DEVICE" and handler_status["PLACE_NEXT_DEVICE"] is False:
                handler_status["PLACE_NEXT_DEVICE"] = True
                await websocket.send_text("PLACED")
            elif data == "PLACE_NEXT_DEVICE" and handler_status["PLACE_NEXT_DEVICE"]:
                await websocket.send_text("END_OF_SITE")
            elif data == "press_down" and handler_status["press_down"] is False:
                handler_status["press_down"] = True
                await websocket.send_text("press_down completed")
            elif data == "LIFT_UP" and handler_status["lift_up"] is False:
                handler_status["lift_up"] = True
                await websocket.send_text("lift_up completed")
            elif data == "RETURN_DEVICE" and handler_status["return_device"] is False:
                handler_status["return_device"] = True
                await websocket.send_text("return_device completed")

    except Exception as e:
        print(str(e))



if __name__ == "__main__":
    uvicorn.run(
        app,
        host='127.0.0.1',
        reload=False,
        port=8000,
    )