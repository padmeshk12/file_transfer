"""
Module: main.py
Date: 09-10-2025
Author: Arya Aji
"""


# A skeleton TCP server + websocket client
# Can take this as a reference, and copy and modify for the custom TCP servers based on Tester requirements


import socket
from websockets.sync.client import connect
allow_connection_creation = {'status': True}


def client_connect():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as soc:
        soc.bind(('localhost', 9000))
        soc.listen(1)
        print("server is listening on port 9000")
        conn, addr = soc.accept()
        print("connection is established")

        if allow_connection_creation:

            with connect("ws://localhost:8000/ws") as client:
                allow_connection_creation['status'] = False

                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    print(f"Received: {data.decode()}")
                    data = data.decode()
                    client.send(data)
                    response = client.recv()
                    conn.send(response.encode())
                    print(response)

if __name__ == '__main__':
    client_connect()