"""
Module: main.py
Date: 09-10-2025
Author: Arya Aji
"""

# this module act as a tcp client
# add your commands to send to handler,
# created to act as a tester

import socket

def tcp_client():
    """
    It's a simple TCP client, can modify
    :return:
    """
    tcp_server_add = ("127.0.0.1", 9000)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as soc:
        soc.connect(tcp_server_add)
        try:

            # place next device command sending and response printing
            message = "PLACE_NEXT_DEVICE"
            print(f'Sending "{message}"')
            soc.send(message.encode())
            response = soc.recv(1024)
            print(f'Received "{response.decode()}"')

            # trying to resend place next device command sending and response printing
            message = "PLACE_NEXT_DEVICE"
            print(f'Sending "{message}"')
            soc.send(message.encode())
            response = soc.recv(1024)
            print(f'Received "{response.decode()}"')

            # press down command sending and response printing
            message = "press_down"
            print(f'Sending "{message}"')
            soc.send(message.encode())
            response = soc.recv(1024)
            print(f'Received "{response.decode()}"')

            # return device command sending and response printing
            message = "RETURN_DEVICE 3"
            print(f'Sending "{message}"')
            soc.send(message.encode())
            response = soc.recv(1024)
            print(f'Received "{response.decode()}"')



        finally:
            print(f'Closing socket')
            soc.close()


if __name__ == '__main__':
    tcp_client()