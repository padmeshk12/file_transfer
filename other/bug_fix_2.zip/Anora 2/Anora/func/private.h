
/*
*/
#ifndef _PRIVATE_H_
#define _PRIVATE_H_


#define INIT_IMPLEMENTED
#define GETSTART_IMPLEMENTED
#define RECONFIGURE_IMPLEMENTED
// #define STRIPSTART_IMPLEMENTED
// #define STRIPDONE_IMPLEMENTED
// #define BINDEVICE_IMPLEMENTED
// #define REPROBE_IMPLEMENTED
// #define BINREPROBE_IMPLEMENTED
// #define LOTSTART_IMPLEMENTED
// #define LOTDONE_IMPLEMENTED
// #define GETSTATUS_IMPLEMENTED
// #define SETSTATUS_IMPLEMENTED

struct pluginPrivate{
    int sites;
    int siteUsed[PHESTATE_MAX_SITES];
    int pollingInterval;
    int devicePending[PHESTATE_MAX_SITES];
    int oredDevicePending;

    char eol[4];
    int deviceGot;
    int strictPolling;
    long status;
    int isNewStripOptional;


};


//external functions

#ifdef INIT_IMPLEMENTED
/*
1. initialize handler specific plugin
*/ 
phFuncError_t privateInit(phFuncId_t handlerID);
#endif

#ifdef GETSTART_IMPLEMENTED
/*
place next device and press_down implementations
*/
phFuncError_t privateGetStart( phFuncId_t handlerID);
#endif


#ifdef RECONFIGURE_IMPLEMENTED
/*
reconfigure driver plugin
*/
phFuncError_t privateReconfigure(phFuncId_t handlerID);
#endif