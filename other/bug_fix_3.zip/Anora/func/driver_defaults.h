#ifndef _DRIVER_DEFAULTS_H_
#define _DRIVER_DEFAULTS_H_

#include "gpib_conf.h"

enum handlerModel
{
 PHFUNC_MOD_Athena,
 PHFUNC_MOD__END   
};

struct modelDef
{
    enum handlerModel model;
    const char *name;
};

void phFuncPredefModels(
    char **family,
    struct modelDef **models    
);

#endif

