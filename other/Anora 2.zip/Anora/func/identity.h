#define PHFUNC_IDENT "Athena PnP Handler Driver Plugin"
#define PHFUNC_DATE ""
#define PHFUNC_REVISION ""
#undef PHFUNC_LOCAL