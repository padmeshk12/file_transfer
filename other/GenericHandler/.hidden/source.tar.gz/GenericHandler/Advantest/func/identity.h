#define PHFUNC_IDENT "Advantest Handler Driver Plugin"
#define PHFUNC_DATE "Tue Aug 6 05:20:47 CEST 2024"
#define PHFUNC_REVISION "8.6.4.2"
#undef PHFUNC_LOCAL
