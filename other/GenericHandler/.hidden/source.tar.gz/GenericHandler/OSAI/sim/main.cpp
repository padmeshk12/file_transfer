#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    cout << "please use windows simulator for instead of!" << endl;
}
