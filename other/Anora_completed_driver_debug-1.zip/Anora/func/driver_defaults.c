#include "ph_mhcom.h"
#include "ph_estate.h"
#include "ph_hfunc.h"
#include "gpib_conf.h"
#include "driver_defaults.h"

#ifdef USE_DMALLOC
    #include "dmalloc.h"
#endif


void phFuncPredefModels(
    char **family,
    struct  modelDef **models    
)
{
    static char myFamily[] = "Anora";
    static struct modelDef myModels[] = 
    {
        {PHFUNC_MOD_Athena, "Athena"},
        {PHFUNC_MOD__END, ""}
    };
    *family = myFamily;
    *models = myModels;
    
}
