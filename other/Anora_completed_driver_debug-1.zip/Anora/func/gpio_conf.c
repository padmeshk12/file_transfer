/******************************************************************************
 *
 *       (c) Copyright HEWLETT-PACKARD GmbH, Boeblingen 1999
 *
 *-----------------------------------------------------------------------------
 *
 * MODULE   : gpio_conf.c
 * CREATED  : 05 Aug 1999
 *
 * CONTENTS : Configuration of GPIO specific parts
 *
 * AUTHORS  : Michael Vogt, SSTD-R&D, initial revision
 *
 *-----------------------------------------------------------------------------
 *
 * HISTORY  : 05 Aug 1999, Michael Vogt, created
 *
 * Instructions:
 *
 * 1) Copy this template to as many .c files as you require
 *
 * 2) Use the command 'make depend' to make visible the new
 *    source files to the makefile utility
 *
 *****************************************************************************/

/*--- system includes -------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*--- module includes -------------------------------------------------------*/

#include "ph_tools.h"

#include "ph_log.h"
#include "ph_mhcom.h"
#include "ph_conf.h"
#include "ph_estate.h"
#include "ph_hfunc.h"

#include "ph_keys.h"
#include "gpio_conf.h"
#include "driver_defaults.h"
#include "ph_hfunc_private.h"
/* Begin of Huatek Modifications, Charley Cao, 03/08/2002 */
/* Issue Number: 335 */
/* NOTE: dmalloc.h should always be the last file in the list of files to be included! */
#ifdef USE_DMALLOC
  #include "dmalloc.h"
#endif
/* End of Huatek Modifications */

/*--- defines ---------------------------------------------------------------*/

/*--- typedefs --------------------------------------------------------------*/

/*--- functions -------------------------------------------------------------*/

static enum gpioPolarity getConfPolarity(
    struct phFuncStruct *myself, char *key, enum gpioPolarity defVal)
{
    enum gpioPolarity result = defVal;
    char *paramString;
    int notExist = 0;
    int isWrong = 0;
    int notUnderstood = 0;

    /* read the polarity for the given key, may be 'negative' or 'positive' */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfString(myself->myConf, key, 0, NULL, &paramString) == 
	    PHCONF_ERR_OK)
	{
	    if (strcasecmp(paramString, "negative") == 0)
		result = PHFUNC_GPIO_POL_NEG;
	    else if (strcasecmp(paramString, "positive") == 0)
		result = PHFUNC_GPIO_POL_POS;
	    else
		notUnderstood = 1;
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, assuming %s polarity", key,
	    result == PHFUNC_GPIO_POL_POS ? "positive" : "negative");

    if (isWrong || notUnderstood)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter '%s' not understood, assuming %s polarity", key,
	    result == PHFUNC_GPIO_POL_POS ? "positive" : "negative");
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' accepted to be '%s'", key, 
	result == PHFUNC_GPIO_POL_POS ?	"positive" : "negative");

    return result;
}

static long getConfUsecTiming(
    struct phFuncStruct *myself, char *key, 
    int confPower /* configured time is given in [seconds * 10^confPower] */, 
    long defVal /* default value in usec */)
{
    long result = defVal;
    double paramDouble;
    int notExist = 0;
    int isWrong = 0;
    const int targetPower = -6; /* result must be in usec */

    /* read the time value for the given key */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfNumber(myself->myConf, key, 0, NULL, &paramDouble) == 
	    PHCONF_ERR_OK)
	{
	    /* convert the configured value to usec */
	    while (confPower > targetPower)
	    {
		paramDouble *= 10.0;
		confPower--;
	    }
	    while (confPower < targetPower)
	    {
		paramDouble /= 10.0;
		confPower++;
	    }
	    result = (long) paramDouble;
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, using %ld usec (converted)", 
	    key, result);

    if (isWrong)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter '%s' not understood, using %ld usec (converted)", 
	    key, result);
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' accepted to be %ld usec (converted)", 
	key, result);

    return result;
}

static enum gpioWaveform getConfGpioWf(
    struct phFuncStruct *myself, char *key, enum gpioWaveform defVal)
{
    enum gpioWaveform result = defVal;
    char *paramString;
    int notExist = 0;
    int isWrong = 0;
    int notUnderstood = 0;

    /* read the waveform for the given key, may be 'pulse' or 'static' */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfString(myself->myConf, key, 0, NULL, &paramString) == 
	    PHCONF_ERR_OK)
	{
	    if (strcasecmp(paramString, "pulse") == 0)
		result = PHFUNC_GPIO_WF_PULSE;
	    else if (strcasecmp(paramString, "static") == 0)
		result = PHFUNC_GPIO_WF_STATIC;
	    else
		notUnderstood = 1;
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, assuming waveform '%s'", key,
	    result == PHFUNC_GPIO_WF_PULSE ? "pulse" : "static");

    if (isWrong || notUnderstood)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter '%s' not understood, assuming waveform '%s'", key,
	    result == PHFUNC_GPIO_WF_PULSE ? "pulse" : "static");
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' accepted to be '%s'", key, 
	result == PHFUNC_GPIO_WF_PULSE ? "pulse" : "static");

    return result;
}

static enum gpioBinMode getConfBinMode(
    struct phFuncStruct *myself, char *key, enum gpioBinMode defVal)
{
    enum gpioBinMode result = defVal;
    char *paramString;
    int notExist = 0;
    int isWrong = 0;
    int notUnderstood = 0;

    /* read the waveform for the given key, may be 'serial' or 'parallel' */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfString(myself->myConf, key, 0, NULL, &paramString) == 
	    PHCONF_ERR_OK)
	{
	    if (strcasecmp(paramString, "serial") == 0)
		result = PHFUNC_GPIO_BM_SERIAL_EOT;
	    else if (strcasecmp(paramString, "parallel") == 0)
		result = PHFUNC_GPIO_BM_PARALLEL_EOT;
	    else
		notUnderstood = 1;
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, assuming %s mode", key,
	    (result == PHFUNC_GPIO_BM_SERIAL_EOT ||
		result == PHFUNC_GPIO_BM_SERIAL_NO_EOT) ? 
	    "serial" : "parallel");

    if (isWrong || notUnderstood)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter '%s' not understood, assuming %s mode", key,
	    (result == PHFUNC_GPIO_BM_SERIAL_EOT ||
		result == PHFUNC_GPIO_BM_SERIAL_NO_EOT) ? 
	    "serial" : "parallel");
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' accepted to be '%s'", key, 
	    (result == PHFUNC_GPIO_BM_SERIAL_EOT ||
		result == PHFUNC_GPIO_BM_SERIAL_NO_EOT) ? 
	    "serial" : "parallel");

    return result;
}

static enum gpioBinCoding getConfBinCoding(
    struct phFuncStruct *myself, char *key, enum gpioBinCoding defVal)
{
    enum gpioBinCoding result = defVal;
    char *paramString;
    int notExist = 0;
    int isWrong = 0;
    int notUnderstood = 0;

    /* read the waveform for the given key, may be 'encoded' or 'explicit' */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfString(myself->myConf, key, 0, NULL, &paramString) == 
	    PHCONF_ERR_OK)
	{
	    if (strcasecmp(paramString, "encoded") == 0)
		result = PHFUNC_GPIO_BC_ENCODED;
	    else if (strcasecmp(paramString, "explicit") == 0)
		result = PHFUNC_GPIO_BC_EXPLICIT;
	    else
		notUnderstood = 1;
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, assuming %s mode", key,
	    result == PHFUNC_GPIO_BC_ENCODED ? "encoded" : "explicit");

    if (isWrong || notUnderstood)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter '%s' not understood, assuming %s mode", key,
	    result == PHFUNC_GPIO_BC_ENCODED ? "encoded" : "explicit");
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' accepted to be '%s'", key, 
	    result == PHFUNC_GPIO_BC_ENCODED ? "encoded" : "explicit");

    return result;
}

static int getConfAcceptEmptyBin(
    struct phFuncStruct *myself, char *key, int defVal)
{
    int result = defVal;
    int notExist = 0;
    int isWrong = 0;
    phConfType_t defType;
    int length;

    /* check whether the key is an empty list */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	length = -1;
	if (phConfConfType(myself->myConf, key, 0, NULL, 
	    &defType, &length) == PHCONF_ERR_OK &&
	    defType == PHCONF_TYPE_LIST)
	{
	    result = (length == 0) ? 1 : 0;
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, %s empty bin codes", key,
	    result == 0 ? "not accepting" : "accepting");

    if (isWrong)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter '%s' not understood, %s empty bin codes", key,
	    result == 0 ? "not accepting" : "accepting");
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' leads to %s empty bin codes", key, 
	    result == 0 ? "not accepting" : "accepting");

    return result;
}

static char *gpioILineToStr(phComGpioILine_t line)
{
    static char result[20];

    switch (line)
    {
      case PHCOM_GPIO_DI_0 : strcpy(result, "DI0"); break;
      case PHCOM_GPIO_DI_1 : strcpy(result, "DI1"); break;
      case PHCOM_GPIO_DI_2 : strcpy(result, "DI2"); break;
      case PHCOM_GPIO_DI_3 : strcpy(result, "DI3"); break;
      case PHCOM_GPIO_DI_4 : strcpy(result, "DI4"); break;
      case PHCOM_GPIO_DI_5 : strcpy(result, "DI5"); break;
      case PHCOM_GPIO_DI_6 : strcpy(result, "DI6"); break;
      case PHCOM_GPIO_DI_7 : strcpy(result, "DI7"); break;
      case PHCOM_GPIO_DI_8 : strcpy(result, "DI8"); break;
      case PHCOM_GPIO_DI_9 : strcpy(result, "DI9"); break;
      case PHCOM_GPIO_DI_10: strcpy(result, "DI10"); break;
      case PHCOM_GPIO_DI_11: strcpy(result, "DI11"); break;
      case PHCOM_GPIO_DI_12: strcpy(result, "DI12"); break;
      case PHCOM_GPIO_DI_13: strcpy(result, "DI13"); break;
      case PHCOM_GPIO_DI_14: strcpy(result, "DI14"); break;
      case PHCOM_GPIO_DI_15: strcpy(result, "DI15"); break;
      case PHCOM_GPIO_STL_0: strcpy(result, "STI0"); break;
      case PHCOM_GPIO_STL_1: strcpy(result, "STI1"); break;
      case PHCOM_GPIO_EIR  : strcpy(result, "EIR"); break;
      default:               strcpy(result, "NONE"); break;
    }
    return result;
}

static char *gpioOLineToStr(phComGpioOLine_t line)
{
    static char result[20];

    switch (line)
    {
      case PHCOM_GPIO_DO_0 : strcpy(result, "DO0"); break;
      case PHCOM_GPIO_DO_1 : strcpy(result, "DO1"); break;
      case PHCOM_GPIO_DO_2 : strcpy(result, "DO2"); break;
      case PHCOM_GPIO_DO_3 : strcpy(result, "DO3"); break;
      case PHCOM_GPIO_DO_4 : strcpy(result, "DO4"); break;
      case PHCOM_GPIO_DO_5 : strcpy(result, "DO5"); break;
      case PHCOM_GPIO_DO_6 : strcpy(result, "DO6"); break;
      case PHCOM_GPIO_DO_7 : strcpy(result, "DO7"); break;
      case PHCOM_GPIO_DO_8 : strcpy(result, "DO8"); break;
      case PHCOM_GPIO_DO_9 : strcpy(result, "DO9"); break;
      case PHCOM_GPIO_DO_10: strcpy(result, "DO10"); break;
      case PHCOM_GPIO_DO_11: strcpy(result, "DO11"); break;
      case PHCOM_GPIO_DO_12: strcpy(result, "DO12"); break;
      case PHCOM_GPIO_DO_13: strcpy(result, "DO13"); break;
      case PHCOM_GPIO_DO_14: strcpy(result, "DO14"); break;
      case PHCOM_GPIO_DO_15: strcpy(result, "DO15"); break;
      case PHCOM_GPIO_CTL_0: strcpy(result, "CTL0"); break;
      case PHCOM_GPIO_CTL_1: strcpy(result, "CTL1"); break;
      default:               strcpy(result, "NONE"); break;
    }
    return result;
}

static phComGpioILine_t gpioStrToILine(char *line)
{
    phComGpioILine_t result = (phComGpioILine_t) 0;
    int lineNumber;

    if (sscanf(line, "DI%d", &lineNumber) == 1)
	/* explicitely switch on line number and do not try to
	   calculate the correct enum value, since its
	   definition may change */
	switch (lineNumber)
	{
	  case 0: result =  PHCOM_GPIO_DI_0;  break;
	  case 1: result =  PHCOM_GPIO_DI_1;  break;
	  case 2: result =  PHCOM_GPIO_DI_2;  break;
	  case 3: result =  PHCOM_GPIO_DI_3;  break;
	  case 4: result =  PHCOM_GPIO_DI_4;  break;
	  case 5: result =  PHCOM_GPIO_DI_5;  break;
	  case 6: result =  PHCOM_GPIO_DI_6;  break;
	  case 7: result =  PHCOM_GPIO_DI_7;  break;
	  case 8: result =  PHCOM_GPIO_DI_8;  break;
	  case 9: result =  PHCOM_GPIO_DI_9;  break;
	  case 10: result = PHCOM_GPIO_DI_10; break;
	  case 11: result = PHCOM_GPIO_DI_11; break;
	  case 12: result = PHCOM_GPIO_DI_12; break;
	  case 13: result = PHCOM_GPIO_DI_13; break;
	  case 14: result = PHCOM_GPIO_DI_14; break;
	  case 15: result = PHCOM_GPIO_DI_15; break;
	  default: break;
	}
    else if (sscanf(line, "STI%d", &lineNumber) == 1)
	/* explicitely switch on line number and do not try to
	   calculate the correct enum value, since its
	   definition may change */
	switch (lineNumber)
	{
	  case 0: result = PHCOM_GPIO_STL_0; break;
	  case 1: result = PHCOM_GPIO_STL_1; break;
	  default: break;
	}
    else if (strcmp(line, "EIR") == 0)
	result =  PHCOM_GPIO_EIR;

    /* if not parsed, returning with empty value */
    return result;
}

static phComGpioOLine_t gpioStrToOLine(char *line)
{
    phComGpioOLine_t result = (phComGpioOLine_t) 0;
    int lineNumber;

    if (sscanf(line, "DO%d", &lineNumber) == 1)
	/* explicitely switch on line number and do not try to
	   calculate the correct enum value, since its
	   definition may change */
	switch (lineNumber)
	{
	  case 0: result =  PHCOM_GPIO_DO_0;  break;
	  case 1: result =  PHCOM_GPIO_DO_1;  break;
	  case 2: result =  PHCOM_GPIO_DO_2;  break;
	  case 3: result =  PHCOM_GPIO_DO_3;  break;
	  case 4: result =  PHCOM_GPIO_DO_4;  break;
	  case 5: result =  PHCOM_GPIO_DO_5;  break;
	  case 6: result =  PHCOM_GPIO_DO_6;  break;
	  case 7: result =  PHCOM_GPIO_DO_7;  break;
	  case 8: result =  PHCOM_GPIO_DO_8;  break;
	  case 9: result =  PHCOM_GPIO_DO_9;  break;
	  case 10: result = PHCOM_GPIO_DO_10; break;
	  case 11: result = PHCOM_GPIO_DO_11; break;
	  case 12: result = PHCOM_GPIO_DO_12; break;
	  case 13: result = PHCOM_GPIO_DO_13; break;
	  case 14: result = PHCOM_GPIO_DO_14; break;
	  case 15: result = PHCOM_GPIO_DO_15; break;
	  default: break;
	}
    else if (sscanf(line, "CTL%d", &lineNumber) == 1)
	/* explicitely switch on line number and do not try to
	   calculate the correct enum value, since its
	   definition may change */
	switch (lineNumber)
	{
	  case 0: result = PHCOM_GPIO_CTL_0; break;
	  case 1: result = PHCOM_GPIO_CTL_1; break;
	  default: break;
	}

    /* if not parsed, returning with empty value */
    return result;
}

static phComGpioILine_t getConfGpioInput(
    struct phFuncStruct *myself, char *key,
    int dimension, int *indexField, phComGpioILine_t defVal)
{
    phComGpioILine_t result = defVal;
    char *paramString;
    int notExist = 0;
    int isWrong = 0;
    int notUnderstood = 0;

    /* read the string for the given key */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfString(myself->myConf, key, 
	    dimension, indexField, &paramString) == 
	    PHCONF_ERR_OK)
	{
	    result = gpioStrToILine(paramString);
	    if (result == (phComGpioILine_t) 0)
	    {
		result = defVal;
		notUnderstood = 1;
	    }
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, assuming line %s",
	    key, gpioILineToStr(result));

    if (isWrong || notUnderstood)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter of '%s' not understood (%s), assuming line %s",
	    key, paramString, gpioILineToStr(result));
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' parameter accepted to be '%s'", 
	key, gpioILineToStr(result));

    return result;
}

static phComGpioOLine_t getConfGpioOutput(
    struct phFuncStruct *myself, char *key,
    int dimension, int *indexField, phComGpioOLine_t defVal)
{
    phComGpioOLine_t result = defVal;
    char *paramString;
    int notExist = 0;
    int isWrong = 0;
    int notUnderstood = 0;

    /* read the string for the given key */
    if (phConfConfIfDef(myself->myConf, key) == PHCONF_ERR_OK)
    {
	if (phConfConfString(myself->myConf, key, 
	    dimension, indexField, &paramString) == 
	    PHCONF_ERR_OK)
	{
	    result = gpioStrToOLine(paramString);
	    if (result == (phComGpioOLine_t) 0)
	    {
		result = defVal;
		notUnderstood = 1;
	    }
	}
	else
	    isWrong = 1;
    }
    else
	notExist = 1;

    /* handle exceptions */
    if (notExist)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
	    "parameter '%s' not configured, assuming line %s",
	    key, gpioOLineToStr(result));

    if (isWrong || notUnderstood)
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "parameter of '%s' not understood (%s), assuming line %s",
	    key, paramString, gpioOLineToStr(result));
    
    /* log result */
    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_MESSAGE_1,
	"'%s' parameter accepted to be '%s'", 
	key, gpioOLineToStr(result));

    return result;
}

static phComGpioOLine_t fillBinPattern(
    phComGpioOLine_t lsb    /* e.g. 0000010000000000 */ , 
    phComGpioOLine_t msb)   /* e.g. 0000000000100000 */
{
    phComGpioOLine_t lsbPat = (phComGpioOLine_t) 0; /* -> 0000011111111111 */
    phComGpioOLine_t msbPat = (phComGpioOLine_t) 0; /* -> 0000000000111111 */
    phComGpioOLine_t result = (phComGpioOLine_t) 0; /* -> 0000011111100000 */

    if (lsb == 0 || msb == 0 ||
	((lsb & PHCOM_GPIO_DO_ALL) && !(msb & PHCOM_GPIO_DO_ALL)) ||
	((lsb & PHCOM_GPIO_CTL_ALL) && !(msb & PHCOM_GPIO_CTL_ALL)))
	return (phComGpioOLine_t) 0;

    result = lsb | msb;   /* 0000010000100000 */

    do
    {
	lsbPat |= lsb;
	lsb >>= 1;
    } while (lsb != 0);

    do
    {
	msbPat |= msb;
	msb >>= 1;
    } while (msb != 0);

    result |= (lsbPat ^ msbPat);
    return result;
}

/*****************************************************************************
 *
 * Reconfigure plugin specific GPIO definitions
 *
 * Authors: Michael Vogt
 *
 * History: 05 Aug 1999, Michael Vogt, created
 *
 * Description: 
 * please refer to gpio_conf.h
 *
 ***************************************************************************/
int phFuncReconfigureGpio(struct phFuncStruct *myself)
{
    int resultValue = 1;
    struct gpioStruct safeConfig;
    struct gpioStruct *defaultConfig = NULL;
    struct gpioFlagsStruct *flags = NULL;

    int i;
    int gStartLnDefined;
    int psStartLnsDefined;
    int length;
    int site;
    int indexField[2];
    phConfType_t confType;
    int binLinesGiven;
    int eotLinesGiven;
    phComGpioOLine_t oredBinLines;
    phComGpioOLine_t binPattern;
    int assumeSharedBinLines;
    long binBitsUsed;
    phComGpioOLine_t oredEotLines;
    int assumeSharedEotLines;

    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_TRACE,
	"phFuncReconfigureGpio(P%p)", myself);

    /* save old configuration, in case we run into fatal situations */
    safeConfig = myself->u.gpio;

    /* get the defaults and set them, tehy may later be overridden by
       values coming from the configuration files */

    phFuncPredefGpioParams(&defaultConfig, &flags);
    if (!defaultConfig || !flags)
    {
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_FATAL,
	    "can not retrieve default GPIO config values");
	myself->u.gpio = safeConfig;
	return 0;
    }
    myself->u.gpio = *defaultConfig;

    /* get GPIO line polarities */
    myself->u.gpio.testStartPol = flags->testStartPolDeflt ?
	defaultConfig->testStartPol :
	getConfPolarity(myself, PHKEY_GP_TSPOL, defaultConfig->testStartPol);
    myself->u.gpio.eotPol = flags->eotPolDeflt ?
	defaultConfig->eotPol :
	getConfPolarity(myself, PHKEY_GP_EOTPOL, defaultConfig->eotPol);
    myself->u.gpio.binDataPol = flags->binDataPolDeflt ?
	defaultConfig->binDataPol :
	getConfPolarity(myself, PHKEY_GP_BINPOL, defaultConfig->binDataPol);

    /* get GPIO timings, only read in used values, otherwise warnings
       are printed that may confuse the user. Here is the complete list */
    myself->u.gpio.multiSiteLatencyTime = flags->multiSiteLatencyTimeDeflt ?
        defaultConfig->multiSiteLatencyTime :
        getConfUsecTiming(myself, PHKEY_GP_LATENCY, -3,
            defaultConfig->multiSiteLatencyTime);

    if ( flags->testStartToDutDelayTimeDeflt )
    {
        myself->u.gpio.testStartToDutDelayTime = defaultConfig->testStartToDutDelayTime;
    }
    else
    {
        if ( phConfConfIfDef(myself->myConf, PHKEY_GP_BOXDUTDELAY) == PHCONF_ERR_OK &&
             myself->interfaceType == PHFUNC_IF_NGPIO )
        {
            phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
                "configuration \"%s\" defined for interface type ngpio: setting ignored ",
                PHKEY_GP_BOXDUTDELAY);
        }
        else
        {
            myself->u.gpio.testStartToDutDelayTime =  getConfUsecTiming(myself, PHKEY_GP_BOXDUTDELAY, -3,
                                                                        defaultConfig->testStartToDutDelayTime);
        }
    }

    myself->u.gpio.smartestStartDelayTime = flags->smartestStartDelayTimeDeflt?
	defaultConfig->smartestStartDelayTime :
	getConfUsecTiming(myself, PHKEY_GP_TESTDELAY, -3, 
	    defaultConfig->smartestStartDelayTime);
    myself->u.gpio.eotDelayTime = flags->eotDelayTimeDeflt ?
	defaultConfig->eotDelayTime :
	getConfUsecTiming(myself, PHKEY_GP_EOTDELAY, -3, 
	    defaultConfig->eotDelayTime);
    myself->u.gpio.testStartRelaxTime = flags->testStartRelaxTimeDeflt ?
        defaultConfig->testStartRelaxTime :
        getConfUsecTiming(myself, PHKEY_GP_TESTSTARTRT, -3, 
            defaultConfig->testStartRelaxTime);
    myself->u.gpio.binDataSetupTime = flags->binDataSetupTimeDeflt ?
	defaultConfig->binDataSetupTime :
	getConfUsecTiming(myself, PHKEY_GP_BINTSU, -3, 
	    defaultConfig->binDataSetupTime);
    myself->u.gpio.eotPulseWidthTime = flags->eotPulseWidthTimeDeflt ?
	defaultConfig->eotPulseWidthTime :
	getConfUsecTiming(myself, PHKEY_GP_EOTPW, -3, 
	    defaultConfig->eotPulseWidthTime);
    myself->u.gpio.binDataHoldTime = flags->binDataHoldTimeDeflt ?
	defaultConfig->binDataHoldTime :
	getConfUsecTiming(myself, PHKEY_GP_BINTHLD, -3, 
	    defaultConfig->binDataHoldTime);
    myself->u.gpio.serialBinIntervalTime = flags->serialBinIntervalTimeDeflt ?
	defaultConfig->serialBinIntervalTime :
	getConfUsecTiming(myself, PHKEY_GP_BINTSER, -3, 
	    defaultConfig->serialBinIntervalTime);

    /* get GPIO waveforms, only read in used values, otherwise warnings
       are printed that may confuse the user. Here is the complete list */
    myself->u.gpio.testStartWf = flags->testStartWfDeflt ?
	defaultConfig->testStartWf :
	getConfGpioWf(myself, PHKEY_GP_TSWAV, defaultConfig->testStartWf);

    /* test start GPIO lines */
    gStartLnDefined = 
	(phConfConfIfDef(myself->myConf, PHKEY_GP_GSTARTLN) == PHCONF_ERR_OK);
    psStartLnsDefined = 
	(phConfConfIfDef(myself->myConf, PHKEY_GP_PSSTARTLNS) ==PHCONF_ERR_OK);

    if (flags->testStartModeDeflt)
    {
	/* do nothing, default values are already assigned */
    }
    else if (gStartLnDefined && psStartLnsDefined)
	myself->u.gpio.testStartMode = PHFUNC_GPIO_TS_CLOCKED;
    else if (gStartLnDefined && !psStartLnsDefined)
	myself->u.gpio.testStartMode = PHFUNC_GPIO_TS_GLOB;
    else if (!gStartLnDefined && psStartLnsDefined)
	myself->u.gpio.testStartMode = PHFUNC_GPIO_TS_DUT;
    else
	/* neither a global test start line nor per dut start lines
           are defined. assume a global test start line and report a
           warning while trying to read the GPIO line channel below... */
	myself->u.gpio.testStartMode = PHFUNC_GPIO_TS_GLOB;

    /* look for the global test start line */
    if (!flags->globalTestStartLineDeflt &&
	(myself->u.gpio.testStartMode == PHFUNC_GPIO_TS_GLOB ||
	    myself->u.gpio.testStartMode == PHFUNC_GPIO_TS_CLOCKED))
	myself->u.gpio.globalTestStartLine = getConfGpioInput(myself, 
	    PHKEY_GP_GSTARTLN, 0, NULL, defaultConfig->globalTestStartLine);
    
    /* look for per site test start lines */
    if (flags->perSiteDutLineCount)
    {
	if (flags->perSiteDutLineCount != myself->noOfSites)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"number of sites in configuration (%d) differs\n"
		"from plugin internal default value (%d)",
		myself->noOfSites, flags->perSiteDutLineCount);
	    resultValue = 0;
	}
	/* default values are already assigned */
    }
    else if (myself->u.gpio.testStartMode == PHFUNC_GPIO_TS_DUT ||
	myself->u.gpio.testStartMode == PHFUNC_GPIO_TS_CLOCKED)
	for (i=0; i<myself->noOfSites; i++)
	    myself->u.gpio.perSiteDutLine[i] = 
		getConfGpioInput(myself, PHKEY_GP_PSSTARTLNS, 1, &i, 
		    defaultConfig->perSiteDutLine[i]);
    
    /* define any gpio box latch reset lines */
    if (!flags->gpioClearLatchLinesDeflt &&
        phConfConfIfDef(myself->myConf, PHKEY_GP_BOXRESLNS) == PHCONF_ERR_OK)
    {
        if ( myself->interfaceType == PHFUNC_IF_NGPIO )
        {
            phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
                "configuration \"%s\" defined for interface type ngpio: setting ignored ",
                PHKEY_GP_BOXRESLNS);
        }
        else
        {
            length = 0;
            confType = PHCONF_TYPE_ALL;
            phConfConfType(myself->myConf, PHKEY_GP_BOXRESLNS, 0, NULL, 
                &confType, &length);
            if (confType == PHCONF_TYPE_LIST)
            {
                for (i=0; i<length; i++)
                    myself->u.gpio.gpioClearLatchLines |=
                        getConfGpioOutput(myself, PHKEY_GP_BOXRESLNS, 1, &i, 
                            defaultConfig->gpioClearLatchLines);
            }
            else
            {
                phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
                    "configuration '%s' not understood", PHKEY_GP_BOXRESLNS);
                resultValue = 0;
            }
        }
    }

    /* 
       find combination of input lines that need to be set as latched
       input lines for ngpio interface type where input start waveforms
       are pulsed waveforms
     */
    if ( myself->interfaceType == PHFUNC_IF_NGPIO &&
         myself->u.gpio.testStartWf == PHFUNC_GPIO_WF_PULSE )
    {
        myself->u.gpio.ngpioLatchedLines = myself->u.gpio.globalTestStartLine;

        for (i=0; i<myself->noOfSites; i++)
        {
            myself->u.gpio.ngpioLatchedLines |= myself->u.gpio.perSiteDutLine[i];
        }
    }
    else
        myself->u.gpio.ngpioLatchedLines =  (phComGpioILine_t) 0;

    /* define the binning */
    myself->u.gpio.binCoding = flags->binCodingDeflt ?
	defaultConfig->binCoding :
	getConfBinCoding(myself, PHKEY_GP_BINCODE, PHFUNC_GPIO_BC_EXPLICIT);

    myself->u.gpio.binMode = flags->binModeDeflt ?
	defaultConfig->binMode :
	getConfBinMode(myself, PHKEY_GP_BINMD, PHFUNC_GPIO_BM_SERIAL_EOT);

    myself->u.gpio.binDataWf = flags->binDataWfDeflt ?
	defaultConfig->binDataWf :
	getConfGpioWf(myself, PHKEY_GP_BINWAV, PHFUNC_GPIO_WF_STATIC);

    if (flags->binGroupsCount)
    {
	binLinesGiven = 1;
	eotLinesGiven = 1;
    }
    else
    {
	binLinesGiven = 0;
	eotLinesGiven = 0;
    }

    if (!flags->binGroupsCount &&
	phConfConfIfDef(myself->myConf, PHKEY_GP_PSBINLNSS) == PHCONF_ERR_OK)
    {
	length = 0;
	confType = PHCONF_TYPE_ALL;	
	phConfConfType(myself->myConf, PHKEY_GP_PSBINLNSS, 0, NULL,
	    &confType, &length);
	if (confType != PHCONF_TYPE_LIST || length != myself->noOfSites)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"configuration of '%s' must be a list of pairs of\n"
		"GPIO output lines with equal count as configuration '%s'", 
		PHKEY_GP_PSBINLNSS, PHKEY_SI_HSIDS);
	    resultValue = 0;
	}
	else
	    binLinesGiven = 1;
    }

    if (!flags->binGroupsCount &&
	phConfConfIfDef(myself->myConf, PHKEY_GP_PSEOTLNS) == PHCONF_ERR_OK)
    {
	length = 0;
	confType = PHCONF_TYPE_ALL;	
	phConfConfType(myself->myConf, PHKEY_GP_PSEOTLNS, 0, NULL,
	    &confType, &length);
	if (confType != PHCONF_TYPE_LIST || length != myself->noOfSites)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"configuration of '%s' must be a list of\n"
		"GPIO output lines with equal count as configuration '%s'", 
		PHKEY_GP_PSEOTLNS, PHKEY_SI_HSIDS);
	    resultValue = 0;
	}
	else
	    eotLinesGiven = 1;
    }

    if (!flags->binModeDeflt && !eotLinesGiven)
    {
	if (myself->u.gpio.binMode == PHFUNC_GPIO_BM_SERIAL_EOT)
	{
	    myself->u.gpio.binMode = PHFUNC_GPIO_BM_SERIAL_NO_EOT;
	    if (myself->u.gpio.binCoding == PHFUNC_GPIO_BC_EXPLICIT &&
		myself->u.gpio.binDataWf == PHFUNC_GPIO_WF_PULSE)
		phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
		    "unusual bin coding defined: pulsed, serial with explicit coding");
	}
	if (myself->u.gpio.binMode == PHFUNC_GPIO_BM_PARALLEL_EOT)
	    myself->u.gpio.binMode = PHFUNC_GPIO_BM_PARALLEL_NO_EOT;
	if (myself->u.gpio.binDataWf == PHFUNC_GPIO_WF_STATIC ||
	    myself->u.gpio.binCoding == PHFUNC_GPIO_BC_ENCODED)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"wrong GPIO bin modes defined, if not using end of test lines\n"
		"please check configuration for: %s, %s, and %s",
		PHKEY_GP_BINWAV, PHKEY_GP_BINCODE, PHKEY_GP_PSEOTLNS);
	    resultValue = 0;
	}
    }

    if (!flags->binGroupsCount) for (site=0; site<myself->noOfSites; site++)
    {
	if (binLinesGiven)
	{
	    indexField[0] = site;
	    indexField[1] = 0;
	    myself->u.gpio.binGroups[site].lsbLine =
		getConfGpioOutput(myself, PHKEY_GP_PSBINLNSS, 2, indexField, 
		    (phComGpioOLine_t) 0);
	    indexField[1] = 1;
	    myself->u.gpio.binGroups[site].msbLine =
		getConfGpioOutput(myself, PHKEY_GP_PSBINLNSS, 2, indexField, 
		    (phComGpioOLine_t) 0);
	}

	if (eotLinesGiven)
	{
	    myself->u.gpio.binGroups[site].eotLine =
		getConfGpioOutput(myself, PHKEY_GP_PSEOTLNS, 1, &site, 
		    (phComGpioOLine_t) 0);
	    if (myself->u.gpio.binGroups[site].eotLine == 0)
	    {
		phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		    "end of test line wrongly configured");
		resultValue = 0;
	    }		
	}
    }

    /* do we accept an empty bin code for retest ? */
    myself->u.gpio.acceptEmptyBin = flags->acceptEmptyBinDeflt ?
	defaultConfig->acceptEmptyBin :
	getConfAcceptEmptyBin(myself, PHKEY_BI_HRTBINS, 0);

    if (myself->u.gpio.acceptEmptyBin &&
	myself->u.gpio.binCoding != PHFUNC_GPIO_BC_EXPLICIT)
    {
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "impossible to use zero retest bin code together\n"
	    "with encoded bin data. Check configuration of %s and %s",
	    PHKEY_BI_HRTBINS, PHKEY_GP_BINCODE);
	resultValue = 0;
    }

    /* should check two things:
       do all bin line groups have the same size?
       do the groups overlap? if yes: do they fully overlap? */
    
    oredBinLines = (phComGpioOLine_t) 0;
    for (site=0; site<myself->noOfSites; site++)
    {
	binPattern = fillBinPattern(
	    myself->u.gpio.binGroups[site].lsbLine,
	    myself->u.gpio.binGroups[site].msbLine);
	oredBinLines |= binPattern;

	if (binPattern == 0)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"bin line group for handler site '%s' wrongly defined",
		myself->siteIds[site]);
	    resultValue = 0;   
	}
    }
    assumeSharedBinLines = 1;
    for (site=0; site<myself->noOfSites; site++)
    {
	binPattern = fillBinPattern(
	    myself->u.gpio.binGroups[site].lsbLine,
	    myself->u.gpio.binGroups[site].msbLine);

	if (binPattern != oredBinLines)
	    assumeSharedBinLines = 0;
    }
    for (site=0; !assumeSharedBinLines && site<myself->noOfSites; site++)
    {
	binPattern = fillBinPattern(
	    myself->u.gpio.binGroups[site].lsbLine,
	    myself->u.gpio.binGroups[site].msbLine);

	for (i=site+1; i<myself->noOfSites; i++)
	{
	    if ((binPattern & fillBinPattern(
		myself->u.gpio.binGroups[i].lsbLine,
		myself->u.gpio.binGroups[i].msbLine)))
	    {
		phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		    "bin line groups for handler site '%s' and '%s' overlap",
		    myself->siteIds[site], myself->siteIds[i]);
		resultValue = 0;   
	    }
	}
    }
    myself->u.gpio.allBinLines = oredBinLines;

    if (resultValue)
    {
	if (assumeSharedBinLines &&
	    myself->noOfSites > 1 &&
	    (myself->u.gpio.binMode == PHFUNC_GPIO_BM_PARALLEL_EOT ||
		myself->u.gpio.binMode == PHFUNC_GPIO_BM_PARALLEL_NO_EOT))
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"parallel binning mode defined but using shared bin lines for all sites");
	    resultValue = 0;   
	}

	if (!assumeSharedBinLines &&
	    (myself->u.gpio.binMode == PHFUNC_GPIO_BM_SERIAL_EOT ||
		myself->u.gpio.binMode == PHFUNC_GPIO_BM_SERIAL_NO_EOT))
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
		"serial binning mode defined but using different bin lines for each site");
	}
    }

    /* should check:
       are all eot lines dijunct or are all eot lines equal?
       Both would be valid but strange combinations seem to be wrong */

    oredEotLines = (phComGpioOLine_t) 0;
    if (myself->u.gpio.binMode == PHFUNC_GPIO_BM_PARALLEL_EOT ||
	myself->u.gpio.binMode == PHFUNC_GPIO_BM_SERIAL_EOT)
    {
	for (site=0; site<myself->noOfSites; site++)
	{
	    oredEotLines |= myself->u.gpio.binGroups[site].eotLine;

	    if (myself->u.gpio.binGroups[site].eotLine == 0)
	    {
		phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		    "end of test line for handler site '%s' not defined",
		    myself->siteIds[site]);
		resultValue = 0;   
	    }
	}
	assumeSharedEotLines = 1;
	for (site=0; site<myself->noOfSites; site++)
	{
	    if (myself->u.gpio.binGroups[site].eotLine != oredEotLines)
		assumeSharedEotLines = 0;
	}
	for (site=0; !assumeSharedEotLines && site<myself->noOfSites; site++)
	{
	    for (i=site+1; i<myself->noOfSites; i++)
	    {
		if ((myself->u.gpio.binGroups[site].eotLine & 
		    myself->u.gpio.binGroups[i].eotLine))
		{
		    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
			"eot lines for handler site '%s' and '%s' overlap",
			myself->siteIds[site], myself->siteIds[i]);
		    resultValue = 0;   
		}
	    }
	}
    }
    myself->u.gpio.allEotLines = oredEotLines;

    if (resultValue)
    {
	if (oredEotLines & oredBinLines)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"bin lines and end of test lines definitions overlap");
	    resultValue = 0;   
	}
    }

    /* count the number of bits per bin */
    if (resultValue) 
	for (site=0; site<myself->noOfSites; site++)
	{
	    binPattern = fillBinPattern(
		myself->u.gpio.binGroups[site].lsbLine,
		myself->u.gpio.binGroups[site].msbLine);
	    binBitsUsed = 0;
	    do
	    {
		if ((binPattern & 1))
		    binBitsUsed++;
		binPattern >>= 1;
	    } while (binPattern != 0);
	    myself->u.gpio.binGroups[site].binBitsUsed = binBitsUsed;
	}

    /* if bin id's are given in the configuration (set in myself),
       then check whether the number of bins fits together with the
       bin code lines */

    if (resultValue && myself->noOfBins)
    {
	binBitsUsed = myself->u.gpio.binGroups[0].binBitsUsed;

	if (myself->u.gpio.binCoding == PHFUNC_GPIO_BC_ENCODED)
	    binBitsUsed = (1 << binBitsUsed);
	
	if (binBitsUsed > myself->noOfBins)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_WARNING,
		"GPIO bin line configuration allows more bins (%ld) than\n"
		"given in '%s' (%d). Not all posible handler bins will be used",
		binBitsUsed, PHKEY_BI_HBIDS, myself->noOfBins);
	}

	if (binBitsUsed < myself->noOfBins)
	{
	    phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
		"GPIO bin line configuration defines less bins (%ld) than\n"
		"given in '%s' (%d)",
		binBitsUsed, PHKEY_BI_HBIDS, myself->noOfBins);
	    resultValue = 0;
	}	
    }

    /* set the received time stamp to 0.0 to have a valid start condition */
    myself->u.gpio.devicesReceivedStamp.tv_sec = 0L;
    myself->u.gpio.devicesReceivedStamp.tv_usec = 0L;

    /* return with success status, recover old configuration in case
       of fatal errors */
    if (! resultValue)
    {
	phLogFuncMessage(myself->myLogger, PHLOG_TYPE_ERROR,
	    "GPIO specific parts of driver plugin not (re)configured\n"
	    "due to previous error messages");
	myself->u.gpio = safeConfig;
    }

    return resultValue;
}

/*****************************************************************************
 * End of file
 *****************************************************************************/
