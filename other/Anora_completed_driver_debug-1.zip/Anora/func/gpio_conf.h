/******************************************************************************
 *
 *       (c) Copyright HEWLETT-PACKARD GmbH, Boeblingen 1999
 *
 *-----------------------------------------------------------------------------
 *
 * MODULE   : gpio_conf.h
 * CREATED  : 05 Aug 1999
 *
 * CONTENTS : Configuration of GPIO specific parts
 *
 * AUTHORS  : Michael Vogt, SSTD-R&D, initial revision
 *
 *-----------------------------------------------------------------------------
 *
 * HISTORY  : 05 Aug 1999, Michael Vogt, created
 *
 * Instructions:
 *
 * 1) Copy this template to as many .h files as you require
 *
 * 2) Use the command 'make depend' to make the new
 *    source files visible to the makefile utility
 *
 * 3) To support automatic man page (documentation) generation, follow the
 *    instructions given for the function template below.
 * 
 * 4) Put private functions and other definitions into separate header
 * files. (divide interface and private definitions)
 *
 *****************************************************************************/

#ifndef _GPIO_CONF_H_
#define _GPIO_CONF_H_

/*--- system includes -------------------------------------------------------*/

#include <time.h>

/*--- module includes -------------------------------------------------------*/

#include "ph_mhcom.h"

/*--- defines ---------------------------------------------------------------*/

/*--- typedefs --------------------------------------------------------------*/

enum gpioPolarity
{
    PHFUNC_GPIO_POL_POS,
    PHFUNC_GPIO_POL_NEG
};

enum gpioWaveform
{
    PHFUNC_GPIO_WF_PULSE,
    PHFUNC_GPIO_WF_STATIC
};

enum gpioTestStartMode
{
    PHFUNC_GPIO_TS_DUT                  /* test start lines per dut */,
    PHFUNC_GPIO_TS_GLOB                 /* global test start line */,
    PHFUNC_GPIO_TS_CLOCKED              /* combination of per dut
					   signals and global test start 
					   signal */
};

enum gpioBinCoding
{
    PHFUNC_GPIO_BC_ENCODED,
    PHFUNC_GPIO_BC_EXPLICIT
};

enum gpioBinMode
{
    PHFUNC_GPIO_BM_SERIAL_EOT,
    PHFUNC_GPIO_BM_SERIAL_NO_EOT,
    PHFUNC_GPIO_BM_PARALLEL_EOT,
    PHFUNC_GPIO_BM_PARALLEL_NO_EOT
};

struct gpioPerSiteBinDef
{
    phComGpioOLine_t         lsbLine;
    phComGpioOLine_t         msbLine;
    phComGpioOLine_t         eotLine;
    int                      binBitsUsed;
};

struct gpioStruct{
    enum gpioPolarity        testStartPol;            /* PHKEY_GP_TSPOL */
    enum gpioPolarity        eotPol;                  /* PHKEY_GP_EOTPOL */
    enum gpioPolarity        binDataPol;              /* PHKEY_GP_BINPOL */

    long                     multiSiteLatencyTime;    /* PHKEY_GP_LATENCY */
    long                     testStartToDutDelayTime; /* PHKEY_GP_BOXDUTDELAY*/
    long                     smartestStartDelayTime;  /* PHKEY_GP_TESTDELAY */
    long                     eotDelayTime;            /* PHKEY_GP_EOTDELAY */
    long                     binDataSetupTime;        /* PHKEY_GP_BINTSU */
    long                     eotPulseWidthTime;       /* PHKEY_GP_EOTPW */
    long                     binDataHoldTime;         /* PHKEY_GP_BINTHLD */
    long                     serialBinIntervalTime;   /* PHKEY_GP_BINTSER*/
    long                     testStartRelaxTime;      /* PHKEY_GP_TESTSTARTRT */

    enum gpioWaveform        testStartWf;             /* PHKEY_GP_TSWAV */
    enum gpioTestStartMode   testStartMode;           /* PHKEY_GP_GSTARTLN 
							 PHKEY_GP_PSSTARTLNS */

    phComGpioILine_t         globalTestStartLine;     /* PHKEY_GP_GSTARTLN */
    phComGpioILine_t         perSiteDutLine[PHESTATE_MAX_SITES];
                                                      /* PHKEY_GP_PSSTARTLNS */
    phComGpioOLine_t         gpioClearLatchLines;     /* PHKEY_GP_BOXRESLNS 
							 multiple lines */

    enum gpioBinMode         binMode;                 /* PHKEY_GP_BINMD 
							 PHKEY_GP_PSEOTLNS */
    enum gpioBinCoding       binCoding;               /* PHKEY_GP_BINCODE */
    enum gpioWaveform        binDataWf;               /* PHKEY_GP_BINWAV */
    struct gpioPerSiteBinDef binGroups[PHESTATE_MAX_SITES];
                                                      /* PHKEY_GP_PSBINLNSS 
							 PHKEY_GP_PSEOTLNS */

    int                      acceptEmptyBin;          /* PHKEY_BI_HRTBINS */

    phComGpioOLine_t         allEotLines;             /* PHKEY_GP_PSEOTLNS */
    phComGpioOLine_t         allBinLines;             /* PHKEY_GP_PSBINLNSS */

    struct timeval           devicesReceivedStamp;

    struct timeval           eotSignalSentStamp;

    phComGpioILine_t         ngpioLatchedLines;   
                                      /* 
                                         For the ngpio interface type must set certain input lines 
                                         as latched inputlines. Derrived by considering 
                                         test_start_waveform.  For type "pulse" latches need 
                                         to be set. In this case ngpioLatchedLines
                                         should be the or'ed combination of 
                                         per_site_test_start_line and global_test_start_line.  
                                       */
};

struct gpioFlagsStruct{
    int testStartPolDeflt;             /* PHKEY_GP_TSPOL */
    int eotPolDeflt;                   /* PHKEY_GP_EOTPOL */
    int binDataPolDeflt;               /* PHKEY_GP_BINPOL */
    int multiSiteLatencyTimeDeflt;     /* PHKEY_GP_LATENCY */
    int testStartToDutDelayTimeDeflt;  /* PHKEY_GP_BOXDUTDELAY */
    int smartestStartDelayTimeDeflt;   /* PHKEY_GP_TESTDELAY */
    int eotDelayTimeDeflt;             /* PHKEY_GP_EOTDELAY */
    int binDataSetupTimeDeflt;         /* PHKEY_GP_BINTSU */
    int eotPulseWidthTimeDeflt;        /* PHKEY_GP_EOTPW */
    int binDataHoldTimeDeflt;          /* PHKEY_GP_BINTHLD */
    int serialBinIntervalTimeDeflt;    /* PHKEY_GP_BINTSER*/
    int testStartWfDeflt;              /* PHKEY_GP_TSWAV */
    int testStartModeDeflt;            /* PHKEY_GP_GSTARTLN 
					  PHKEY_GP_PSSTARTLNS */
    int globalTestStartLineDeflt;      /* PHKEY_GP_GSTARTLN */
    int perSiteDutLineCount;           /* PHKEY_GP_PSSTARTLNS */
    int gpioClearLatchLinesDeflt;      /* PHKEY_GP_BOXRESLNS */
    int testStartRelaxTimeDeflt;       /* PHKEY_GP_TESTSTARTRT */

    int binModeDeflt;                  /* PHKEY_GP_BINMD 
					  PHKEY_GP_PSEOTLNS */
    int binCodingDeflt;                /* PHKEY_GP_BINCODE */
    int binDataWfDeflt;                /* PHKEY_GP_BINWAV */
    int binGroupsCount;                /* PHKEY_GP_PSBINLNSS 
					  PHKEY_GP_PSEOTLNS */
    int acceptEmptyBinDeflt;           /* PHKEY_BI_HRTBINS */
};

/*--- external variables ----------------------------------------------------*/

/*--- external function -----------------------------------------------------*/

/*****************************************************************************
 * To allow a consistent interface definition and documentation, the
 * documentation is automatically extracted from the comment section
 * of the below function declarations. All text within the comment
 * region just in front of a function header will be used for
 * documentation. Additional text, which should not be visible in the
 * documentation (like this text), must be put in a separate comment
 * region, ahead of the documentation comment and separated by at
 * least one blank line.
 *
 * To fill the documentation with life, please fill in the angle
 * bracketed text portions (<>) below. Each line ending with a colon
 * (:) or each line starting with a single word followed by a colon is
 * treated as the beginning of a separate section in the generated
 * documentation man page. Besides blank lines, there is no additional
 * format information for the resulting man page. Don't expect
 * formated text (like tables) to appear in the man page similar as it
 * looks in this header file.
 *
 * Function parameters should be commented immediately after the type
 * specification of the parameter but befor the closing bracket or
 * dividing comma characters.
 *
 * To use the automatic documentation feature, c2man must be installed
 * on your system for man page generation.
 *****************************************************************************/

/*****************************************************************************
 *
 * Reconfigure plugin specific GPIO definitions
 *
 * Authors: Michael Vogt
 *
 * Description: On initialization and when the configuration has
 * changed, the configuration data must be read and the driver plugin
 * must be reconfigured. This function performs all necessary steps
 * for GPIO specific parts of the driver.
 * 
 * Notes: The function will print any error messages and warnings
 *
 * Returns: 0 in fatal situations, 1 on success
 *
 ***************************************************************************/

int phFuncReconfigureGpio(
    struct phFuncStruct *myself         /* the handle of the plugin */
);

#endif /* ! _GPIO_CONF_H_ */

/*****************************************************************************
 * End of file
 *****************************************************************************/
